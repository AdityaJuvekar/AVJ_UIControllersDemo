//
//  ArrowView.m
//  SpeedBanking
//
//  Created by admin on 18/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import "ArrowView.h"

@implementation ArrowView


- (void)drawRect:(CGRect)rect {
    UIBezierPath* triangle = [UIBezierPath bezierPath];
    if (_isRight) {
        [triangle moveToPoint:CGPointMake(0, 0)];
        [triangle addLineToPoint:CGPointMake(self.frame.size.width, self.frame.size.height/2)];
        [triangle addLineToPoint:CGPointMake(0, self.frame.size.height)];
    } else {
        [triangle moveToPoint:CGPointMake(self.frame.size.width, 0)];
        [triangle addLineToPoint:CGPointMake(0, self.frame.size.height/2)];
        [triangle addLineToPoint:CGPointMake(self.frame.size.width, self.frame.size.height)];
    }
    [triangle closePath];
    [_arrowColor setFill];
    [triangle fill];
    
    /*CGContextRef context = UIGraphicsGetCurrentContext();
    CGMutablePathRef path = CGPathCreateMutable();
    if (_isRight) {
        CGPathMoveToPoint(path, NULL, 0, 0);
        CGPathAddLineToPoint(path, NULL, self.frame.size.width, self.frame.size.height/2);
        CGPathAddLineToPoint(path, NULL, 0, self.frame.size.height);
    } else {
        CGPathMoveToPoint(path, NULL, self.frame.size.width, 0);
        CGPathAddLineToPoint(path, NULL, 0, self.frame.size.height/2);
        CGPathAddLineToPoint(path, NULL, self.frame.size.width, self.frame.size.height);
    }
    
    CGPathCloseSubpath(path);
    CGContextAddPath(context, path);
    CGContextSetFillColorWithColor(context, _arrowColor.CGColor);
    CGContextFillPath(context);*/
}


@end
