//
//  ColorView.m
//  AVJ_UIControllersDemo
//
//  Created by admin on 23/01/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ColorView.h"

@implementation ColorView

- (void)drawRect:(CGRect)rect {
    CAGradientLayer *gradient = [CAGradientLayer layer];
    
    gradient.frame = self.bounds;
    gradient.colors = @[(id)[UIColor blueColor].CGColor, (id)[UIColor redColor].CGColor,(id)[UIColor greenColor].CGColor];
    //gradient.startPoint = CGPointMake(0, 0);
    //gradient.endPoint = CGPointMake(100, 100);
    gradient.locations = @[[NSNumber numberWithFloat:0.0],[NSNumber numberWithFloat:0.5],[NSNumber numberWithFloat:1.0]];
    [self.layer insertSublayer:gradient atIndex:0];
    
    CAGradientLayer *gradient2 = [CAGradientLayer layer];
    
    gradient2.frame = self.bounds;
    gradient2.colors = @[(id)[UIColor redColor].CGColor,(id)[UIColor greenColor].CGColor,(id)[UIColor blueColor].CGColor, (id)[UIColor clearColor].CGColor];
    gradient2.locations = @[[NSNumber numberWithFloat:0.0],[NSNumber numberWithFloat:0.5],[NSNumber numberWithFloat:1.0]];
    //gradient2.locations = @[[NSNumber numberWithFloat:0.0],[NSNumber numberWithFloat:0.2]];
    gradient2.startPoint = CGPointMake(0.0, 0.5);
    gradient2.endPoint = CGPointMake(1.0, 0.5);
    //[self.layer insertSublayer:gradient2 atIndex:0];
}


@end
