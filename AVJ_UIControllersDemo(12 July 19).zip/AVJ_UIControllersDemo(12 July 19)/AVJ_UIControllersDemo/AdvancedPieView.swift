//
//  AdvancedPieView.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 30/04/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

struct PieStruct {
    var value: Double
    var color: UIColor
    var image: UIImage
    var labelText: NSAttributedString
    fileprivate var index: Int
    
    static var counter = 0
    
    init(value val: Double,color clr: UIColor,image img: UIImage,labelText text: NSAttributedString) {
        self.value = val
        self.color = clr
        self.image = img
        self.labelText = text
        self.index = PieStruct.counter
        PieStruct.counter += 1
    }
}

class AdvancedPieView: UIView {
    
    let lineWidth: CGFloat = 0.01
    var maxValue = 0.0
    var maxRadius: CGFloat = 0.0
    let maxRadFactor: CGFloat = 1.2
    let _extension: CGFloat = 0.3
    private var radius: CGFloat = 0.0
    private var centre = CGPoint(x: 0, y: 0)
    let dotRad: CGFloat = 5.0
    private var ninety = CGFloat.pi/2
    private var oneEighty = CGFloat.pi
    private var twoSeventy = CGFloat.pi*(3/2)
    private var threeSixty = CGFloat.pi*2

    var dataArray: [PieStruct]? {
        didSet {
            removeAllPies()
            removeAllSubviews()
            var totalValue = 0.0
            guard dataArray != nil else { return }
            for data in dataArray! {
                totalValue = totalValue + data.value
            }
            
            for i in 0..<dataArray!.count {
                dataArray![i].value = (dataArray![i].value/totalValue)*Double(threeSixty)
                if maxValue < dataArray![i].value {
                    maxValue = dataArray![i].value
                    selectedIndex = i
                }
            }
            self.setNeedsDisplay()
        }
    }
    
    let imageNamesArray = ["icons8-buy-80.png","icons8-cheap-2-80.png","icons8-flag-2-64.png","icons8-motorcycle-filled-50.png","icons8-rupee-80.png","icons8-salami-pizza-64.png","icons8-trust-64.png"]

    var startEndAnglesArray: [(startAngle: Double, endAngle: Double)]?
    var layerArray: [CALayer] = []
    var viewArray: [UIView] = []
    var selectedShapeLayer: CAShapeLayer?
    var selectedIndex = 0
    let tapRecognizer = UITapGestureRecognizer.init()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        tapRecognizer.addTarget(self, action: #selector(segmentSelected(_:)))
        self.addGestureRecognizer(tapRecognizer)
    }
    
    @objc func segmentSelected(_ recognizer: UITapGestureRecognizer) {
        let touchPoint = recognizer.location(in: self)
        let convertedPoint = CGPoint(x: touchPoint.x-centre.x, y: touchPoint.y-centre.y)
        let distance = sqrt(convertedPoint.x*convertedPoint.x + convertedPoint.y*convertedPoint.y)
        guard distance <= radius else { return }
        var angle: CGFloat?

        if convertedPoint.y>0 {
            if convertedPoint.x == 0 {
                angle = ninety
            } else {
                angle = atan2(convertedPoint.y, convertedPoint.x)
            }
        } else if convertedPoint.y<0{
            if convertedPoint.x == 0 {
                angle = twoSeventy
            } else {
                angle = threeSixty + atan2(convertedPoint.y, convertedPoint.x)
            }
        }

        if let anglesArray = startEndAnglesArray, let touchAngle = angle, !touchAngle.isNaN {
            for i in 0..<anglesArray.count {
                var strAngle = anglesArray[i].startAngle
                var endAngle = anglesArray[i].endAngle
//                if strAngle > .pi*2 {
//                    strAngle -= .pi*2
//                }
//                if endAngle > .pi*2 {
//                    endAngle -= .pi*2
//                }
                //print("\(strAngle), \(touchAngle), \(endAngle)")
                if (strAngle < Double(touchAngle) && Double(touchAngle) < endAngle)/* || (strAngle > Double(touchAngle) && Double(touchAngle) > endAngle)*/ {
                    if selectedIndex != i {
                        selectedIndex = i
                        removeAllPies()
                        removeAllSubviews()
                        setNeedsDisplay()
                    }
                }
            }
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let dataArray = dataArray else { return }
        
        startEndAnglesArray?.removeAll()
        centre = CGPoint(x: frame.width/2.0, y: frame.height/2.0)
        radius = min(frame.width, frame.height)/4.5
        maxRadius = radius*maxRadFactor
        var shiftAngle = 0.0//dataArray[0].value/2
        var maxValueTuple: (strAng:Double, endAgl:Double, arcColor:UIColor, image:UIImage, text:NSAttributedString) = (0,0,UIColor.clear,UIImage(),NSAttributedString())
        var maxValArray: [(strAng:Double, endAgl:Double, arcColor:UIColor, image:UIImage, text:NSAttributedString)]?
        
        for i in 0..<dataArray.count {
            let endAngle = (shiftAngle+dataArray[i].value)
            if dataArray[i].index == selectedIndex {
                maxValueTuple = (shiftAngle, endAngle, dataArray[i].color, dataArray[i].image, dataArray[i].labelText)
                if maxValArray != nil {
                    maxValArray?.append(maxValueTuple)
                } else {
                    maxValArray = [maxValueTuple]
                }
                if startEndAnglesArray != nil {
                    startEndAnglesArray?.append((shiftAngle, endAngle))
                } else {
                    startEndAnglesArray = [(shiftAngle, endAngle)]
                }
            } else {
                if startEndAnglesArray != nil {
                    startEndAnglesArray?.append((shiftAngle, endAngle))
                } else {
                    startEndAnglesArray = [(shiftAngle, endAngle)]
                }
                drawArcWithCentre(centre, radius: radius, arcWidth: 0, startAngle: CGFloat(shiftAngle), endAngle: CGFloat(endAngle), andColor: dataArray[i].color, andImage: dataArray[i].image,andText: dataArray[i].labelText)
            }
            shiftAngle = endAngle
        }
        if let maxValData = maxValArray {
            for maxValTuple in maxValData {
                drawArcWithCentre(centre, radius: maxRadius, arcWidth: 0, startAngle: CGFloat(maxValTuple.strAng), endAngle: CGFloat(maxValTuple.endAgl), andColor: maxValTuple.arcColor, andImage: maxValTuple.image,andText: maxValTuple.text)
            }
        }
    }
    
    private func drawArcWithCentre(_ centre: CGPoint,radius rad: CGFloat,arcWidth arcWid: CGFloat,startAngle srtAngle: CGFloat,endAngle endAgl: CGFloat,andColor color :UIColor,andImage image: UIImage,andText text: NSAttributedString) {
        
        let intermediateAng = srtAngle + (endAgl-srtAngle)/2.0
        let lengthFactor: CGFloat = 1 + _extension
        let path = CGMutablePath()
        path.move(to: centre)
        path.addLine(to: CGPoint(x: centre.x + radius*cos(srtAngle), y: centre.y + radius*sin(srtAngle)))
        path.addArc(center: centre, radius: radius, startAngle: srtAngle, endAngle: intermediateAng-lineWidth, clockwise: false)
        path.addLine(to: CGPoint(x: lengthFactor*radius*cos(intermediateAng-lineWidth/lengthFactor)+centre.x, y: lengthFactor*radius*sin(intermediateAng-lineWidth/lengthFactor)+centre.y))
        path.addArc(center: CGPoint(x: (lengthFactor*radius+dotRad)*cos(intermediateAng)+centre.x, y: (lengthFactor*radius+dotRad)*sin(intermediateAng)+centre.y), radius: dotRad, startAngle: intermediateAng + ninety+lineWidth/lengthFactor, endAngle: intermediateAng + oneEighty*3.0 - (maxRadius/dotRad)*lineWidth/lengthFactor, clockwise: false)
        path.addLine(to: CGPoint(x: radius*cos(intermediateAng+lineWidth)+centre.x, y: radius*sin(intermediateAng+lineWidth)+centre.y))
        path.addArc(center: centre, radius: radius, startAngle: intermediateAng+lineWidth, endAngle: endAgl, clockwise: false)
        path.closeSubpath()

        let shapelayer = CAShapeLayer()
        shapelayer.path = path
        shapelayer.strokeColor = UIColor.clear.cgColor
        shapelayer.lineWidth = lineWidth
        shapelayer.fillColor = color.cgColor
        shapelayer.fillMode = CAMediaTimingFillMode.forwards
        
        if rad == maxRadius {
            shapelayer.shadowOffset = CGSize(width: 10, height: 3)
            shapelayer.shadowColor = UIColor.init(white: 0.2, alpha: 0.5).cgColor
            shapelayer.shadowRadius = 8
            shapelayer.shadowOpacity = 1
            let endPath = CGMutablePath()
            endPath.move(to: centre)
            endPath.addLine(to: CGPoint(x: centre.x + maxRadius*cos(srtAngle), y: centre.y + maxRadius*sin(srtAngle)))
            endPath.addArc(center: centre, radius: maxRadius, startAngle: srtAngle, endAngle: intermediateAng-lineWidth, clockwise: false)
            endPath.addLine(to: CGPoint(x: lengthFactor*maxRadius*cos(intermediateAng-lineWidth/lengthFactor)+centre.x, y: lengthFactor*maxRadius*sin(intermediateAng-lineWidth/lengthFactor)+centre.y))
            endPath.addArc(center: CGPoint(x: lengthFactor*(maxRadius+dotRad)*cos(intermediateAng)+centre.x, y: lengthFactor*(maxRadius+dotRad)*sin(intermediateAng)+centre.y), radius: dotRad*lengthFactor, startAngle: intermediateAng + ninety+lineWidth/lengthFactor, endAngle: intermediateAng + oneEighty*3.0 - (maxRadius/dotRad*lengthFactor)*lineWidth/lengthFactor, clockwise: false)
            endPath.addLine(to: CGPoint(x: maxRadius*cos(intermediateAng+lineWidth)+centre.x, y: maxRadius*sin(intermediateAng+lineWidth)+centre.y))
            endPath.addArc(center: centre, radius: maxRadius, startAngle: intermediateAng+lineWidth, endAngle: endAgl, clockwise: false)
            endPath.closeSubpath()
            
            let animation = CABasicAnimation(keyPath: "path")
            animation.toValue = endPath
            animation.duration = 0.2
            animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
            animation.fillMode = CAMediaTimingFillMode.both
            animation.isRemovedOnCompletion = false
            shapelayer.add(animation, forKey: animation.keyPath)
        } else {
            shapelayer.shadowOffset = CGSize(width: 5, height: 1.5)
            shapelayer.shadowColor = UIColor.init(white: 0.2, alpha: 0.4).cgColor
            shapelayer.shadowRadius = 4
            shapelayer.shadowOpacity = 1
        }
        self.layer.addSublayer(shapelayer)
        layerArray.append(shapelayer)
        addImage(image, atAngle: intermediateAng, radius: rad, forDifference: endAgl-srtAngle)
        addLabel(text, atAngle: intermediateAng, radius: rad)
    }
    
    func addImage(_ image: UIImage, atAngle angle: CGFloat, radius rad: CGFloat , forDifference difference: CGFloat) {
        let imageWidth: CGFloat = 20
        let imageHeight: CGFloat = 20
        let imageLayer = CALayer()
        imageLayer.backgroundColor = UIColor.clear.cgColor
        imageLayer.frame = CGRect(x: (rad/1.75)*cos(angle)+centre.x-imageWidth/2, y: (rad/1.75)*sin(angle)+centre.y-imageHeight/2, width: imageWidth, height: imageHeight)
        imageLayer.contents = image.cgImage
        self.layer.addSublayer(imageLayer)
        layerArray.append(imageLayer)
    }
    
    func addLabel(_ text: NSAttributedString, atAngle angle: CGFloat, radius rad: CGFloat) {
        let lengthFactor: CGFloat = 1 + _extension
        let distance = lengthFactor*rad
        let dotRadAdjstmnt = lengthFactor*dotRad
        let labelHeight: CGFloat = 32
        let labelWidth = text.width(withConstrainedHeight: labelHeight)
        
        let Xcoordinate = distance*cos(angle)+centre.x
        let Ycoordinate = distance*sin(angle)+centre.y
        
        let label = UILabel()
        if angle < ninety {
            label.frame = CGRect(x: Xcoordinate-((ninety-angle)/ninety)*_extension*(rad), y: Ycoordinate+dotRadAdjstmnt, width: labelWidth, height: labelHeight)
        } else if angle < oneEighty {
            label.frame = CGRect(x: Xcoordinate+((angle-ninety)/ninety)*_extension*(rad)-labelWidth, y: Ycoordinate+dotRadAdjstmnt, width: labelWidth, height: labelHeight)
        } else if angle < twoSeventy {
            label.frame = CGRect(x: Xcoordinate+((twoSeventy-angle)/ninety)*_extension*(rad)-labelWidth, y: Ycoordinate-labelHeight-dotRadAdjstmnt, width: labelWidth, height: labelHeight)
        } else {
            label.frame = CGRect(x: Xcoordinate-((angle-twoSeventy)/ninety)*_extension*(rad), y: Ycoordinate-labelHeight-dotRadAdjstmnt, width: labelWidth, height: labelHeight)
        }
        
        label.numberOfLines = 2
        label.attributedText = text
        self.addSubview(label)
        viewArray.append(label)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let point = touch!.location(in: self)
        for i in 0..<layerArray.count {
            if let shapeLayer = layerArray[i] as? CAShapeLayer, shapeLayer.path?.contains(point) ?? false {
                selectedShapeLayer = shapeLayer
                //selectedIndex = i
            }
        }
        
    }
    
    func removeAllPies() {
        for shapelayer in layerArray {
            shapelayer.removeAllAnimations()
            shapelayer.removeFromSuperlayer()
        }
        layerArray.removeAll()
    }
    
    func removeAllSubviews() {
        for view in viewArray {
            view.removeFromSuperview()
        }
        viewArray.removeAll()
    }
    
}


extension NSAttributedString {
    func height(withConstrainedWidth width: CGFloat) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, context: nil)
        
        return ceil(boundingBox.height)
    }
    
    func width(withConstrainedHeight height: CGFloat) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, context: nil)
        
        return ceil(boundingBox.width)
    }
}

