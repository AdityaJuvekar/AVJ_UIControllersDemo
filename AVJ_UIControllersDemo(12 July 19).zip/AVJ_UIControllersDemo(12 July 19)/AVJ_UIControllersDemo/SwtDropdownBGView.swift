//
//  SwtDropdownBGView.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 10/09/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class SwtDropdownBGView: UIPopoverBackgroundView {
    
    override init(frame:CGRect) {
        super.init(frame:frame)
        
        let popoverBackgroundImageView
            = UIImageView(image: createBackgroundImage())
        self.addSubview(popoverBackgroundImageView)
        popoverBackgroundImageView.frame = self.bounds
        self.layer.shadowColor = UIColor.clear.cgColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override static func contentViewInsets() -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    override static func arrowBase() -> CGFloat {
        return 0
    }
    
    override static func arrowHeight() -> CGFloat {
        return 0
    }

    override var arrowDirection: UIPopoverArrowDirection {
        get {
            return .up
        }
        set {
        }
    }
    
    override var arrowOffset: CGFloat {
        get {
            return 0
        }
        set {
        }
    }
    
    func createBackgroundImage() -> UIImage {
        let blankView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        blankView.backgroundColor = UIColor.white
        UIGraphicsBeginImageContextWithOptions(blankView.frame.size, true, 0.0)
        blankView.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        let popoverBackgroundImage
            = image?.resizableImage(withCapInsets: UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20))
        
        return popoverBackgroundImage!
    }

}
