//
//  SwMonthYearTable.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 21/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class SwMonthYearTable: UITableViewController {

    var dataArray = [String]()
    weak var delegate: SwiftCalendarVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.view.superview?.layer.cornerRadius = 0
        self.view.superview?.clipsToBounds = false
    }

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArray.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SwMonthYearCell") as! SwMonthYearCell
        cell.monthYearLabel.text = dataArray[indexPath.row]
        return cell
    }
 
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    
    // MARK: - Table view delegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        delegate?.delegateMethod(index: indexPath.row)
        self.dismiss(animated: false, completion: nil)
    }
}
