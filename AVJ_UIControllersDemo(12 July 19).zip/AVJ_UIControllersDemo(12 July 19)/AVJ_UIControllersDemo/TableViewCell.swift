//
//  TableViewCell.swift
//  TableCellAnimation
//
//  Created by Azim on 01/12/18.
//  Copyright © 2018 Vijendra. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var imageViewTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var imageViewLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var titleLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var titleTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var descriptionLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var descriptionTrailingConstraint: NSLayoutConstraint!
    
    var flag: Int? {
        didSet {
            if flag == 0 {
                imageViewTrailingConstraint.isActive = false
                imageViewLeadingConstraint.isActive = true
                titleLeadingConstraint.constant = 84
                titleTrailingConstraint.constant = 12
                descriptionLeadingConstraint.constant = 84
                descriptionTrailingConstraint.constant = 12
                UIView.animate(withDuration: 0.7,
                               delay: 0.0,
                               options: .curveEaseInOut,
                               animations: {
                                self.contentView.layoutIfNeeded()
                                },
                               completion: nil)
            } else {
                imageViewLeadingConstraint.isActive = false
                imageViewTrailingConstraint.isActive = true
                titleLeadingConstraint.constant = 28
                titleTrailingConstraint.constant = 68
                descriptionLeadingConstraint.constant = 28
                descriptionTrailingConstraint.constant = 68
                UIView.animate(withDuration: 0.7,
                               delay: 0.0,
                               options: .curveEaseInOut,
                               animations: {
                                self.contentView.layoutIfNeeded()
                                },
                               completion: nil)
            }
        }
    }
    
    var dataDict: [String: String]? {
        didSet {
            imageView1.image = UIImage(named: (dataDict?["profileImage"])!)
            titleLabel.text = dataDict?["title"]
            descriptionLabel.text = dataDict?["description"]
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
