//
//  CustomerDetails+CoreDataClass.m
//  AVJ_UIControllersDemo
//
//  Created by admin on 17/03/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "CustomerDetails+CoreDataClass.h"

@implementation CustomerDetails

@end
