//
//  SnakeCurveView.m
//  BezierZigzagCurve
//
//  Created by admin on 06/07/17.
//  Copyright © 2017 AdityaVJ. All rights reserved.
//

#import "SnakeCurveView.h"

@interface SnakeCurveView ()
@property (nonatomic) CAShapeLayer *shapeLayer;
@property (nonatomic) BOOL anticlockwise;
@end

@implementation SnakeCurveView

- (void)drawRect:(CGRect)rect {
    _pointsArray = [[NSMutableArray alloc]init];
    _timeArray = [[NSMutableArray alloc]init];
    _centresArray = [[NSMutableArray alloc]init];
    [_shapeLayer removeFromSuperlayer];
    if (_draw) {
        float margin = MAX(_padding,20);
        float height = self.frame.size.height-2*margin;
        float width = self.frame.size.width-2*margin;
        int divisor = MAX(_numberOfNodes, 2);
        float separation = MAX(_segmentSeparation, 0);
        float radius = height/(2*divisor);
        float pathLength;
        float timePerUnitLength;
        
        UIBezierPath *path = [[UIBezierPath alloc]init];
        CGPoint A = CGPointMake(margin+width-radius, margin);
        [_pointsArray addObject:[NSValue valueWithCGPoint:A]];
        [path moveToPoint:A];
        
        for(int i = 0; i<divisor; i++) {
            CGPoint One, Two, Three, Centre;
            
            if (i%2==0) {
                One = CGPointMake(margin+radius, margin+(height*i)/divisor);
                Two = CGPointMake(margin+radius, margin+(height*(i+1))/divisor);
                Three = CGPointMake(margin, One.y+(Two.y-One.y)/2);
                Centre = CGPointMake(One.x, One.y+(Two.y-One.y)/2);
                [path addLineToPoint:One];
                [path addArcWithCenter:Centre radius:radius startAngle:-M_PI/2 endAngle:-M_PI*3/2 clockwise:_anticlockwise];
            } else {
                One = CGPointMake(margin+width-radius, margin+(height*i)/divisor);
                Two = CGPointMake(margin+width-radius, margin+(height*(i+1))/divisor);
                Three = CGPointMake(margin+width, One.y+(Two.y-One.y)/2);
                Centre = CGPointMake(One.x, One.y+(Two.y-One.y)/2);
                [path addLineToPoint:One];
                [path addArcWithCenter:Centre radius:radius startAngle:-M_PI/2 endAngle:-M_PI*3/2 clockwise:!_anticlockwise];
            }
            [_pointsArray addObject:[NSValue valueWithCGPoint:One]];
            [_pointsArray addObject:[NSValue valueWithCGPoint:Three]];
            [_pointsArray addObject:[NSValue valueWithCGPoint:Two]];
            [_centresArray addObject:[NSValue valueWithCGPoint:Centre]];
        }
        
        if (_drawEndTail) {
            pathLength = divisor*((width-2*radius)+M_PI*radius)+(width-2*radius);
            CGPoint F;
            if (divisor%2==0) {
                F = CGPointMake(margin+radius, margin+height);
            } else {
                F = CGPointMake(margin+width-radius, margin+height);
            }
            [_pointsArray addObject:[NSValue valueWithCGPoint:F]];
            [path addLineToPoint:F];
        }
        else {
            pathLength = divisor*((width-2*radius)+M_PI*radius);
        }
        
        timePerUnitLength = _animationDuration/pathLength;
        [_timeArray addObject:[NSNumber numberWithFloat:0.0]];
        for (int i=0; i<divisor*3; i=i+3) {
            [_timeArray addObject:[NSNumber numberWithFloat:[_timeArray[i] floatValue]+(width-2*radius)*timePerUnitLength]];
            [_timeArray addObject:[NSNumber numberWithFloat:[_timeArray[i+1] floatValue]+M_PI_2*radius*timePerUnitLength]];
            [_timeArray addObject:[NSNumber numberWithFloat:[_timeArray[i+2] floatValue]+M_PI_2*radius*timePerUnitLength]];
        }
        if (_drawEndTail) {
            [_timeArray addObject:[NSNumber numberWithFloat:[[_timeArray lastObject] floatValue]+(width-2*radius)*timePerUnitLength]];
        }
        [_delegate setTimeArray:_timeArray];
        [_delegate setPointsArray:_pointsArray];
        [_delegate setCentresArray:_centresArray];
        
        [path setLineWidth:MAX(_segmentLength,0.5)];
        
        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.frame = self.frame;
        _shapeLayer.path = path.CGPath;
        _shapeLayer.fillColor = [UIColor clearColor].CGColor;
        [self.layer addSublayer:_shapeLayer];
        if (!_pathColor) {
            _shapeLayer.strokeColor = [UIColor orangeColor].CGColor;
        }
        else {
            _shapeLayer.strokeColor = _pathColor.CGColor;
        }
        _shapeLayer.lineWidth = MAX(_pathWidth,1);
        [_shapeLayer setLineDashPattern:@[[NSNumber numberWithFloat:path.lineWidth],[NSNumber numberWithFloat:path.lineWidth*separation]]];
        _shapeLayer.strokeStart = 0.0;
        
        CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
        anim.duration = MAX(_animationDuration, 0.0);
        anim.fromValue = @(0.0);
        anim.toValue = @(1.0);
        [_shapeLayer addAnimation:anim forKey:@"strokeAnim"];
    }
}


@end
