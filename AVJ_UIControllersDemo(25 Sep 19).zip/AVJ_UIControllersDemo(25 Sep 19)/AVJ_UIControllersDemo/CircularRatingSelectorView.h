//
//  CircularRatingSelectorView.h
//  SpeedBanking
//
//  Created by admin on 02/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircularRatingSelectorView : UIView

@property (nonatomic) float radius;
@property (nonatomic) float cutAngle;
@property (nonatomic) float arcWidth;
@property (nonatomic) float endAngle;
@property (nonatomic) int n;
@property (nonatomic) float f;
@property (nonatomic) int nos;
@end
