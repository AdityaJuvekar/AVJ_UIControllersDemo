//
//  PieChartControllerView.swift
//  PieChart
//
//  Created by admin on 23/03/18.
//  Copyright © 2018 AXIS. All rights reserved.
//

import UIKit

class PieChartControllerView: UIView {

    var valueArray = [CGFloat(98),CGFloat(75),CGFloat(24),CGFloat(10),CGFloat(15),CGFloat(5),CGFloat(30)]
    var colorArray = [UIColor]()
    
    override func draw(_ rect: CGRect) {
        let padding : Float = 0.0
        let length : Float = Float(min(self.frame.size.width, self.frame.size.height))
        //let difference =
        let maxlength = length - 2*padding
        var minlength = (length - 2*padding)/3
        
        if valueArray.count < 4 {
            minlength = (length - 2*padding)/2
        } else if valueArray.count < 7 {
            minlength = (length - 2*padding)/3
        } else {
            minlength = (length - 2*padding)/5
        }
        
        let lengthInterval = (maxlength - minlength)/Float(valueArray.count-1)
        
        for i in 0..<valueArray.count {
            let pieView = PieView.init(frame: CGRect.init(origin: CGPoint(x: CGFloat(padding+Float(i)*lengthInterval/2.0),y: CGFloat(padding+Float(i)*lengthInterval/2.0)), size: CGSize(width: CGFloat(maxlength-Float(i)*lengthInterval),height: CGFloat(maxlength-Float(i)*lengthInterval))))
            pieView.value = valueArray[i]
            
            self.addSubview(pieView)
        
        }
    } 

}
