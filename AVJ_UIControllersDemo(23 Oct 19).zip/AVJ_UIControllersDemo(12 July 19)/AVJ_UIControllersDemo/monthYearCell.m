//
//  monthYearCell.m
//  AVJ_Calendar
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "monthYearCell.h"

@implementation monthYearCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
