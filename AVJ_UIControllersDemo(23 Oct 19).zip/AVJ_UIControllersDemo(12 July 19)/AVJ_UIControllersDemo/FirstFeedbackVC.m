//
//  FirstFeedbackVC.m
//  SpeedBanking
//
//  Created by admin on 02/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import "FirstFeedbackVC.h"
#import "CircularRatingSelectorView.h"
#import "ArcDrawingView.h"
//#import "SecondFeedbackVC.h"

@interface FirstFeedbackVC ()

@property (weak, nonatomic) IBOutlet CircularRatingSelectorView *ratingWheel;
@property (weak, nonatomic) IBOutlet ArcDrawingView *arrowContainerView;
@property (weak, nonatomic) IBOutlet UILabel *centralLabel;

@property (weak, nonatomic) IBOutlet UIImageView *movingImageView;

@property (nonatomic) UIView *arrowImageView;
@property (nonatomic) float viewSize;
@property (nonatomic) float absoluteX;
@property (nonatomic) float absoluteY;
@property (nonatomic) float radius;
@property (nonatomic) float cutAngle;
@property (nonatomic) float arcWidth;
@property (nonatomic) float movingViewSize;
@property (nonatomic) float angle;
@property (nonatomic) float oldAngle;
@property (nonatomic) NSArray *colorArray;
@property (nonatomic) NSNumber *numberOfSlots;
@property (weak, nonatomic) IBOutlet UILabel *numberOfSlotsLabel;
- (IBAction)increaseNumberOfSlots:(UIButton *)sender;
- (IBAction)decreaseNumberOfSlots:(UIButton *)sender;

@property (nonatomic) BOOL isFirstTime;
@end

@implementation FirstFeedbackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _colorArray = @[[UIColor colorWithRed:171.0/255.0 green:45.0/255.0 blue:54.0/255.0 alpha:1],[UIColor colorWithRed:235.0/255.0 green:95.0/255.0 blue:51.0/255.0 alpha:1],[UIColor colorWithRed:241.0/255.0 green:183.0/255.0 blue:49.0/255.0 alpha:1],[UIColor yellowColor],[UIColor colorWithRed:98.0/255.0 green:179.0/255.0 blue:75.0/255.0 alpha:1],[UIColor colorWithRed:53.0/255.0 green:111.0/255.0 blue:60.0/255.0 alpha:1],[UIColor colorWithRed:0.0/255.0 green:148.0/255.0 blue:203.0/255.0 alpha:1],[UIColor blueColor],[UIColor magentaColor],[UIColor purpleColor]];
    _arcWidth = 64;
    _movingViewSize = _arcWidth*1.25;
    _angle = M_PI_2;
    _cutAngle = 0.025;
    _numberOfSlots = [[NSNumber alloc]initWithInt:5];
    _arrowContainerView.endAngle = -M_PI_2 + _cutAngle;
    _ratingWheel.endAngle = -M_PI_2 + _cutAngle;
    _ratingWheel.cutAngle = _cutAngle;
    _ratingWheel.nos = [_numberOfSlots intValue];
    _ratingWheel.arcWidth = _arcWidth;
    _arrowContainerView.cutAngle = _cutAngle;
    _arrowContainerView.nos = [_numberOfSlots intValue];
    _arrowContainerView.arcWidth = _arcWidth;
    _isFirstTime = true;
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (_isFirstTime) {
        _viewSize = MIN(_arrowContainerView.frame.size.width, _arrowContainerView.frame.size.height)/2;
        _radius = _viewSize - _arcWidth/2 - 10;
        _ratingWheel.radius = _radius;
        [_ratingWheel setNeedsDisplay];
        float startPositonAngle = M_PI_2 - 2*_cutAngle;
        CGRect rect = CGRectMake(_arrowContainerView.frame.size.width/2 - _movingViewSize/2 + _radius*cos(startPositonAngle), _arrowContainerView.frame.size.height/2 - _movingViewSize/2 -_radius*sin(startPositonAngle), _movingViewSize, _movingViewSize);
        [_movingImageView setFrame:rect];
        _movingImageView.alpha = 1;
        _arrowImageView = [[UIView alloc]initWithFrame:rect];
        [_arrowContainerView addSubview:_arrowImageView];
        _movingImageView.transform = CGAffineTransformMakeRotation(2*_cutAngle);
        _arrowContainerView.radius = _radius;
        _absoluteX = _movingImageView.center.x - _viewSize;
        _absoluteY = _movingImageView.center.y - _viewSize;
        
        UIPanGestureRecognizer *panRecognisor = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panGestureDetected:)];
        [_arrowImageView addGestureRecognizer:panRecognisor];
        panRecognisor.delegate = self;
        [panRecognisor setMinimumNumberOfTouches:1];
    }
    _isFirstTime = false;
}

- (void)panGestureDetected:(UIPanGestureRecognizer *)recognizer {
    UIGestureRecognizerState state = [recognizer state];
    if (state == UIGestureRecognizerStateBegan || state == UIGestureRecognizerStateChanged)
    {
        CGPoint translation = [recognizer translationInView:recognizer.view];
        [recognizer.view setTransform:CGAffineTransformTranslate(recognizer.view.transform, translation.x, translation.y)];
        [recognizer setTranslation:CGPointZero inView:recognizer.view];
        _absoluteX += translation.x;
        _absoluteY += translation.y;
        
        if (_absoluteX>0) {
            _angle = atan(-_absoluteY/_absoluteX);
            [self validateAngle];
        }
        else if (_absoluteX<0){
            _angle = atan(-_absoluteY/_absoluteX)-M_PI;
            [self validateAngle];
        }
        else {
        }
    }
    if (state == UIGestureRecognizerStateEnded) {
        [recognizer.view setFrame:_movingImageView.frame];
        [recognizer setTranslation:CGPointZero inView:recognizer.view];
        _absoluteX = _movingImageView.center.x - _viewSize;
        _absoluteY = _movingImageView.center.y - _viewSize;
    }
}

-(void)validateAngle {
    if (!isnan(_angle) && fabsf(_angle-_oldAngle)>0.02) {
        [self drawArcForCurrentAngle];
        _oldAngle = _angle;
    }
}

-(void)drawArcForCurrentAngle {
    [_movingImageView setCenter:CGPointMake(_radius*cos(_angle)+ _viewSize, -_radius*sin(_angle)+ _viewSize)];
    _movingImageView.transform = CGAffineTransformMakeRotation(-_angle+M_PI_2);
    _arrowContainerView.endAngle = -_angle;
    _ratingWheel.endAngle = -_angle;
    _arrowContainerView.colorArray = _colorArray;
    int n = (-_angle+M_PI_2)/(2*M_PI/[_numberOfSlots intValue]);
    float f = fmodf((-_angle+M_PI_2), (2*M_PI/[_numberOfSlots intValue]));
    _arrowContainerView.n = n;
    _arrowContainerView.f = f;
    _ratingWheel.n = n;
    _ratingWheel.f = f;
    [_arrowContainerView setNeedsDisplay];
    [_ratingWheel setNeedsDisplay];
    if (f>2*_cutAngle) {
        _centralLabel.text = [NSString stringWithFormat:@"%d",n+1];
    }
}

- (IBAction)increaseNumberOfSlots:(UIButton *)sender {
    int i = [_numberOfSlotsLabel.text intValue];
    if (i<_colorArray.count) {
        _numberOfSlots = [[NSNumber alloc] initWithInt:++i];
        [self changeNumberOfSlots];
    }
}

- (IBAction)decreaseNumberOfSlots:(UIButton *)sender {
    int i = [_numberOfSlotsLabel.text intValue];
    if (i>1) {
        _numberOfSlots = [[NSNumber alloc] initWithInt:--i];
        [self changeNumberOfSlots];
    }
}

-(void)changeNumberOfSlots {
    _numberOfSlotsLabel.text = [NSString stringWithFormat:@"%@",_numberOfSlots];
    _ratingWheel.nos = [_numberOfSlots intValue];
    _arrowContainerView.nos = [_numberOfSlots intValue];
    [self drawArcForCurrentAngle];
}

@end
