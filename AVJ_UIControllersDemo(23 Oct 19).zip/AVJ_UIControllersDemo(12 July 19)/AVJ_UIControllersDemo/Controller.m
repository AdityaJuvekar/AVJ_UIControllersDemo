//
//  Controller.m
//  AVJ_Calendar
//
//  Created by Apple on 07/05/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "Controller.h"
#import "CalendarVC.h"
#import "AVJ_UIControllersDemo-Swift.h"

@interface Controller ()<AVJCalendarDelegate>
@property (weak, nonatomic) IBOutlet UIView *calenderView;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (weak, nonatomic) IBOutlet UIPickerView *startingWeekDayPicker;

@property (nonatomic) SwiftCalendarVC *cvc; //for swift
//@property (nonatomic) CalendarVC *cvc; //for objc
@property (nonatomic) NSMutableArray *dateArray;
@property (nonatomic) NSArray *weekDaysArray;
@property (nonatomic) NSArray *colorsArray;
- (IBAction)addDateToArray:(UIButton *)sender;
- (IBAction)clearDateArray:(UIButton *)sender;

@end

@implementation Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    _dateArray = [[NSMutableArray alloc]init];
    _weekDaysArray = @[@"Mon",@"Tue",@"Wed",@"Thu",@"Fri",@"Sat",@"Sun"];
    _datePicker.datePickerMode = UIDatePickerModeDate;
    _colorsArray = @[[UIColor greenColor],[UIColor cyanColor],[UIColor grayColor]];
    _startingWeekDayPicker.transform = CGAffineTransformRotate(_startingWeekDayPicker.transform, M_PI_2);
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
//    _cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"CalendarVC"]; //for objc
    _cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"SwiftCalendarVC"]; //for swift
    _cvc.delegate = self;
    [self addChildViewController:_cvc];
    [_calenderView addSubview:_cvc.view];
    _cvc.view.frame = _calenderView.bounds;
    [_cvc didMoveToParentViewController:self];
    
    NSDateComponents *weekdaycomponents = [[NSDateComponents alloc]init];
    weekdaycomponents.month = 7;
    weekdaycomponents.year = 2019;
    weekdaycomponents.day = 25;
    NSCalendar *calender = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *date = [calender dateFromComponents:weekdaycomponents];
    [_cvc markDatesFromArrayWithDates:@[@17,date] withColors:_colorsArray]; //for swift
//    [_cvc markDatesFromArray:@[@13,date] withColors:_colorsArray]; //for objc
}

-(void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:_calenderView.bounds];
    _calenderView.layer.shadowColor = [UIColor blackColor].CGColor;
    _calenderView.layer.shadowOpacity = 0.5;
    _calenderView.layer.shadowOffset = CGSizeMake(1, 1);
    _calenderView.layer.masksToBounds = NO;
    _calenderView.layer.shadowPath = shadowPath.CGPath;
}

-(void)dateSelected:(NSDate *)selectedDate {
    NSLog(@"Selected date : %@",selectedDate);
    [_datePicker setDate:selectedDate animated:true];
}

-(void)monthChangedWithNewDate:(NSDate *)date {
    NSLog(@"New month: %@",date);
    [_datePicker setDate:date animated:true];
}

- (IBAction)addDateToArray:(UIButton *)sender {
    [_dateArray addObject:_datePicker.date];
    [_cvc markDatesFromArrayWithDates:_dateArray withColors:_colorsArray]; //swift
//    [_cvc markDatesFromArray:_dateArray withColors:_colorsArray]; //objc
}

- (IBAction)clearDateArray:(UIButton *)sender {
    [_dateArray removeAllObjects];
    [_cvc markDatesFromArrayWithDates:_dateArray withColors:@[[UIColor clearColor]]]; //swift
//    [_cvc markDatesFromArray:_dateArray withColors:@[[UIColor clearColor]]]; //objc
}

- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return 7;
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = _weekDaysArray[row];
    label.transform = CGAffineTransformRotate(label.transform, -M_PI_2);
    return label;
}

-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 44;
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    _cvc.indexOfFirstWeekDay = row;
}

@end
