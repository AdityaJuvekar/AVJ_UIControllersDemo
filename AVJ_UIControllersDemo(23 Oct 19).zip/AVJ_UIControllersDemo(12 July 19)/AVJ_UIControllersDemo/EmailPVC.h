//
//  EmailPVC.h
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EmailPVCDelegate <NSObject>
@required -(void)dismissPopUp;
@required -(void)setEmailAddress:(NSString*)emailID;
@required -(void)captureAndSetImage;
@end

@interface EmailPVC : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;
@property (weak, nonatomic) IBOutlet UITextField *inputField;

- (IBAction)cancelClicked:(UIButton *)sender;
- (IBAction)confirmClicked:(UIButton *)sender;

@property (nonatomic) NSString* email;
@property (weak,nonatomic) id delegate;
@end
