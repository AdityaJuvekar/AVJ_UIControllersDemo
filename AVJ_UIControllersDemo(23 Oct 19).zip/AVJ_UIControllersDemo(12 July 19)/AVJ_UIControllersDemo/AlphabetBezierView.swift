//
//  AlphabetBezierView.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 07/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class AlphabetBezierView: UIView {

    var distanceFactor: CGFloat = 1.0
    var pathsArray = [UIBezierPath]()
    var oldTimeStr = String()
    var currentTimeStr = String()
    var changedNumberIndexes = [Int]()
    
    override func draw(_ rect: CGRect) {
        pathsArray.removeAll()
        
        if oldTimeStr.count > 0 {
            for i in 0..<oldTimeStr.count {
                if oldTimeStr[i] != currentTimeStr[i] {
                    changedNumberIndexes.append(i)
                }
            }
        }
        
        let fontSize: Float = 121
        
        let font = UIFont(name: "HelveticaNeue-CondensedBold", size: CGFloat(fontSize))!

        var unichars = [UniChar](currentTimeStr.utf16)
        var oldUnichars = [UniChar](oldTimeStr.utf16)
        
        var glyphs = [CGGlyph](repeating: 0, count: unichars.count)
        var oldGlyphs = [CGGlyph](repeating: 0, count: oldUnichars.count)
        
        let gotGlyphs = CTFontGetGlyphsForCharacters(font, &unichars, &glyphs, unichars.count)
        CTFontGetGlyphsForCharacters(font, &oldUnichars, &oldGlyphs, oldUnichars.count)
        
        if gotGlyphs {
            
            for i in 0..<glyphs.count {
                let cgpath = CTFontCreatePathForGlyph(font, (changedNumberIndexes.contains(i) && distanceFactor <= 1) ? oldGlyphs[i] : glyphs[i], nil)!
                var inverse = CGAffineTransform(scaleX: 1, y: -1).translatedBy(x: ((i>0) ? pathsArray[i-1].cgPath.boundingBox.origin.x : 50) + ((i>0) ? pathsArray[i-1].cgPath.boundingBox.width : 0) + CGFloat(sqrtf(fontSize))*(changedNumberIndexes.contains(i)
                    ? distanceFactor : 1), y: -cgpath.boundingBox.height - ((i==2) ? (50 + (pathsArray[i-1].cgPath.boundingBox.height - cgpath.boundingBox.height)/2) : 50))
                let path = UIBezierPath(cgPath: cgpath.copy(using: &inverse)!)
                pathsArray.append(path)
            }
            
            let timePath = UIBezierPath()
            for path in pathsArray {
                timePath.append(path)
            }
            timePath.append(UIBezierPath(rect: self.bounds))
            
            let maskLayer = CAShapeLayer()
            maskLayer.fillRule = CAShapeLayerFillRule.evenOdd
            maskLayer.fillMode = CAMediaTimingFillMode.forwards
            maskLayer.path = timePath.cgPath
            
            self.layer.mask = maskLayer
        }
    }

}
