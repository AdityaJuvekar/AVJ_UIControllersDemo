//
//  MobilePVC.h
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MobilePVCDelegate <NSObject>
@required -(void)dismissPopUp;
@required -(void)setMobileNumber:(NSString*)number;
@required -(void)captureAndSetImage;
@end

@interface MobilePVC : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;
@property (weak, nonatomic) IBOutlet UITextField *inputField;

- (IBAction)cancelClicked:(UIButton *)sender;
- (IBAction)confirmClicked:(UIButton *)sender;

@property (strong,nonatomic) NSString *mobile;
@property (weak,nonatomic) id delegate;
@end
