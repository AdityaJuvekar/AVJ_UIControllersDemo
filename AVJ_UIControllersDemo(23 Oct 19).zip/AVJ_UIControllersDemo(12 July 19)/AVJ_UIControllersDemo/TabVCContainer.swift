//
//  TabVCContainer.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 23/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class TabVCContainer: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func displayTimer(_ sender: UIButton) {
        let negativeTimer = self.storyboard?.instantiateViewController(withIdentifier: "NegativeClockVC")
        self.present(negativeTimer!, animated: true, completion: nil)
    }
    
    
}
