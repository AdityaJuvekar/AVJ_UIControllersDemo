//
//  SwMonthYearCell.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 21/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class SwMonthYearCell: UITableViewCell {
    
    @IBOutlet weak var monthYearLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
