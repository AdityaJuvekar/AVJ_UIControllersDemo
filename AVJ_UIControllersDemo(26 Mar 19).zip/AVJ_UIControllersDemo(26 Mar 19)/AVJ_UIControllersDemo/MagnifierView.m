//
//  MagnifierView.m
//  AVJ_Calendar
//
//  Created by Apple on 16/05/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "MagnifierView.h"

@implementation MagnifierView

- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame radius:Radius];
}

- (id)initWithFrame:(CGRect)frame radius:(int)r {
    int radius = r;
    
    if ((self = [super initWithFrame:CGRectMake(0, 0, radius, radius)])) {
        //Make the layer circular.
        self.layer.cornerRadius = radius / 2;
        self.layer.masksToBounds = YES;
    }
    
    return self;
}

- (void)setTouchPoint:(CGPoint)pt {
    _touchPoint = pt;
    // whenever touchPoint is set, update the position of the magnifier (to just above what's being magnified)
    self.center = CGPointMake(pt.x, pt.y);
}

- (CGPoint)getTouchPoint {
    return _touchPoint;
}

- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGRect bounds = self.bounds;
    CGImageRef mask = [UIImage imageNamed: @"lens-mask.png"].CGImage;
    UIImage *glass = [UIImage imageNamed: @"lens.png"];
    float magnification = 1.3;
    
    CGContextSaveGState(context);
    CGContextClipToMask(context, bounds, mask);
    CGContextFillRect(context, bounds);
    CGContextScaleCTM(context, magnification, magnification);
    
    //draw your subject view here
    CGContextTranslateCTM(context,1*(self.frame.size.width*0.5),1*(self.frame.size.height*0.5));
    //CGContextScaleCTM(context, 1.5, 1.5);
    CGContextTranslateCTM(context,-1*(_touchPoint.x)-Radius*(magnification-1)/2,-1*(_touchPoint.y)-Radius*(magnification-1)/2);
    [self.viewToMagnify.layer renderInContext:context];
    
    CGContextRestoreGState(context);
    [glass drawInRect: bounds];
}


@end
