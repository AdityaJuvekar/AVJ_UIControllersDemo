//
//  ChequePVC.m
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "ChequePVC.h"

@interface ChequePVC ()
@property BOOL crosschecker;
@end

@implementation ChequePVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _cancelButton.layer.cornerRadius = 4;
    _confirmButton.layer.cornerRadius = 4;
    _cancelButton.clipsToBounds = YES;
    _confirmButton.clipsToBounds = YES;
    _crosschecker = _chequeBookIsRequired;
    if (_chequeBookIsRequired) {
        _YNSegment.selectedSegmentIndex = 0;
    }
    else {
        _YNSegment.selectedSegmentIndex = 1;
    }
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.superview.layer.cornerRadius = 0;
    self.view.superview.clipsToBounds = NO;
}

- (IBAction)segmentControllerPressed:(UISegmentedControl *)sender {
    switch (sender.selectedSegmentIndex) {
        case 0:
            _chequeBookIsRequired = YES;
            break;
        
        case 1:
            _chequeBookIsRequired = NO;
            break;
            
        default:
            break;
    }
}

- (IBAction)cancelClicked:(UIButton *)sender {
    [_delegate dismissPopUp];
}



- (IBAction)confirmClicked:(UIButton *)sender {
    if (!_chequeBookIsRequired == _crosschecker) {
        [_delegate whetherChequeRequired:_chequeBookIsRequired];
    }
    [_delegate dismissPopUp];
}

-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString*)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];
                             
                         }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}
















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
@end
