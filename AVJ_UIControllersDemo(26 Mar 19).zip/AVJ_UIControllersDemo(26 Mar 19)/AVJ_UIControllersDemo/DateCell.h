//
//  DateCell.h
//  AVJ_Calendar
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MarkerView.h"

@interface DateCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet MarkerView *markingView;
@property (nonatomic) BOOL mark;
@property (nonatomic) BOOL select;
@property (nonatomic) NSDate *date;
@property (nonatomic) UIColor *markingColor;
@property (nonatomic) UIColor *selectionColor;
@end
