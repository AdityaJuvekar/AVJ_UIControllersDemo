//
//  SnakeCurveView.h
//  BezierZigzagCurve
//
//  Created by admin on 06/07/17.
//  Copyright © 2017 AdityaVJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SnakeCurveView : UIView

@property (nonatomic) BOOL draw;

@property (nonatomic) int numberOfNodes;
@property (nonatomic) float animationDuration;

@property (nonatomic) float padding;
@property (nonatomic) float segmentLength;
@property (nonatomic) float pathWidth;
@property (nonatomic) float segmentSeparation;
@property (nonatomic) UIColor *pathColor;

@property (nonatomic) BOOL drawEndTail;

@property (nonatomic) NSMutableArray *pointsArray;
@property (nonatomic) NSMutableArray *timeArray;
@property (nonatomic) NSMutableArray *centresArray;

@property (weak, nonatomic) id delegate;

@end
