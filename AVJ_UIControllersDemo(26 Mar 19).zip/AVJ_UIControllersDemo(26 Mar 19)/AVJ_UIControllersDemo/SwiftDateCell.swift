//
//  SwiftDateCell.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 18/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class SwiftDateCell: UICollectionViewCell {
    @IBOutlet weak var markerView: SwiftMarkerView!
    @IBOutlet weak var dateLabel: UILabel!
    var date: Date?
    var markingColor = UIColor()
    var selectionColor = UIColor()
    var mark = false {
        didSet {
            markerView.markingColor = nil
            if mark {
                markerView.markingColor = markingColor
            }
            markerView.setNeedsDisplay()
        }
    }
    
    var select = false {
        didSet {
            markerView.selectionColor = nil
            if select {
                markerView.selectionColor = selectionColor
            }
            markerView.setNeedsDisplay()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
