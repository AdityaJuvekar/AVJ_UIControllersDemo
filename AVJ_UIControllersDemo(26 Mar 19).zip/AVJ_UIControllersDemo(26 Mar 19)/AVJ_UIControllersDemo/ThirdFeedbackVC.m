//
//  ThirdFeedbackVC.m
//  SpeedBanking
//
//  Created by admin on 14/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import "ThirdFeedbackVC.h"
#import "ArrowView.h"
@import EventKit;

@interface ThirdFeedbackVC ()

@property (weak, nonatomic) IBOutlet UIView *ratingView;
@property (weak, nonatomic) IBOutlet ArrowView *leftTriangleView;
@property (weak, nonatomic) IBOutlet ArrowView *rightTriangleView;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;

- (IBAction)upButtonPressed:(UIButton *)sender;
- (IBAction)downButtonPressed:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *zerothViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *forthViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *fifthViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *sixthViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *seventhViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *eighthViewWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *ninthViewWidth;

@property (weak, nonatomic) IBOutlet UILabel *label0;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label3;
@property (weak, nonatomic) IBOutlet UILabel *label4;
@property (weak, nonatomic) IBOutlet UILabel *label5;
@property (weak, nonatomic) IBOutlet UILabel *label6;
@property (weak, nonatomic) IBOutlet UILabel *label7;
@property (weak, nonatomic) IBOutlet UILabel *label8;
@property (weak, nonatomic) IBOutlet UILabel *label9;

@property NSArray *colorArray;
@property float indicatorWidth;
@property int currentIndex;
@property NSNumber *numberOfSlots;
@property NSArray *widthsArray;
@property NSArray *labelsArray;
@property BOOL isFirstTime;

@end

@implementation ThirdFeedbackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _colorArray = @[[UIColor colorWithRed:233.0/255.0 green:63.0/255.0 blue:51.0/255.0 alpha:1],[UIColor colorWithRed:245.0/255.0 green:179.0/255.0 blue:51.0/255.0 alpha:1],[UIColor colorWithRed:53.0/255.0 green:111.0/255.0 blue:60.0/255.0 alpha:1]];
    _widthsArray = @[_zerothViewWidth,_firstViewWidth,_secondViewWidth,_thirdViewWidth,_forthViewWidth,_fifthViewWidth,_sixthViewWidth,_seventhViewWidth,_eighthViewWidth,_ninthViewWidth];
    _labelsArray = @[_label0,_label1,_label2,_label3,_label4,_label5,_label6,_label7,_label8,_label9];
    [self setupGestureRecognizersForView:_ratingView];
    _leftTriangleView.isRight = FALSE;
    _leftTriangleView.arrowColor = [UIColor lightGrayColor];
    _rightTriangleView.isRight = TRUE;
    _rightTriangleView.arrowColor = [UIColor lightGrayColor];
    [self clearBlockColorsForView:_ratingView];
    _currentIndex = -1;
    _numberOfSlots = [[NSNumber alloc]initWithInt:6];
    _isFirstTime = true;
    
}

-(void)setIndicatorWidth {
    _indicatorWidth = _ratingView.frame.size.width/([_numberOfSlots intValue] +1);
    for (int i=0; i<_widthsArray.count; i++) {
        if(i<=([_numberOfSlots intValue])) {
            ((NSLayoutConstraint*)_widthsArray[i]).constant = (_ratingView.frame.size.width-2*([_numberOfSlots intValue]+2))/([_numberOfSlots intValue] +1);
            ((UILabel*)_labelsArray[i]).transform = CGAffineTransformIdentity;
        }
        else {
            ((NSLayoutConstraint*)_widthsArray[i]).constant = 0;
            ((UILabel*)_labelsArray[i]).transform = CGAffineTransformScale(((UILabel*)_labelsArray[i]).transform, 0, 1);
        }
    }
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self setIndicatorWidth];
//    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//    dateFormatter.dateFormat = @"dd-MM-yyyy HH:mm:ss";
//    NSDate *startDate = [dateFormatter dateFromString:@"10-10-2018 18:55:00 "];
//    [self createEventInCalendarWithTitle:@"Test Date" fromDate:startDate toDate:[startDate dateByAddingTimeInterval:3600]];
}

-(void)setupGestureRecognizersForView:(UIView*)view {
    UIPanGestureRecognizer *panRecognisor = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(gestureDetected:)];
    [view addGestureRecognizer:panRecognisor];
    panRecognisor.delegate = self;
    [panRecognisor setMinimumNumberOfTouches:0];
    UITapGestureRecognizer *tapRecognisor = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(gestureDetected:)];
    [view addGestureRecognizer:tapRecognisor];
    tapRecognisor.delegate = self;
}

-(void)gestureDetected:(UIPanGestureRecognizer *)recognizer {
    CGPoint touchPoint = [recognizer locationInView:recognizer.view];
    float distance = touchPoint.x;
    int index = distance/_indicatorWidth;
    if (index!=_currentIndex && index<=[_numberOfSlots intValue] && index>=0) {
        _currentIndex = index;
        [self clearBlockColorsForView:recognizer.view];
        [self paintBlocksForView:recognizer.view tillIndex:index];
    }
}

-(void)clearBlockColorsForView:(UIView*)view {
    _leftTriangleView.transform = CGAffineTransformIdentity;
    _leftTriangleView.arrowColor = [UIColor lightGrayColor];
    [_leftTriangleView setNeedsDisplay];
    for (int i=1; i<=[_numberOfSlots intValue]+1; i++) {
        UIView *tempView = [view viewWithTag:i*10];
        [tempView setBackgroundColor:[UIColor lightGrayColor]];
        UILabel *tempLabel = (UILabel*)[tempView viewWithTag:7];
        [tempLabel setTextColor:[UIColor blackColor]];
        if (!CGAffineTransformIsIdentity(tempView.transform)) {
            tempView.transform = CGAffineTransformIdentity;
            [tempLabel setFont:[UIFont fontWithName:@"Courier" size:22]];
        }
    }
    _rightTriangleView.transform = CGAffineTransformIdentity;
    _rightTriangleView.arrowColor = [UIColor lightGrayColor];
    [_rightTriangleView setNeedsDisplay];
}

-(void)paintBlocksForView:(UIView*)view tillIndex:(int)index {
    int j = 0;
    if (index>[_numberOfSlots intValue]*(2.0/3.0)) {
        j=2;
    }
    else if (index>[_numberOfSlots intValue]*(1.0/3.0)) {
        j=1;
    }
    _leftTriangleView.arrowColor = _colorArray[j];
    [_leftTriangleView setNeedsDisplay];
    
    for (int i=0; i<=index; i++) {
        UIView *tempView = [view viewWithTag:(i+1)*10];
        [tempView setBackgroundColor:_colorArray[j]];
        
        UILabel *tempLabel = (UILabel*)[tempView viewWithTag:7];
        [tempLabel setTextColor:[UIColor whiteColor]];
    }
    
    if (index<=0) {
        [self performSelector:@selector(transformLeftTrianle) withObject:self afterDelay:.007];
    }
    else if (index>=[_numberOfSlots intValue]) {
        _rightTriangleView.arrowColor = _colorArray[2];
        [_rightTriangleView setNeedsDisplay];
        [self performSelector:@selector(transformRightTrianle) withObject:self afterDelay:.007];
    }
    
    UIView *finalView = [view viewWithTag:(index+1)*10];
    if (CGAffineTransformIsIdentity(finalView.transform)) {
        finalView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1, 1+(index+1)*0.075);
        [((UILabel*)[finalView viewWithTag:7]) setFont:[UIFont fontWithName:@"Courier" size:25]];
    }
}

-(void)transformLeftTrianle {
    _leftTriangleView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1, 1.2);
}

-(void)transformRightTrianle {
    _rightTriangleView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1, 1.0 +(.07*[_numberOfSlots intValue]));
}


- (IBAction)upButtonPressed:(UIButton *)sender {
    int i = [_numberLabel.text intValue];
    if (i<_widthsArray.count-1) {
        _numberOfSlots = [[NSNumber alloc] initWithInt:++i];
        [self resetForNewSlotNumber];
    }
}

- (IBAction)downButtonPressed:(UIButton *)sender {
    int i = [_numberLabel.text intValue];
    if (i>4) {
        _numberOfSlots = [[NSNumber alloc] initWithInt:--i];
        [self resetForNewSlotNumber];
    }
}

-(void)resetForNewSlotNumber {
    [self setIndicatorWidth];
    [self changeNumberOfSlots];
    [self clearBlockColorsForView:_ratingView];
}

-(void)changeNumberOfSlots {
    _numberLabel.text = [NSString stringWithFormat:@"%@",_numberOfSlots];
    for (int i=[_numberOfSlots intValue]; i<=8; i++) {
        UIView *tempView = [_ratingView viewWithTag:i*10];
        [tempView setBackgroundColor:[UIColor lightGrayColor]];
        UILabel *tempLabel = (UILabel*)[tempView viewWithTag:7];
        [tempLabel setTextColor:[UIColor blackColor]];
        if (!CGAffineTransformIsIdentity(tempView.transform)) {
            tempView.transform = CGAffineTransformIdentity;
            [tempLabel setFont:[UIFont fontWithName:@"Courier" size:22]];
        }
    }
}



-(void)createEventInCalendarWithTitle:(NSString*) title fromDate:(NSDate*) eventStartDate toDate:(NSDate*) eventEndDate {
    
    EKEventStore *store = [[EKEventStore alloc] init];
    __block BOOL eventAlreadyPresent = false;
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError * _Nullable error) {
        if (granted && error == nil) {
            NSArray *eventIDsArray = [self fetchEventIDsFromPlist];
            for (NSString *eventID in eventIDsArray) {
                EKEvent *event = [store eventWithIdentifier:eventID];
                NSLog(@"Event title: %@, event date: %@",event.title, event.startDate);
                if ([event.title isEqualToString: title] && event.startDate == eventStartDate) {
                    eventAlreadyPresent = true;
                    break;
                }
            }
            
            if (eventAlreadyPresent) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSLog(@"Event already added to calendar");
                    return;
                });
            } else {
                EKEvent *event = [EKEvent eventWithEventStore:store];
                event.title = title;
                event.calendar = store.defaultCalendarForNewEvents; //this will return default calendar from device calendars
                event.startDate = eventStartDate;
                event.endDate = eventEndDate;
                
                NSError *calendarError;
                [store saveEvent:event span:EKSpanThisEvent error:&calendarError];
                if (calendarError == nil) {
                    NSString *identifier = event.eventIdentifier;
                    [self saveEventIDtoPlist:identifier];
                    NSLog(@"Event successfully added to calendar");
                } else {
                    NSLog(@"Failed to save event with error : %@",calendarError);
                }
            }
        } else {
            //we have error in getting access to device calendar
            NSLog(@"error = %@",[error localizedDescription]);
        }
    }];
}

-(void)saveEventIDtoPlist:(NSString*) eventID {
    NSArray *array = [self fetchEventIDsFromPlist];
    if (![array containsObject:eventID]) {
        NSMutableArray *idArray = [NSMutableArray arrayWithArray:array];
        [idArray addObject:eventID];
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"CalendarEvents.plist"];
        NSLog(@"Filepath: %@",filePath);
        [idArray writeToFile:filePath atomically:true];
    }
}

-(NSArray*)fetchEventIDsFromPlist {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"CalendarEvents.plist"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSArray *eventsArray;
    if ([fileManager fileExistsAtPath: filePath]) {
        eventsArray = [[NSArray alloc] initWithContentsOfFile: filePath];
    } else {
        eventsArray = [NSArray array];
    }
    return eventsArray;
}

@end
