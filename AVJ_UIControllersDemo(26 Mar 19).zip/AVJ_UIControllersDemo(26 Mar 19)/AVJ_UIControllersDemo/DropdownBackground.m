//
//  DropdownBackground.m
//  SpeedBanking
//
//  Created by admin on 04/10/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import "DropdownBackground.h"

@implementation DropdownBackground

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    UIImageView *popoverBackgroundImageView = [[UIImageView alloc] initWithImage:[self createBackgroundImage]];
    [self addSubview:popoverBackgroundImageView];
    popoverBackgroundImageView.frame = self.bounds;
    self.layer.shadowColor = [[UIColor clearColor] CGColor];
    return self;
}

+(CGFloat)arrowBase {
    return 0;
}

+(CGFloat)arrowHeight {
    return 0;
}

+(UIEdgeInsets)contentViewInsets {
    return UIEdgeInsetsZero;
}

-(UIPopoverArrowDirection)arrowDirection {
    return UIPopoverArrowDirectionUp;
}

-(CGFloat)arrowOffset {
    return 0;
}

-(void)setArrowOffset:(CGFloat)arrowOffset {
    
}

- (void)drawRect:(CGRect)rect {
    self.layer.cornerRadius = 0;
    self.clipsToBounds = NO;
    self.layer.shadowColor = [UIColor clearColor].CGColor;
}

-(void)setArrowDirection:(UIPopoverArrowDirection)arrowDirection {
    
}

-(UIImage*)createBackgroundImage {
    UIView *blankView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    blankView.backgroundColor = [UIColor whiteColor];
    UIGraphicsBeginImageContextWithOptions(blankView.frame.size, true, 0.0);
    [blankView.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIImage *popoverBackgroundImage = [image resizableImageWithCapInsets:UIEdgeInsetsMake(20, 20, 20, 20)];
    
    return popoverBackgroundImage;
}

@end
