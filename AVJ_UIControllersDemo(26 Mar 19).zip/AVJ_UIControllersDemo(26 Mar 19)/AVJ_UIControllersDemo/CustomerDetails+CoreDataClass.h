//
//  CustomerDetails+CoreDataClass.h
//  AVJ_UIControllersDemo
//
//  Created by admin on 17/03/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomerDetails : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CustomerDetails+CoreDataProperties.h"
