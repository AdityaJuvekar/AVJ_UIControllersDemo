//
//  ProgressBarVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 17/01/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

func RGBCOLOR(_ red: CGFloat, _ green: CGFloat, _ blue: CGFloat) -> UIColor {
    return UIColor(red: red/255.0,
                   green: green/255.0,
                   blue: blue/255.0,
                   alpha: 1.0)
}

let GradientBlue = RGBCOLOR(85, 82, 199)
let GradientPurple = RGBCOLOR(42, 134, 230)

class ProgressBarVC: UIViewController {

    @IBOutlet weak var progressBar: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stopProgressAnimation()
//        animateProgressBar()
    }
    
    
    @IBAction func startStopProgressAnimation(_ sender: UIButton) {
        if sender.tag == 0 {
            animateProgressBar()
        } else {
            stopProgressAnimation()
        }
    }
    
    func animateProgressBar() {
        for i in 1...13 {
            let fragView = progressBar.viewWithTag(i)
            UIView.animate(withDuration: 0.4,
                            delay: TimeInterval(Double(i)*0.07),
                            options: [.repeat,.autoreverse],
                            animations: {
                                fragView?.alpha = 1
                                fragView?.transform = CGAffineTransform.init(scaleX: 1, y: 1.3)
                                //fragView?.backgroundColor = GradientPurple
            })
            UIView.animate(withDuration: 0.05) {
                fragView?.backgroundColor = GradientPurple
            }
        }
    }
    
    func stopProgressAnimation() {
        for i in 1...13 {
            let fragView = progressBar.viewWithTag(i)
            fragView?.layer.removeAllAnimations()
            fragView?.backgroundColor = GradientBlue
            fragView?.alpha = 0
            fragView?.transform = CGAffineTransform.identity
        }
    }
    

}
