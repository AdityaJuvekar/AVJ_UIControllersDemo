//
//  ColorPickerVC.m
//  AVJ_UIControllersDemo
//
//  Created by admin on 22/01/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "ColorPickerVC.h"
#import "ColorView.h"


@interface ColorPickerVC ()
@property (weak, nonatomic) IBOutlet ColorView *pickerView;
@property (weak, nonatomic) IBOutlet UIView *selectedColorView;
@property (nonatomic) float viewHeight;
@end

@implementation ColorPickerVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupGestureRecognizersForView:_pickerView];
    _selectedColorView.layer.cornerRadius = 8;
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    _viewHeight = _pickerView.frame.size.height;
}

-(void)setupGestureRecognizersForView:(UIView*)view {
    UIPanGestureRecognizer *panRecognisor = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(gestureDetected:)];
    [view addGestureRecognizer:panRecognisor];
    panRecognisor.delegate = self;
    [panRecognisor setMinimumNumberOfTouches:0];
    UITapGestureRecognizer *tapRecognisor = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(gestureDetected:)];
    [view addGestureRecognizer:tapRecognisor];
    tapRecognisor.delegate = self;
}

-(void)gestureDetected:(UIPanGestureRecognizer *)recognizer {
    CGPoint touchPoint = [recognizer locationInView:recognizer.view];
    float distance = touchPoint.y;
    float location = distance/_viewHeight;
    UIColor *color;
    if (location<=0.5) {
        location /= 0.5;
        color = [UIColor colorWithRed:location green:0 blue:1-location alpha:1];
        
    } else {
        location = (location - 0.5)/0.5;
        color = [UIColor colorWithRed:1-location green:location blue:0 alpha:1];
    }
    [_selectedColorView setBackgroundColor:color];
    _delegate.buttonColor = color;
    [_delegate setButtonTint];
}

@end
