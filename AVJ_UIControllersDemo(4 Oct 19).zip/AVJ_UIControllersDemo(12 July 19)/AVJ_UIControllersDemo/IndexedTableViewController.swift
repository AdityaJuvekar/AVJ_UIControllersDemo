//
//  IndexedTableViewController.swift
//  TableCellAnimation
//
//  Created by Azim on 01/12/18.
//  Copyright © 2018 Vijendra. All rights reserved.
//

import UIKit

class IndexedTableViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var profileImageView = UIImageView()
    let thickness: CGFloat = 30
    let paddingForIndexView: CGFloat = 20
    
    let array = [["title": "What is Lorem Ipsum?", "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry.", "profileImage": "avatar.png"], ["title": "Where does it come from?", "description": "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.", "profileImage": "businessman.png"], ["title": "Why do we use it?", "description": "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.", "profileImage": "silhouette-man.png"], ["title": "Dummy 1", "description": "No description", "profileImage": "businessman.png"], ["title": "Where can I get some?", "description": "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.", "profileImage": "user.png"], ["title": "Donate", "description": "If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.", "profileImage": "avatar.png"], ["title": "The standard Lorem Ipsum passage, used since the 1500s", "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.", "profileImage": "dog-profile.png"], ["title": "de Finibus Bonorum et Malorum", "description": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.", "profileImage": "businessman.png"], ["title": "Dummy 2", "description": "No description", "profileImage": "user.png"], ["title": "1914 translation by H. Rackham", "description": "But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.", "profileImage": "silhouette-woman.png"],["title": "Definition - What does Lorem Ipsum mean?", "description": "Lorem ipsum, in graphical and textual context, refers to filler text that is placed in a document or visual presentation. Lorem ipsum is derived from the Latin \"dolorem ipsum\" roughly translated as \"pain itself.\" Lorem ipsum presents the sample font and orientation of writing on Web pages and other software applications where content is not the main concern of the developer.", "profileImage": "silhouette-woman.png"],["title": "Techopedia explains Lorem Ipsum", "description": "Lorem ipsum is the nonsense filler text that typically demonstrates the font and style of a text in a document or visual demonstration.", "profileImage": "dog-profile.png"],["title": "lorem-ipsum.js", "description": "lorem-ipsum.js is a Node.js, Component.js, and React Native module for generating passages of lorem ipsum text.", "profileImage": "avatar.png"], ["title": "Using the Module (Node.js)", "description": "Install the lorem-ipsum.js module to use the library in your server-side Node.js projects. Require the lorem-ipsum.js module and use it to generate a passage of lorem ipsum text.", "profileImage": "businessman.png"],["title": "Customizing the Output with Options", "description": "You can pass options to the loremIpsum() function to fine-tune the output. The API is the same on client and server.", "profileImage": "user.png"],["title": "Notes", "description": "The copy feature requires that you have xclip installed if you are using lorem-ipsum.js on Linux. The feature will work out of the box on Mac and Windows systems.", "profileImage": "businessman.png"]]
    let alphabetsArray = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    var sectionIndexArray = [String]()
    
    var sectionizedArray = [[[String:String]]]()
    var flag = 0
    var frame: CGRect?
    var indexContainerView = UIView()
    var transparentView: UIView?
    var isFirstTime = true
    var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.estimatedRowHeight = 70
        //tableView.sectionIndexColor = UIColor.darkGray//UIColor.init(red: 139.0/255.0, green: 190.0/255.0, blue: 89.0/255.0, alpha: 1)
        createSectionizedArray()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if isFirstTime {
            isFirstTime = false
            constructCustomTableIndex()
        }
    }
    
    func enlargeProfileImage() {
        transparentView = UIView(frame: self.view.bounds)
        let dismissButton = UIButton(frame: transparentView!.bounds)
        dismissButton.addTarget(self, action: #selector(dismissMagnifiedImage), for: .touchUpInside)
        transparentView?.addSubview(dismissButton)
        frame = self.view.convert(profileImageView.frame, from: profileImageView.superview)
        let magnifiedImageView = UIImageView(frame: frame!)
        magnifiedImageView.contentMode = profileImageView.contentMode
        magnifiedImageView.clipsToBounds = profileImageView.clipsToBounds
        magnifiedImageView.image = profileImageView.image
        magnifiedImageView.tag = 99
        transparentView?.addSubview(magnifiedImageView)
        self.view.addSubview(transparentView!)
        
        animateImageToCentre()
    }
    
    func animateImageToCentre() {
        UIApplication.shared.beginIgnoringInteractionEvents()
        let imageView = transparentView?.viewWithTag(99)
        let viewWidth = self.view.frame.width
        let viewheight = self.view.frame.height
        let width = viewWidth/2
        let height = width*((imageView?.frame.height)!/(imageView?.frame.width)!)
        
        profileImageView.alpha = 0
        UIView.animate(withDuration: 0.7,
                       delay: 0.0,
                       options: .curveEaseInOut,
                       animations: {
                        imageView?.frame = CGRect(x: (viewWidth-width)/2, y: (viewheight-height)/2, width: width, height: height)
        }) { (finished) in
            if finished {
                UIApplication.shared.endIgnoringInteractionEvents()
            }
        }
    }
    
    @objc func dismissMagnifiedImage() {
        UIApplication.shared.beginIgnoringInteractionEvents()
        
        let imageView = transparentView?.viewWithTag(99)
        UIView.animate(withDuration: 0.5,
                       delay: 0.0,
                       options: .curveEaseIn,
                       animations: {
                        imageView?.frame = self.frame!
        }) { [weak self] (finished) in
            if finished {
                self?.profileImageView.alpha = 1
                self?.transparentView?.removeFromSuperview()
                self?.transparentView = nil
                UIApplication.shared.endIgnoringInteractionEvents()
            }
        }
    }
    
    @IBAction func segmentControllerClicked(_ sender: UISegmentedControl) {
        flag = sender.selectedSegmentIndex
        tableView.reloadData()
        moveTableIndexLeftOrRight()
    }
    
    func createSectionizedArray() {
        for alphabet in alphabetsArray {
            let singleAlphabetArray = array.filter { (object) -> Bool in
                return object["title"]?.first == alphabet.first
            }
            sectionizedArray.append(singleAlphabetArray)
            if singleAlphabetArray.isEmpty {
                sectionIndexArray.append(".")
            } else {
                sectionIndexArray.append(alphabet)
            }
        }
        tableView.reloadData()
    }

}



extension IndexedTableViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if sectionizedArray.count > 0 {
            return sectionizedArray.count
        } else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if sectionizedArray.count > 0 {
            return sectionizedArray[section].count
        } else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.flag = flag
        if !sectionizedArray.isEmpty {
            cell.dataDict = sectionizedArray[indexPath.section][indexPath.row]
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        profileImageView = (tableView.cellForRow(at: indexPath) as! TableViewCell).imageView1
        enlargeProfileImage()
    }
    
//    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
//        return sectionIndexArray
//    }

    
}



extension IndexedTableViewController /* For creating custom tableView Index */ {
    
    func constructCustomTableIndex() {
        createIndexContainerView()
        addAlphabetsInTableindex()
        addGestureRecognizerToTableIndex()
    }
    
    func createIndexContainerView() {
        let tableFrame = tableView.frame
        
        indexContainerView = UIView(frame: CGRect(x: view.frame.size.width - thickness, y: tableFrame.origin.y + paddingForIndexView, width: thickness, height: tableFrame.size.height - 2*paddingForIndexView))
        //indexContainerView.backgroundColor = UIColor.blue
        indexContainerView.layer.cornerRadius = 4
        indexContainerView.clipsToBounds = true
        view.insertSubview(indexContainerView, aboveSubview: tableView)
    }
    
    func addAlphabetsInTableindex() {
        let width = indexContainerView.frame.size.width
        let height = indexContainerView.frame.size.height/CGFloat(sectionIndexArray.count)
        for i in 0..<sectionIndexArray.count {
            let alphabetLabel = UILabel(frame: CGRect(x: 0, y: CGFloat(i)*height, width: width, height: height))
            alphabetLabel.textAlignment = .center
            alphabetLabel.font = UIFont.init(name: "Chalkduster", size: 13)
            alphabetLabel.textColor = UIColor.init(red: 139.0/255.0, green: 113.0/255.0, blue: 179.0/255.0, alpha: 1.0)
            alphabetLabel.text = sectionIndexArray[i]
            indexContainerView.addSubview(alphabetLabel)
        }
    }
    
    func addGestureRecognizerToTableIndex() {
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tableIndexTapped(_:)))
        indexContainerView.addGestureRecognizer(tapGesture)
        
        let panGesture = UIPanGestureRecognizer.init(target: self, action: #selector(tableIndexPanned(_:)))
        indexContainerView.addGestureRecognizer(panGesture)
    }
    
    @objc func tableIndexTapped(_ gestureRecognizer: UITapGestureRecognizer) {
        let touchPoint = gestureRecognizer.location(in: indexContainerView)
        scrollTableForDistance(touchPoint.y)
    }
    
    @objc func tableIndexPanned(_ gestureRecognizer: UIPanGestureRecognizer) {
        let touchPoint = gestureRecognizer.location(in: indexContainerView)
        scrollTableForDistance(touchPoint.y)
    }
    
    func scrollTableForDistance(_ distance: CGFloat) {
        let height = indexContainerView.frame.size.height/CGFloat(sectionIndexArray.count)
        let index = Int(floor(distance/height))
        if index < sectionizedArray.count && index >= 0 && index != currentIndex {
            currentIndex = index
            if !sectionizedArray[index].isEmpty {
                tableView.scrollToRow(at: IndexPath(row: 0, section: index), at: .top, animated: false)
            }
        }
    }
    
    func moveTableIndexLeftOrRight() {
        var frame = CGRect()
        let tableFrame = tableView.frame
        
        if flag == 0 {
            frame = CGRect(x: view.frame.size.width - thickness, y: tableFrame.origin.y + paddingForIndexView, width: thickness, height: tableFrame.size.height - 2*paddingForIndexView)
            
        } else {
            frame = CGRect(x: 0, y: tableFrame.origin.y + paddingForIndexView, width: thickness, height: tableFrame.size.height - 2*paddingForIndexView)
        }
        UIView.animate(withDuration: 0.3,
                       delay: 0.0,
                       options: .curveEaseOut,
                       animations: {
                        self.indexContainerView.frame = frame
        })
    }
    
}
