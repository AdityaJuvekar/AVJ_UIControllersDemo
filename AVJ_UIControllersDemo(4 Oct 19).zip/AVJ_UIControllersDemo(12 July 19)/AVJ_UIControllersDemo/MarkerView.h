//
//  MarkerView.h
//  AVJ_Calendar
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MarkerView : UIView
@property (nonatomic) UIColor *markingColor;
@property (nonatomic) UIColor *selectionColor;
@end
