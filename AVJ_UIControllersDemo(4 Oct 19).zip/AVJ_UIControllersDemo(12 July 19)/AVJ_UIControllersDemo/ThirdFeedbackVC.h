//
//  ThirdFeedbackVC.h
//  SpeedBanking
//
//  Created by admin on 14/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdFeedbackVC : UIViewController<UIGestureRecognizerDelegate,UITextViewDelegate>

@end
