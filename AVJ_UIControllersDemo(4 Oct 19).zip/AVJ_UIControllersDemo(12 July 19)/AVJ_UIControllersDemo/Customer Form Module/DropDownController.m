//
//  DropDownController.m
//  ECRFmainScreen
//
//  Created by admin on 23/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "DropDownController.h"
#import "DropDownCell.h"

@interface DropDownController ()

@end

@implementation DropDownController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self animateDropDown];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.superview.layer.cornerRadius = 0;
    self.view.superview.clipsToBounds = NO;
}

-(void)animateDropDown {
    [UIView transitionWithView:self.view
                      duration:.4
                       options:UIViewAnimationOptionTransitionCurlDown
                    animations:^{
                        _backView.hidden = true;
                        _tableView.hidden = false;
                    } completion:^(BOOL finished) {
                    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _tableDataArray1.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DropDownCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DropDownCell"];
    cell.label.text = _tableDataArray1[indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [UIView transitionWithView:self.view
                      duration:.4
                       options:UIViewAnimationOptionTransitionCurlUp
                    animations:^{
                        _backView.hidden = false;
                        _tableView.hidden = true;
                    } completion:^(BOOL finished) {
                        [_delegate rowSelectedWithName:_tableDataArray1[indexPath.row] andNumber:_tableDataArray2[indexPath.row]];
                    }];
}




@end
