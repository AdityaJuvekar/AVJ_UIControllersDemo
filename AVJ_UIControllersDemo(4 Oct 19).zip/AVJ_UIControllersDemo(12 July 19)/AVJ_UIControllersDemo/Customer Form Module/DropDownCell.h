//
//  DropDownCell.h
//  ECRFmainScreen
//
//  Created by admin on 23/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DropDownCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *mainView;
@property (weak, nonatomic) IBOutlet UILabel *label;


@end
