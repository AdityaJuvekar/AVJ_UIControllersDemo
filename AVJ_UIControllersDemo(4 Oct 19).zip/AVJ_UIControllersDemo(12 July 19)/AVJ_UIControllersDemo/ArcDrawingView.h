//
//  ArcDrawingView.h
//  SpeedBanking
//
//  Created by admin on 07/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArcDrawingView : UIView
@property (nonatomic) float endAngle;
@property (nonatomic) NSArray *colorArray;
@property (nonatomic) float radius;
@property (nonatomic) float cutAngle;
@property (nonatomic) float arcWidth;
@property (nonatomic) int n;
@property (nonatomic) float f;
@property (nonatomic) int nos;
@end
