//
//  DataController.h
//  AVJ_UIControllersDemo
//
//  Created by admin on 12/03/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface DataController : NSObject

@property (strong, nonatomic, readonly) NSPersistentContainer *persistentContainer;
@property (nonatomic) NSManagedObjectContext *managedObjectContext;

- (id)initWithCompletionBlock:(void(^)(void))callback;

@end
