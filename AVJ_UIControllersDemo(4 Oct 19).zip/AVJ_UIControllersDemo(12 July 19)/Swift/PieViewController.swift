//
//  PieViewController.swift
//  PieChart
//
//  Created by admin on 23/03/18.
//  Copyright © 2018 AXIS. All rights reserved.
//

import UIKit

class PieViewController: UIViewController {

    var pieView = PieView()
    override func viewDidLoad() {
        super.viewDidLoad()
        //let pieControllerView = PieChartControllerView()
        //pieControllerView.valueArray = [CGFloat(23.0),CGFloat(40.0),CGFloat(15.0),CGFloat(75.0)]
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        /*pieView = PieView.init(frame: CGRect.init(origin: CGPoint(x: self.view.center.x-150, y: self.view.center.y-150), size: CGSize(width: 360,height: 400)))
        self.view .addSubview(pieView)
        pieView.value = CGFloat.pi
        pieView.setNeedsDisplay()*/
    }

}
