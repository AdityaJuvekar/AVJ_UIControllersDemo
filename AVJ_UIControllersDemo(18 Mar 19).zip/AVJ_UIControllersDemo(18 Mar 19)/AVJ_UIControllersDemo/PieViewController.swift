//
//  PieViewController.swift
//  PieChart
//
//  Created by admin on 23/03/18.
//  Copyright © 2018 AXIS. All rights reserved.
//

import UIKit

class PieViewController: UIViewController {
    @IBOutlet weak var drawingView: PieChartControllerView!
    
    @IBOutlet weak var numberSlider: UISlider!
    
    
    @IBOutlet weak var slider1: UISlider!
    
    @IBOutlet weak var slider2: UISlider!
    
    @IBOutlet weak var slider3: UISlider!
    
    @IBOutlet weak var slider4: UISlider!
    
    @IBOutlet weak var slider5: UISlider!
    
    @IBOutlet weak var slider6: UISlider!
    
    @IBOutlet weak var slider7: UISlider!
    
    var sliderArray = [UISlider]()
    
    var numberOfPies = 3
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sliderArray.append(slider1)
        sliderArray.append(slider2)
        sliderArray.append(slider3)
        sliderArray.append(slider4)
        sliderArray.append(slider5)
        sliderArray.append(slider6)
        sliderArray.append(slider7)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        resetValueArray()
        drawingView.colorArray = [#colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1),#colorLiteral(red: 1, green: 0.08355515055, blue: 0.03777309893, alpha: 1),UIColor.white,#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1),#colorLiteral(red: 0.1215686277, green: 0.01176470611, blue: 0.4235294163, alpha: 1),#colorLiteral(red: 0.4392156899, green: 0.01176470611, blue: 0.1921568662, alpha: 1),#colorLiteral(red: 0.5725490451, green: 0, blue: 0.2313725501, alpha: 1)]
    }
    
    func resetValueArray() {
        drawingView.valueArray.removeAll()
        drawingView.setNeedsDisplay()
    }
    
    @IBAction func drawPieView() {
        numberOfPies = Int(roundf(numberSlider.value));
        var tempArray = [CGFloat]()
        for i in 0 ..< numberOfPies {
            tempArray.append(CGFloat(sliderArray[i].value))
        }
        drawingView.valueArray = tempArray
        drawingView.setNeedsDisplay()
    }
    
    @IBAction func numberSliderChanged(_ sender: UISlider) {
        sender.value = roundf(sender.value);
        switch sender.value {
        case 0.0:
            slider1.isEnabled = false
            slider2.isEnabled = false
            slider3.isEnabled = false
            slider4.isEnabled = false
            slider5.isEnabled = false
            slider6.isEnabled = false
            slider7.isEnabled = false
        case 1.0:
            slider1.isEnabled = true
            slider2.isEnabled = false
            slider3.isEnabled = false
            slider4.isEnabled = false
            slider5.isEnabled = false
            slider6.isEnabled = false
            slider7.isEnabled = false
        case 2.0:
            slider1.isEnabled = true
            slider2.isEnabled = true
            slider3.isEnabled = false
            slider4.isEnabled = false
            slider5.isEnabled = false
            slider6.isEnabled = false
            slider7.isEnabled = false
        case 3.0:
            slider1.isEnabled = true
            slider2.isEnabled = true
            slider3.isEnabled = true
            slider4.isEnabled = false
            slider5.isEnabled = false
            slider6.isEnabled = false
            slider7.isEnabled = false
        case 4.0:
            slider1.isEnabled = true
            slider2.isEnabled = true
            slider3.isEnabled = true
            slider4.isEnabled = true
            slider5.isEnabled = false
            slider6.isEnabled = false
            slider7.isEnabled = false
        case 5.0:
            slider1.isEnabled = true
            slider2.isEnabled = true
            slider3.isEnabled = true
            slider4.isEnabled = true
            slider5.isEnabled = true
            slider6.isEnabled = false
            slider7.isEnabled = false
        case 6.0:
            slider1.isEnabled = true
            slider2.isEnabled = true
            slider3.isEnabled = true
            slider4.isEnabled = true
            slider5.isEnabled = true
            slider6.isEnabled = true
            slider7.isEnabled = false
        case 7.0:
            slider1.isEnabled = true
            slider2.isEnabled = true
            slider3.isEnabled = true
            slider4.isEnabled = true
            slider5.isEnabled = true
            slider6.isEnabled = true
            slider7.isEnabled = true
        default:
            slider1.isEnabled = false
            slider2.isEnabled = false
            slider3.isEnabled = false
            slider4.isEnabled = false
            slider5.isEnabled = false
            slider6.isEnabled = false
            slider7.isEnabled = false
        }
    }
    

}
