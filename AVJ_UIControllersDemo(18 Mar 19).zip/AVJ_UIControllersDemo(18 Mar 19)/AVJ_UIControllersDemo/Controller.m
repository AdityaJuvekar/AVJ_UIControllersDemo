//
//  Controller.m
//  AVJ_Calendar
//
//  Created by Apple on 07/05/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "Controller.h"
#import "CalendarVC.h"
#import "AVJ_UIControllersDemo-Swift.h"

@interface Controller ()<AVJCalendarDelegate>
@property (weak, nonatomic) IBOutlet UIView *calenderView;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
//@property (nonatomic) CalendarVC *cvc; //for objc
@property (nonatomic) SwiftCalendarVC *cvc; //for swift
@property (nonatomic) NSMutableArray *dateArray;
@property (nonatomic) NSArray *colorsArray;
- (IBAction)addDateToArray:(UIButton *)sender;
- (IBAction)clearDateArray:(UIButton *)sender;

@end

@implementation Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    _dateArray = [[NSMutableArray alloc]init];
    _datePicker.datePickerMode = UIDatePickerModeDate;
    _colorsArray = @[[UIColor greenColor],[UIColor cyanColor],[UIColor grayColor]];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
//    _cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"CalendarVC"]; //for objc
    _cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"SwiftCalendarVC"]; //for swift
    _cvc.delegate = self;
    [self addChildViewController:_cvc];
    [_calenderView addSubview:_cvc.view];
    _cvc.view.frame = _calenderView.bounds;
    [_cvc didMoveToParentViewController:self];
    
    NSDateComponents *weekdaycomponents = [[NSDateComponents alloc]init];
    weekdaycomponents.month = 7;
    weekdaycomponents.year = 2019;
    weekdaycomponents.day = 25;
    NSCalendar *calender = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *date = [calender dateFromComponents:weekdaycomponents];
    [_cvc markDatesFromArrayWithDates:@[@2,date] withColors:_colorsArray]; //for swift
//    [_cvc markDatesFromArray:@[@2,date] withColors:_colorsArray]; //for objc
}

-(void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:_calenderView.bounds];
    _calenderView.layer.shadowColor = [UIColor blackColor].CGColor;
    _calenderView.layer.shadowOpacity = 0.5;
    _calenderView.layer.shadowOffset = CGSizeMake(1, 1);
    _calenderView.layer.masksToBounds = NO;
    _calenderView.layer.shadowPath = shadowPath.CGPath;
}

-(void)dateSelected:(NSDate *)selectedDate {
    NSLog(@"Selected date : %@",selectedDate);
}

-(void)monthChangedWithNewDate:(NSDate *)date {
    NSLog(@"New month: %@",date);
}

- (IBAction)addDateToArray:(UIButton *)sender {
    [_dateArray addObject:_datePicker.date];
    [_cvc markDatesFromArrayWithDates:_dateArray withColors:_colorsArray]; //swift
//    [_cvc markDatesFromArray:_dateArray withColors:_colorsArray]; //objc
}

- (IBAction)clearDateArray:(UIButton *)sender {
    [_dateArray removeAllObjects];
    [_cvc markDatesFromArrayWithDates:_dateArray withColors:@[[UIColor clearColor]]]; //swift
//    [_cvc markDatesFromArray:_dateArray withColors:@[[UIColor clearColor]]]; //objc
}

@end
