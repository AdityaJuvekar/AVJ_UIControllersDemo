//
//  DetailViewController.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 19/12/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, AVJControllerSelectionDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var containerView: UIView!
    
    var currentViewController: UIViewController?
    
    let controllerIdentifierArray = ["ThirdFeedbackVC","FirstFeedbackVC","ViewController","PieViewController","CustomFormController","CalendarController","IndexedTableViewController"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //searchBar.becomeFirstResponder()
    }

    func selectedController(withIndex index: Int) {
        for view in containerView.subviews {
            view.removeFromSuperview()
        }
        currentViewController?.removeFromParent()
        currentViewController = nil
        currentViewController = self.storyboard?.instantiateViewController(withIdentifier: controllerIdentifierArray[index])
        addChild(currentViewController!)
        view.addSubview((currentViewController?.view)!)
        currentViewController?.view.frame = view.bounds
        currentViewController?.didMove(toParent: self)
    }

}
