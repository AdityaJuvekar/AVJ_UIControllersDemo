//
//  CustomerDetails+CoreDataProperties.m
//  AVJ_UIControllersDemo
//
//  Created by admin on 17/03/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "CustomerDetails+CoreDataProperties.h"

@implementation CustomerDetails (CoreDataProperties)

+ (NSFetchRequest<CustomerDetails *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CustomerDetails"];
}

@dynamic accountNumber;
@dynamic cheque;
@dynamic custID;
@dynamic emailID;
@dynamic mobile;
@dynamic name;
@dynamic pan;

@end
