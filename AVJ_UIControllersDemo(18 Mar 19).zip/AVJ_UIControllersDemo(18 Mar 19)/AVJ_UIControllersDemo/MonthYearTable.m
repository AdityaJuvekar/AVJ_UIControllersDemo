//
//  MonthYearTable.m
//  AVJ_Calendar
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "MonthYearTable.h"
#import "monthYearCell.h"
#import "CalendarVC.h"

@interface MonthYearTable ()

@end

@implementation MonthYearTable

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.superview.layer.cornerRadius = 0;
    self.view.superview.clipsToBounds = NO;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    monthYearCell *cell = [tableView dequeueReusableCellWithIdentifier:@"monthYearCell" forIndexPath:indexPath];
    cell.cellLabel.text = _dataArray[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [_delegate delegateMethod:indexPath.row];
    [self dismissViewControllerAnimated:NO completion:nil];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}


@end
