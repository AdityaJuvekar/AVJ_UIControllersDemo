//
//  CommonFile.h
//  ECRFmainScreen
//
//  Created by admin on 12/05/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommonFile : NSObject

+ (UIImage *)imageWithView: (UIView *)view;

@end
