//
//  DropDownController.h
//  ECRFmainScreen
//
//  Created by admin on 23/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol DDTDelegate <NSObject>

-(void)rowSelectedWithName:(NSString *)string1 andNumber:(NSString *)string2;

@end

@interface DropDownController : UIViewController <UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *backView;

@property NSMutableArray *tableDataArray1;
@property NSMutableArray *tableDataArray2;
@property (weak,nonatomic) id delegate;

-(void)animateDropDown;
@end
