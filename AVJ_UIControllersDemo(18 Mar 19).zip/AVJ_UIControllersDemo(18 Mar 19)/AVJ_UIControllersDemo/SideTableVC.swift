//
//  SideTableVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 10/12/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

@objc protocol AVJControllerSelectionDelegate: AnyObject {
    func selectedController(withIndex index: Int)
}

class SideTableVC: UITableViewController {
    
    let arrayXXX = [["image":"003-graphic-progression.png", "title":"Linear Feedback"], ["image":"oie_23112010dG6VH9KD.png", "title":"Circular Feedback"], ["image":"002-sea-snake.png", "title":"Snake Curve"], ["image":"electronic-board-with-concentric-circles.png", "title":"Concentric Pies"], ["image":"001-square.png", "title":"Account Details"], ["image":"calendar-page-of-day-25.png", "title":"Calendar"], ["image":"index.png", "title":"Table Index"]]
    
    @objc weak var controllerSelectionDelegate: AVJControllerSelectionDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return arrayXXX.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dictionary = arrayXXX[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        (cell.viewWithTag(10) as! UIImageView).image = UIImage(named: dictionary["image"]!)
        (cell.viewWithTag(20) as! UILabel).text = dictionary["title"]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        controllerSelectionDelegate?.selectedController(withIndex: indexPath.row)
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
