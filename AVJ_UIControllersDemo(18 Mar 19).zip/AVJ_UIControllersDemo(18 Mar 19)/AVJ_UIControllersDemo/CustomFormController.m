
//
//  CustomFormController.m
//  ECRFmainScreen
//
//  Created by admin on 06/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "CustomFormController.h"
#import <QuartzCore/CAAnimation.h>
#import "CommonFile.h"
#import "DropdownBackground.h"
#import "DataController.h"
#import "CustomerDetails+CoreDataProperties.h"

@interface CustomFormController ()
@property (weak, nonatomic) IBOutlet UIButton *emailButton;
@property (weak, nonatomic) IBOutlet UIButton *panButton;
@property (weak, nonatomic) IBOutlet UIButton *mobileButton;
@property (weak, nonatomic) IBOutlet UIButton *chequeButton;
@property (weak, nonatomic) IBOutlet UITextField *emailTextField;
@property (weak, nonatomic) IBOutlet UITextField *panTextField;
@property (weak, nonatomic) IBOutlet UITextField *mobileTextField;
@property (weak, nonatomic) IBOutlet UISegmentedControl *chequeSegmentControl;

@property (strong, nonatomic) NSString *mobileTemp;
@property (strong, nonatomic) NSString *PANTemp;
@property (strong, nonatomic) NSString *emailTemp;
@property (nonatomic) BOOL chequeWantedTemp;
@property (nonatomic) DataController *db;

@property (strong, nonatomic) NSString *mobile;
@property (strong, nonatomic) NSString *PAN;
@property (strong, nonatomic) NSString *email;
@property (nonatomic) BOOL chequeWanted;
@property (nonatomic) CustomerDetails *customer;
@property (nonatomic) NSArray *dbDataArray;
@property (nonatomic) int arrayIndex;
@end

@implementation CustomFormController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_chequeSegmentControl setTitleTextAttributes:[NSDictionary dictionaryWithObject:[UIFont boldSystemFontOfSize:10.0f] forKey:NSFontAttributeName] forState:UIControlStateNormal];
    [self disableButtons];
    [self initiateDataArrays];
    _mobileTemp = @"9898989898";
    _PANTemp = @"QWERT1111Y";
    _emailTemp = @"xxxxx@xxxx.xxx";
    _chequeWantedTemp = false;
    _db = [[DataController alloc] initWithCompletionBlock:^{}];
    [self loadDataInDataBase];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    [self initiateDropDownTextFields];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self setShadow];
    int width = self.view.frame.size.width;
    int height = self.view.frame.size.height;
    _centralFrame = CGRectMake((width/2)-(width*2)/6, (height/2)-(width*4)/18, (width*2)/3, (width*4)/9);
}

-(void)disableButtons {
    _emailButton.enabled = NO;
    _panButton.enabled = NO;
    _mobileButton.enabled = NO;
    _chequeButton.enabled = NO;
}

-(void)enableButtons {
    _emailButton.enabled = YES;
    _panButton.enabled = YES;
    _mobileButton.enabled = YES;
    _chequeButton.enabled = YES;
}

-(void)initiateDropDownTextFields {
    _textFieldHol.userInteractionEnabled = NO;
    _textFieldAcc.delegate = self;
    _textFieldHol.delegate = self;
}

-(void)initiateDataArrays {
    _arrayIndex = -1;
    _accountNoArray = [[NSMutableArray alloc] init];
    //_accountNoArray = [[NSMutableArray alloc] initWithObjects:@"63525476",@"23747817024",@"8783698124",nil];
    _holderNameArray = [[NSMutableArray alloc] init];
    //_holderNameArray = [[NSMutableArray alloc] initWithObjects:@[@"Aditya Juvekar",@"Deepak Yadav",@"Ninad Divekar",@"Pooja Anbule",@"Sayali More"],@[@"Komal Dhumal",@"Prathamesh Sawant",@"Rahi Jain",@"Sandeep Khandare"],@[@"Dhrumil Shah",@"Gauri Desai",@"Sunil Dhappadhule",@"Vishal More"],nil];
    //_holderNoArray = [[NSMutableArray alloc] initWithObjects:@[@"00000001",@"00000002",@"00000003",@"00000004",@"00000005"],@[@"00000006",@"00000007",@"00000008",@"00000009"],@[@"00000010",@"00000011",@"00000012",@"00000013"],nil];
}

-(void)setShadow {
    
    _custNameView.layer.borderWidth = 1.5f;
    _custNameView.layer.borderColor = [UIColor colorWithRed:149.0/255.0 green:184.0/255.0 blue:252.0/255.0 alpha:1].CGColor;
    
    _textFieldAcc.text = @"Select";
    _textFieldHol.text = @"Select";
    
    UIBezierPath *shadowPath1 = [UIBezierPath bezierPathWithRect:_topLeftOuterView.bounds];
    _topLeftOuterView.layer.masksToBounds = NO;
    _topLeftOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _topLeftOuterView.layer.shadowOffset = CGSizeMake(0.0f, 4.5f);
    _topLeftOuterView.layer.shadowOpacity = 0.5f;
    _topLeftOuterView.layer.shadowPath = shadowPath1.CGPath;
    
    UIBezierPath *shadowPath2 = [UIBezierPath bezierPathWithRect:_topRightOuterView.bounds];
    _topRightOuterView.layer.masksToBounds = NO;
    _topRightOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _topRightOuterView.layer.shadowOffset = CGSizeMake(0.0f, 4.5f);
    _topRightOuterView.layer.shadowOpacity = 0.5f;
    _topRightOuterView.layer.shadowPath = shadowPath2.CGPath;
    
    UIBezierPath *shadowPath3 = [UIBezierPath bezierPathWithRect:_bottomLeftOuterView.bounds];
    _bottomLeftOuterView.layer.masksToBounds = NO;
    _bottomLeftOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _bottomLeftOuterView.layer.shadowOffset = CGSizeMake(0.75f, 5.5f);
    _bottomLeftOuterView.layer.shadowOpacity = 0.4f;
    _bottomLeftOuterView.layer.shadowPath = shadowPath3.CGPath;
    
    UIBezierPath *shadowPath4 = [UIBezierPath bezierPathWithRect:_bottomLeftOuterView.bounds];
    _bottomRightOuterView.layer.masksToBounds = NO;
    _bottomRightOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _bottomRightOuterView.layer.shadowOffset = CGSizeMake(0.75f, 5.5f);
    _bottomRightOuterView.layer.shadowOpacity = 0.4f;
    _bottomRightOuterView.layer.shadowPath = shadowPath4.CGPath;
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == _textFieldAcc || textField == _textFieldHol)
    {
        [self dropDownclicked:textField];
        return NO;
    }
    return YES;
}


- (void)dropDownclicked:(UITextField *)textField
{
    _currentfield=textField;
    int row_count = 0;
    DropDownController *ddt=[self.storyboard instantiateViewControllerWithIdentifier:@"DropDownController"];
    ddt.delegate = self;
    if (textField == _textFieldAcc) {
        @try {
            //DataController *db = [[DataController alloc] initWithCompletionBlock:^{}];
            //NSString *name = @"Gauri Desai";
            NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"CustomerDetails"];
            //[request setPredicate:[NSPredicate predicateWithFormat:@"name == %@", name]];
            NSError *error = nil;
            _dbDataArray = [_db.managedObjectContext executeFetchRequest:request error:&error];
            
            if (!_dbDataArray) {
                NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
            } else {
                for (CustomerDetails *custDetails in _dbDataArray) {
                    NSString *accountNumber = [NSString stringWithFormat:@"%d",custDetails.accountNumber];
                    if (![_accountNoArray containsObject:accountNumber]) {
                        [_accountNoArray addObject:accountNumber];
                    }
                }
            }
        } @catch (NSException *exception) {
            NSLog(@"Nyam: could not load AVJ, %@", exception);
        } @finally {
            
        }
        ddt.tableDataArray1 = _accountNoArray;
        row_count = (int)_accountNoArray.count;
    }
    else if (textField == _textFieldHol && _arrayIndex>=0) {
        //ddt.tableDataArray1 = _holderNameArray[_arrayIndex];
        ddt.tableDataArray1 = _holderNameArray;
        //row_count = (int)((NSArray*)_holderNameArray[_arrayIndex]).count;
        row_count = (int)_holderNameArray.count;
    }
    [ddt.tableView reloadData];
    
    ddt.preferredContentSize=CGSizeMake(textField.frame.size.width, row_count*50);
    ddt.modalPresentationStyle = UIModalPresentationPopover;
    ddt.view.clipsToBounds = NO;
    
    _Dropdown = ddt.popoverPresentationController;
    
    _Dropdown.delegate = self;
    _Dropdown.sourceView = self.view;
    _Dropdown.popoverBackgroundViewClass = [DropdownBackground class];
    CGRect rect = [self.view convertRect:textField.frame fromView:textField.superview];
    _Dropdown.sourceRect = rect;
    [_Dropdown setPermittedArrowDirections:UIPopoverArrowDirectionUp];
    [self presentViewController:ddt animated:NO completion:nil];
}

-(void)rowSelectedWithName:(NSString *)string1{
    [self dismissViewControllerAnimated:NO completion:nil];
    self.mobile = @"";
    self.PAN = @"";
    self.email = @"";
    self.chequeWanted = false;
    _chequeLabel.text = @"";
    if (_currentfield == _textFieldAcc) {
        [self disableButtons];
        _accountNumber = string1;
        [_holderNameArray removeAllObjects];
        for (CustomerDetails *custDetails in _dbDataArray) {
            if (custDetails.accountNumber == [string1 intValue]) {
                [_holderNameArray addObject:custDetails.name];
            }
        }
        _arrayIndex = (int)[_accountNoArray indexOfObject:string1];
        _holderName = NULL;
        _textFieldAcc.text = string1;
        _textFieldHol.text = @"Select";
        _textFieldHol.userInteractionEnabled = YES;
        [_custNameLabel setFrame:CGRectMake(0, 0, 0, 0)];
        _custNameLabel.text = nil;
        [UIView animateWithDuration:.4 animations:^{
            [self.custNameView setFrame:CGRectMake(24, 18, 0, 0)];
        } completion:^(BOOL finished) {
            
        }];
    }
    else if (_currentfield == _textFieldHol) {
        [self enableButtons];
        _holderName = string1;
        _textFieldHol.text = string1;
        
        for (CustomerDetails *custDetails in _dbDataArray) {
            if (custDetails.name == string1) {
                _customer = custDetails;
            }
        }
        [UIView animateWithDuration:.5 animations:^{
            [self.custNameView setFrame:CGRectMake(24, 18, self.custNameView.superview.frame.size.width-48, self.custNameView.superview.frame.size.height-18)];
        } completion:^(BOOL finished) {
            [self.custNameLabel setFrame:CGRectMake(20, 0, self.custNameView.frame.size.width-30, self.custNameView.frame.size.height)];
            self.custNameLabel.text = [NSString stringWithFormat:@"Name :   %@ (%@)",self.customer.name ,self.customer.custID];
            self.mobile = [NSString stringWithFormat:@"%d",self.customer.mobile];
            self.PAN = self.customer.pan;
            self.email = self.customer.emailID;
            self.chequeWanted = self.customer.cheque;
        }];
    }
}

-(void)setEmail:(NSString *)email {
    
    _email = email;
    _emailLabel.text = email;
    _emailTextField.text = email;
}

-(void)setPAN:(NSString *)PAN {
    
    _PAN = PAN;
    _PANLabel.text = PAN;
    _panTextField.text = PAN;
}

-(void)setMobile:(NSString *)mobile {
    
    _mobile = mobile;
    _mobileLabel.text = mobile;
    _mobileTextField.text = mobile;
}

-(void)setChequeWanted:(BOOL)chequeWanted {
    
    _chequeWanted = chequeWanted;
    if(chequeWanted) {
        _chequeLabel.text = @"YES";
        _chequeSegmentControl.selectedSegmentIndex = 0;
    }
    else {
        _chequeLabel.text = @"NO";
        _chequeSegmentControl.selectedSegmentIndex = 1;
    }
}

- (IBAction)flipperPressed:(UIButton *)sender {
    
    [self.view setUserInteractionEnabled:NO];
    _superView = [sender superview];
    _frontView = [_superView viewWithTag:20];
    _middleView = [_superView viewWithTag:30];
    _backView = [_superView viewWithTag:10];
    _middleView.alpha = 0;
    _convertedFrame = [_superView convertRect:_backView.frame toView:self.view];
    [UIView transitionWithView:_superView
                      duration:.7
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        self.frontView.hidden = true;
                        self.middleView.hidden = true;
                        self.backView.hidden = false;
                    } completion:^(BOOL finished) {
                        self.image = [CommonFile imageWithView:self.backView];
                        self.imageView = [[UIImageView alloc]initWithImage:self.image];
                        [self.view addSubview:self.imageView];
                        [self.imageView setFrame:self.convertedFrame];
                        self.middleView.hidden = false;
                        self.middleView.alpha = 1;
                        [UIView animateWithDuration:.7
                                         animations:^{
                                             [self.imageView setFrame:self.centralFrame];
                                             self.imageView.alpha = .5;
                                         } completion:^(BOOL finished) {
                                             self.imageView.alpha = 0;
                                             [self displayPopupScreenNumber:sender.tag];
                                         }];
                    }];
}

-(void)displayPopupScreenNumber:(NSInteger)number {
    if(number == 1) {
        EmailPVC *EVC = (EmailPVC*)[self.storyboard instantiateViewControllerWithIdentifier:@"EmailPVC"];
        EVC.delegate = self;
        EVC.email = _email;
        _PVC = EVC;
    }
    else if (number == 2) {
        PanPVC *PVC = [self.storyboard instantiateViewControllerWithIdentifier:@"PanPVC"];
        PVC.delegate = self;
        PVC.PAN = _PAN;
        _PVC = PVC;
    }
    else if (number == 3) {
        MobilePVC *MVC = [self.storyboard instantiateViewControllerWithIdentifier:@"MobilePVC"];
        MVC.delegate = self;
        MVC.mobile = _mobile;
        _PVC = MVC;
    }
    else if (number == 4) {
        ChequePVC *CVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ChequePVC"];
        CVC.delegate = self;
        CVC.chequeBookIsRequired = _chequeWanted;
        _PVC = CVC;
    }
    _PVC.preferredContentSize=CGSizeMake(_centralFrame.size.width, _centralFrame.size.height);
    _PVC.modalPresentationStyle = UIModalPresentationPopover;
    _PVC.view.clipsToBounds = NO;
    
    _Popup = _PVC.popoverPresentationController;
    
    _Popup.delegate = self;
    _Popup.sourceView = self.view;
    _Popup.popoverBackgroundViewClass = [DropdownBackground class];
    CGRect rect = CGRectMake(self.view.center.x-_centralFrame.size.width/2, self.view.center.y+_centralFrame.size.height/2,_centralFrame.size.width,0);
    _Popup.sourceRect = rect;
    [_Popup setPermittedArrowDirections:UIPopoverArrowDirectionDown];
    [self presentViewController:_PVC animated:NO completion:nil];
}

-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

-(BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    if (popoverPresentationController == _Dropdown) {
        [popoverPresentationController setPopoverBackgroundViewClass:nil];
        return YES;
    }
    return NO;
}

-(void)dismissPopUp {
    _imageView.alpha = .5;
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];
    [self.view setUserInteractionEnabled:NO];
    [UIView animateWithDuration:.7
                     animations:^{
                         [self.imageView setFrame:self.convertedFrame];
                         self.imageView.alpha = 1;
                     } completion:^(BOOL finished) {
                         self.middleView.alpha = 0;
                         [self performSelector:@selector(flipViewsToDefault) withObject:nil afterDelay:.05];
                     }];
}

-(void)captureAndSetImage {
    UIImage *capturedImage = [CommonFile imageWithView:_PVC.view];
    [_imageView setImage:capturedImage];
}

-(void)flipViewsToDefault {
    _imageView.alpha = 0;
    _imageView = nil;
    [UIView transitionWithView:_superView
                      duration:.7
                       options:UIViewAnimationOptionTransitionFlipFromRight
                    animations:^{
                        //_middleView.hidden = true;
                        self.backView.hidden = true;
                        self.frontView.hidden = false;
                    } completion:^(BOOL finished) {
                        [self.view setUserInteractionEnabled:YES];
                    }];
}

-(void)setMobileNumber:(NSString*)number {
    self.mobile = number;
    _customer.mobile = number.intValue;
    [self updateDB];
}

-(void)whetherChequeRequired:(BOOL)chequeRequired {
    self.chequeWanted = chequeRequired;
    _customer.cheque = chequeRequired;
    [self updateDB];
}

-(void)setEmailAddress:(NSString*)emailID {
    self.email = emailID;
    _customer.emailID = emailID;
    [self updateDB];
}

-(void)setPANnumber:(NSString*)PANnumber {
    self.PAN = PANnumber;
    _customer.pan = PANnumber;
    [self updateDB];
}

-(void)updateDB {
    NSError *error = nil;
    if ([_db.managedObjectContext save:&error] == NO) {
        NSAssert(NO, @"Error saving context: %@\n%@", [error localizedDescription], [error userInfo]);
    }
}

-(void)loadDataInDataBase {
    //DataController *db = [[DataController alloc] initWithCompletionBlock:^{}];
    @try {
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"CustomerDetails"];
        NSError *error = nil;
        _dbDataArray = [_db.managedObjectContext executeFetchRequest:request error:&error];
        
        if (!_dbDataArray) {
            NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
            abort();
        } else if(_dbDataArray.count == 0) {
            CustomerDetails *customer10 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer10.name = @"Vishal More";
            customer10.accountNumber = 141567688;
            customer10.custID = @"00000010";
            customer10.mobile = 842323460;
            customer10.emailID = @"bisaal@gmail.com";
            customer10.pan = @"DFGHG2373D";
            customer10.cheque = NO;
            CustomerDetails *customer9 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer9.name = @"Sunil Dhapadhule";
            customer9.accountNumber = 141567688;
            customer9.custID = @"00000009";
            customer9.mobile = 842323459;
            customer9.emailID = @"shonill@gmail.com";
            customer9.pan = @"DFGHG2373C";
            customer9.cheque = NO;
            CustomerDetails *customer8 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer8.name = @"Gauri Desai";
            customer8.accountNumber = 141567688;
            customer8.custID = @"00000008";
            customer8.mobile = 764323379;
            customer8.emailID = @"gaurzz@webmail.com";
            customer8.pan = @"YHCVG2371V";
            customer8.cheque = YES;
            CustomerDetails *customer7 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer7.name = @"Sandeep Khandare";
            customer7.accountNumber = 924254712;
            customer7.custID = @"00000007";
            customer7.mobile = 984321277;
            customer7.emailID = @"sandeepk@webmail.com";
            customer7.pan = @"DFCVG5771Q";
            customer7.cheque = YES;
            CustomerDetails *customer6 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer6.name = @"Komal Dhumal";
            customer6.accountNumber = 924254712;
            customer6.custID = @"00000006";
            customer6.mobile = 764111230;
            customer6.emailID = @"komal@webmail.com";
            customer6.pan = @"BBKVG5753L";
            customer6.cheque = YES;
            CustomerDetails *customer5 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer5.name = @"Rahi Jain";
            customer5.accountNumber = 924254712;
            customer5.custID = @"00000005";
            customer5.mobile = 884114962;
            customer5.emailID = @"rahiJ@gmail.com";
            customer5.pan = @"FCKVG1783T";
            customer5.cheque = NO;
            CustomerDetails *customer4 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer4.name = @"Prathamesh Savant";
            customer4.accountNumber = 924254712;
            customer4.custID = @"00000004";
            customer4.mobile = 845517877;
            customer4.emailID = @"prathamesh@gmail.com";
            customer4.pan = @"JJKVG1233O";
            customer4.cheque = YES;
            CustomerDetails *customer3 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer3.name = @"Vijendra Singh";
            customer3.accountNumber = 635254761;
            customer3.custID = @"00000003";
            customer3.mobile = 847617868;
            customer3.emailID = @"vijendra@webmail.com";
            customer3.pan = @"FRGVG1206P";
            customer3.cheque = NO;
            CustomerDetails *customer2 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer2.name = @"Aditya Juvekar";
            customer2.accountNumber = 635254761;
            customer2.custID = @"00000001";
            customer2.mobile = 997617898;
            customer2.emailID = @"adityaJ@webmail.com";
            customer2.pan = @"DKGVG4276P";
            customer2.cheque = YES;
            CustomerDetails *customer1 = [NSEntityDescription insertNewObjectForEntityForName:@"CustomerDetails" inManagedObjectContext:_db.managedObjectContext];
            customer1.name = @"Deepak Yadav";
            customer1.accountNumber = 635254761;
            customer1.custID = @"00000002";
            customer1.mobile = 987617822;
            customer1.emailID = @"deepu@webmail.com";
            customer1.pan = @"ASGVG1176K";
            customer1.cheque = YES;
            if ([_db.managedObjectContext save:&error] == NO) {
                NSAssert(NO, @"Error saving context: %@\n%@", [error localizedDescription], [error userInfo]);
            }
        }
    } @catch (NSException *exception) {
        NSLog(@"Nyam Nyam: saving failed : %@", exception);
    } @finally {
        
    }
}


@end
