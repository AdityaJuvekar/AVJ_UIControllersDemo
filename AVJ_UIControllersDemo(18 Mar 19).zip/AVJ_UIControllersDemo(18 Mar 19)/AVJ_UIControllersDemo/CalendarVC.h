//
//  CalendarVC.h
//  AVJ_Calendar
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol AVJ_CalenderProtocol
@optional -(void)dateSelected:(NSDate *)selectedDate;
@optional -(void)monthChangedWithNewDate:(NSDate *)date;
@end

@interface CalendarVC : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIPopoverPresentationControllerDelegate>

@property (weak, nonatomic) id delegate;

-(void)markDatesFromArray:(NSArray*) dates withColors:(NSArray*) colors;
-(void)delegateMethod:(NSInteger )index;

@end

