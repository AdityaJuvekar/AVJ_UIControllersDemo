//
//  SwiftCalendarVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 17/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

@objc protocol AVJCalendarDelegate {
    @objc optional func dateSelected(_ selectedDate: Date)
    @objc optional func monthChanged(newDate date: Date)
}

class SwiftCalendarVC: UIViewController {

    @IBOutlet weak var collectionContainerView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var monthButton: UIButton!
    @IBOutlet weak var yearButton: UIButton!
    var currentMonthFlag = false
    var monthFlag = false
    var todayDate = Date()
    let calendar = Calendar(identifier: .gregorian)
    var numberOfDaysInMonth = 0
    var indexOfFirstWeekDay = 6 //0 to start week with Mon, 6 for Sun
    var offset = 0
    var weekDaysNameArray = [String]()
    var monthArray = [String]()
    var monthNamesArray = [String]()
    var yearArray = [String]()
    var markedDatesArray = [Any]()
    var markingColorsArray = [UIColor]()
    var selectedDatesArray = [Date]()
    let selectionColor = UIColor.gray
    var weekdayComponents: DateComponents?
    var day = 0
    var today = 0
    var month = 0
    var year = 0
    var currentMonth = 0
    var currentYear = 0
    var numberOfDaysInPreviousMonth = 0
    @objc weak var delegate: AVJCalendarDelegate?
    var monthYearDrDw: UIPopoverPresentationController?
    @IBOutlet var dayNameLabels: [UILabel]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        indexOfFirstWeekDay = abs(indexOfFirstWeekDay%7)
        setDate()
        prepareMonthAndYearArrays()
        setupCalendar()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshCalenderForDeviceOrientation), name: UIDevice.orientationDidChangeNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(setupCalendarForNewDate), name: Notification.Name.NSCalendarDayChanged, object: nil)
    }
    
    func setupCalendar() {
        var weekdayComponents = calendar.dateComponents([.year,.month,.day], from: todayDate)
        day = weekdayComponents.day!
        month = weekdayComponents.month!
        year = weekdayComponents.year!
        if month==currentMonth && year==currentYear {
            currentMonthFlag = true;
        } else {
            currentMonthFlag = false;
        }
        let df = DateFormatter()
        let monthName = df.monthSymbols[month-1]
        monthButton.setTitle(monthName, for: .normal)
        yearButton.setTitle(String(year), for: .normal)
        weekdayComponents.day = 1;
        let firstDayOfMonth = calendar.date(from: weekdayComponents)
        let wd = calendar.component(.weekday, from: firstDayOfMonth!)
        ((wd-2-indexOfFirstWeekDay) >= 0) ? (offset = wd-2-indexOfFirstWeekDay) : (offset = wd+5-indexOfFirstWeekDay)
        let range = calendar.range(of: .day, in: .month, for: todayDate)
        numberOfDaysInMonth = (range?.count)!
        numberOfDaysInPreviousMonth = (calendar.range(of: .day, in: .month, for: (calendar.date(byAdding: .month, value: -1, to: todayDate))!)?.count)!
        addSwipeGestureRecognizer()
        setWeekdayLabels()
    }
    
    func addSwipeGestureRecognizer() {
        let rightSwipeRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(showPrevious))
        rightSwipeRecognizer.direction = .right
        collectionContainerView.addGestureRecognizer(rightSwipeRecognizer)
        let leftSwipeRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(showNext))
        leftSwipeRecognizer.direction = .left
        collectionContainerView.addGestureRecognizer(leftSwipeRecognizer)
    }
    
    func setWeekdayLabels() {
        let count = weekDaysNameArray.count
        for i in 0..<count {
            let j = i + indexOfFirstWeekDay
            if j < weekDaysNameArray.count {
                dayNameLabels[i].text = weekDaysNameArray[j]
            } else {
                dayNameLabels[i].text = weekDaysNameArray[j - count]
            }
        }
    }

    @IBAction func showMonthDropdown(_ sender: UIButton) {
        monthFlag = true
        self.showDropdownAtView(sender, withArray: monthArray)
    }
    
    @IBAction func showYearDropdown(_ sender: UIButton) {
        monthFlag = false
        self.showDropdownAtView(sender, withArray: yearArray)
    }
    
    @IBAction func showPreviousMonth(_ sender: UIButton) {
        showPrevious()
    }
    
    @IBAction func showNextMonth(_ sender: UIButton) {
        showNext()
    }
    
    @objc func markDatesFromArray(dates: [Any],withColors colors: [UIColor]?) {
        markedDatesArray = dates
        for object in markedDatesArray {
            if let date = object as? Date {
                let year = calendar.component(.year, from: date)
                if !yearArray.contains(String(year)) {
                    yearArray.append(String(year))
                    yearArray.sort(by: {$0<$1})
                }
            }
        }
        if let colors = colors, colors.count > 0 {
            markingColorsArray = colors
        } else {
            markingColorsArray = [UIColor.lightGray]
        }
        collectionView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }
    
}



extension SwiftCalendarVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let numberOfCells = numberOfDaysInMonth + offset
        if numberOfCells%7 != 0 {
            return numberOfCells - numberOfCells%7 + 7
        } else {
            return numberOfCells
        }
    }
    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let normalizedIndex = indexPath.row + 1 - offset
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SwiftDateCell", for: indexPath) as! SwiftDateCell
//        cell.mark = false
//        cell.select = false
//        cell.contentView.backgroundColor = UIColor.white
//        cell.dateLabel.textColor = UIColor.black
//        cell.contentView.layer.borderWidth = 0.5
//
//        //Marked dates
//        for i in 0..<markedDatesArray.count {
//            let dateObject = markedDatesArray[i]
//            var number: Int?
//            if let date = dateObject as? Int {
//                number = date
//            } else if let date = dateObject as? Date {
//                let weekdayComponents = calendar.dateComponents([.year,.month,.day], from: date)
//
//                if weekdayComponents.year==year && weekdayComponents.month==month {
//                    number = weekdayComponents.day!
//                }
//            }
//            if number == normalizedIndex {
//                if i < markingColorsArray.count {
//                    cell.markingColor = markingColorsArray[i]
//                } else {
//                    cell.markingColor = markingColorsArray[0]
//                }
//                cell.mark = true
//            }
//        }
//
//        //Previous month cells
//        if (normalizedIndex < 1) {
//            cell.dateLabel.text = String(numberOfDaysInPreviousMonth+normalizedIndex)
//            cell.dateLabel.textColor = UIColor.lightGray
//            cell.contentView.layer.borderColor = UIColor.lightGray.cgColor
//            return cell
//        }
//
//        //Next month cells
//        if (normalizedIndex > numberOfDaysInMonth) {
//            cell.dateLabel.text = String(normalizedIndex-numberOfDaysInMonth)
//            cell.dateLabel.textColor = UIColor.lightGray
//            cell.contentView.layer.borderColor = UIColor.lightGray.cgColor
//            return cell
//        }
//
//        //Currently displayed month cells
//        cell.contentView.layer.borderColor = UIColor.red.cgColor
//        cell.dateLabel.text = String(normalizedIndex)
//
//        //Selected dates
//        for i in 0..<selectedDatesArray.count {
//            let date = selectedDatesArray[i]
//            var number: Int?
//            let weekdayComponents = calendar.dateComponents([.year,.month,.day], from: date)
//            if weekdayComponents.year==year && weekdayComponents.month==month {
//                number = weekdayComponents.day!
//            }
//            if number == normalizedIndex {
//                cell.selectionColor = selectionColor
//                cell.select = true
//            }
//        }
//
//        //Today's date
//        if currentMonthFlag && normalizedIndex == today {
//            cell.contentView.backgroundColor = UIColor.red
//            cell.dateLabel.textColor = UIColor.white
//        }
//        return cell
//    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let normalizedIndex = indexPath.row + 1 - offset
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SwiftDateCell", for: indexPath) as! SwiftDateCell
        cell.mark = false
        cell.select = false
        cell.contentView.backgroundColor = UIColor.white
        cell.dateLabel.textColor = UIColor.black
        cell.contentView.layer.borderWidth = 0.5

        var currentIndexDate = Date()
        var weekdayComponents = DateComponents()
        
        //Previous month cells
        if (normalizedIndex < 1) {
            currentIndexDate = calendar.date(byAdding: .month, value: -1, to: todayDate)!
            weekdayComponents = calendar.dateComponents([.year,.month,.day], from: currentIndexDate)
            weekdayComponents.day = numberOfDaysInPreviousMonth+normalizedIndex
            cell.contentView.backgroundColor = UIColor.init(white: 0.95, alpha: 1.0)
            cell.dateLabel.textColor = UIColor.lightGray
            cell.contentView.layer.borderColor = UIColor.lightGray.cgColor
         
        //Next month cells
        } else if (normalizedIndex > numberOfDaysInMonth) {
            currentIndexDate = calendar.date(byAdding: .month, value: 1, to: todayDate)!
            weekdayComponents = calendar.dateComponents([.year,.month,.day], from: currentIndexDate)
            weekdayComponents.day = normalizedIndex-numberOfDaysInMonth
            cell.contentView.backgroundColor = UIColor.init(white: 0.95, alpha: 1.0)
            cell.dateLabel.textColor = UIColor.lightGray
            cell.contentView.layer.borderColor = UIColor.lightGray.cgColor
            
        //Currently displayed month cells
        } else {
            weekdayComponents = calendar.dateComponents([.year,.month,.day], from: todayDate)
            weekdayComponents.day = normalizedIndex
            cell.contentView.layer.borderColor = UIColor.red.cgColor
        }
        
        currentIndexDate = calendar.date(from: weekdayComponents)!
        cell.date = currentIndexDate
        cell.dateLabel.text = String(calendar.component(.day, from: cell.date ?? Date()))
        
        //Marked dates
        for i in 0..<markedDatesArray.count {
            let dateObject = markedDatesArray[i]
            if let date = dateObject as? Int, date == Int(cell.dateLabel.text ?? "0") {
                (i < markingColorsArray.count) ? (cell.markingColor = markingColorsArray[i]) : (cell.markingColor = markingColorsArray[0])
                cell.mark = true
            } else if let date = dateObject as? Date, calendar.startOfDay(for: cell.date!) == calendar.startOfDay(for: date) {
                (i < markingColorsArray.count) ? (cell.markingColor = markingColorsArray[i]) : (cell.markingColor = markingColorsArray[0])
                cell.mark = true
            }
        }

        //Selected dates
        for date in selectedDatesArray {
            if calendar.startOfDay(for: date) == calendar.startOfDay(for: cell.date!) {
                cell.selectionColor = selectionColor
                cell.select = true
            }
        }

        //Today's date
        if currentMonthFlag && normalizedIndex == today {
            cell.contentView.backgroundColor = UIColor.red
            cell.dateLabel.textColor = UIColor.white
        }
        return cell;
    }
    
}



extension SwiftCalendarVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! SwiftDateCell
        let normalizedIndex = indexPath.row + 1 - offset;
        if (normalizedIndex < 1) {
            showPrevious()
        } else if (normalizedIndex > numberOfDaysInMonth){
            showNext()
        } else {
//            var weekdayComponents = calendar.dateComponents([.year,.month,.day], from: todayDate)
//            weekdayComponents.day = Int(cell.dateLabel.text!)
//            let selectedDate = calendar.date(from: weekdayComponents)
            let selectedDate = cell.date
            delegate?.dateSelected?(selectedDate!)
            
            //To mark/unmark the selected date
            cell.selectionColor = selectionColor
            cell.select = !cell.select
            if let selectedDate = selectedDate {
                if selectedDatesArray.contains(selectedDate) {
                    selectedDatesArray.removeAll { (date) -> Bool in
                        return date == selectedDate
                    }
                } else {
                    selectedDatesArray.append(selectedDate)
                }
            }
        }
    }
    
}



extension SwiftCalendarVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width/7, height: collectionView.frame.size.height/6.33)
    }
    
}



extension SwiftCalendarVC: UIPopoverPresentationControllerDelegate {
    func setDate() {
        today = calendar.component(.day, from: todayDate)
        currentMonth = calendar.component(.month, from: todayDate)
        currentYear = calendar.component(.year, from: todayDate)
    }
    
    func prepareMonthAndYearArrays() {
        weekDaysNameArray = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
        monthArray = ["Jan(01)","Feb(02)","Mar(03)","Apr(04)","May(05)","Jun(06)","Jul(07)","Aug(08)","Sep(09)","Oct(10)","Nov(11)","Dec(12)"];
        monthNamesArray = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        yearArray = ["2015","2016","2017","2018","2019","2020","2021","2022","2023","2024"];
    }
    
    func showDropdownAtView(_ view: UIView, withArray array: [String]) {
        let dropDown = self.storyboard?.instantiateViewController(withIdentifier: "SwMonthYearTable") as! SwMonthYearTable
        dropDown.delegate = self
        dropDown.dataArray = array
        dropDown.preferredContentSize = CGSize(width: 70,height: 120)
        dropDown.modalPresentationStyle = UIModalPresentationStyle.popover
    
        monthYearDrDw = dropDown.popoverPresentationController
        monthYearDrDw?.delegate = self
        monthYearDrDw?.sourceView = self.view
        let rect = self.view.convert(view.frame, from: view.superview)
        monthYearDrDw?.sourceRect = rect
        monthYearDrDw?.popoverBackgroundViewClass = SwtDropdownBGView.self
        monthYearDrDw?.permittedArrowDirections = .up
        self.present(dropDown, animated: false, completion: nil)
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    @objc func showPrevious() {
        todayDate = calendar.date(byAdding: .month, value: -1, to: todayDate)!
        changeMonth(1)
    }
    
    @objc func showNext() {
        todayDate = calendar.date(byAdding: .month, value: 1, to: todayDate)!
        changeMonth(-1)
    }
    
    func changeMonth(_ i: Int) {
        setupCalendar()
        var capturedImageView: UIImageView? = UIImageView.init(frame: collectionView.bounds)
        capturedImageView?.image = imageWithView(collectionView)
        collectionContainerView.addSubview(capturedImageView!)
        collectionView.reloadData()
        delegate?.monthChanged?(newDate: todayDate)
        UIView.animate(withDuration: 0.4,
                       animations: {
                        capturedImageView?.transform = CGAffineTransform(translationX: CGFloat(i)*self.collectionView.frame.size.width, y: 0)
        }) { finished in
            if finished {
                capturedImageView?.removeFromSuperview()
                capturedImageView = nil
                
            }
        }
    }
    
    func imageWithView(_ view: UIView) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.isOpaque, 0.0);
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
    
        let img = UIGraphicsGetImageFromCurrentImageContext();
    
        UIGraphicsEndImageContext();
        return img!;
    }
    
    func delegateMethod(index: Int)  {
        var weekdayComponents = calendar.dateComponents([.year,.month,.day], from: todayDate)
        if monthFlag {
            monthButton.setTitle(monthNamesArray[index], for: .normal)
            weekdayComponents.month = index + 1
        } else {
            yearButton.setTitle(yearArray[index], for: .normal)
            weekdayComponents.year = Int(yearArray[index])
        }
        todayDate = calendar.date(from: weekdayComponents)!
        setupCalendar()
        collectionView.reloadData()
    }
    
    @objc func refreshCalenderForDeviceOrientation() {
        collectionView.reloadData()
    }
    
    @objc func setupCalendarForNewDate() {
        self.setDate()
        self.setupCalendar()
        collectionView.reloadData()
    }

}
