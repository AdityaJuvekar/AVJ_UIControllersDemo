//
//  MarkerView.m
//  AVJ_Calendar
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "MarkerView.h"

@implementation MarkerView


- (void)drawRect:(CGRect)rect {
    if (_markingColor) {
        CGContextRef context = UIGraphicsGetCurrentContext();
        float frameWidth = self.frame.size.width;
        float frameHeight = self.frame.size.height;
        float circleRadius = MIN(frameWidth, frameHeight)/2 - 3;
        CGContextBeginPath(context);
        
        //Triangle at top right
        CGContextMoveToPoint(context, frameWidth-16, 4);
        CGContextAddLineToPoint(context, frameWidth-4, 4);
        CGContextAddLineToPoint(context, frameWidth-4, 16);
        CGContextClosePath(context);
        CGContextSetFillColorWithColor(context, _markingColor.CGColor);
        CGContextSetShadow(context, CGSizeMake(-1.0, 2.0), 1);
        CGContextFillPath(context);
        
        //Bar at the top
//        CGContextMoveToPoint(context, 8, 4);
//        CGContextAddLineToPoint(context, frameWidth-8, 4);
//        CGContextSetLineWidth(context, 4);
//        CGContextSetStrokeColorWithColor(context, _markingColor.CGColor);
//        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
//        CGContextStrokePath(context);
        
        //Bar at the bottom
//        CGContextMoveToPoint(context, 8, frameHeight-5);
//        CGContextAddLineToPoint(context, frameWidth-8, frameHeight-5);
//        CGContextSetLineWidth(context, 4);
//        CGContextSetStrokeColorWithColor(context, _markingColor.CGColor);
//        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
//        CGContextStrokePath(context);
        
        //Dot at top right
//        CGContextAddArc(context, frameWidth-8, 8, 4, 0, 2*M_PI, 1);
//        CGContextSetFillColorWithColor(context, _markingColor.CGColor);
//        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
//        CGContextFillPath(context);
        
        //Square at bottom right
//        CGContextAddRect(context, CGRectMake(frameWidth-8, frameHeight-8, 6, 6));
//        CGContextSetFillColorWithColor(context, _markingColor.CGColor);
//        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
//        CGContextFillPath(context);
        
        //Circle around label
//        CGContextAddArc(context, frameWidth/2, frameHeight/2, circleRadius, 0, 2*M_PI, 1);
//        //CGContextSetFillColorWithColor(context, _markingColor.CGColor);
//        CGContextSetStrokeColorWithColor(context, _markingColor.CGColor);
//        CGContextSetLineWidth(context, 2.5);
//        //CGContextFillPath(context);
//        CGContextStrokePath(context);

    }
    
    if (_selectionColor) {
        CGContextRef context = UIGraphicsGetCurrentContext();
        float frameWidth = self.frame.size.width;
        float frameHeight = self.frame.size.height;
        float circleRadius = MIN(frameWidth, frameHeight)/2 - 3;
        CGContextBeginPath(context);
        
        //Triangle at top right
//        CGContextMoveToPoint(context, frameWidth-16, 4);
//        CGContextAddLineToPoint(context, frameWidth-4, 4);
//        CGContextAddLineToPoint(context, frameWidth-4, 16);
//        CGContextClosePath(context);
//        CGContextSetFillColorWithColor(context, _selectionColor.CGColor);
//        CGContextSetShadow(context, CGSizeMake(-1.0, 2.0), 1);
//        CGContextFillPath(context);
        
        //Bar at the top
        //        CGContextMoveToPoint(context, 8, 4);
        //        CGContextAddLineToPoint(context, frameWidth-8, 4);
        //        CGContextSetLineWidth(context, 4);
        //        CGContextSetStrokeColorWithColor(context, _selectionColor.CGColor);
        //        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
        //        CGContextStrokePath(context);
        
        //Bar at the bottom
        //        CGContextMoveToPoint(context, 8, frameHeight-5);
        //        CGContextAddLineToPoint(context, frameWidth-8, frameHeight-5);
        //        CGContextSetLineWidth(context, 4);
        //        CGContextSetStrokeColorWithColor(context, _selectionColor.CGColor);
        //        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
        //        CGContextStrokePath(context);
        
        //Dot at top right
        //        CGContextAddArc(context, frameWidth-8, 8, 4, 0, 2*M_PI, 1);
        //        CGContextSetFillColorWithColor(context, _selectionColor.CGColor);
        //        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
        //        CGContextFillPath(context);
        
        //Square at bottom right
        //        CGContextAddRect(context, CGRectMake(frameWidth-8, frameHeight-8, 6, 6));
        //        CGContextSetFillColorWithColor(context, _selectionColor.CGColor);
        //        CGContextSetShadow(context, CGSizeMake(-1.0, 1.5), 1);
        //        CGContextFillPath(context);
        
        //Circle around label
                CGContextAddArc(context, frameWidth/2, frameHeight/2, circleRadius, 0, 2*M_PI, 1);
                //CGContextSetFillColorWithColor(context, _selectionColor.CGColor);
                CGContextSetStrokeColorWithColor(context, _selectionColor.CGColor);
                CGContextSetLineWidth(context, 2.5);
                //CGContextFillPath(context);
                CGContextStrokePath(context);
        
    }
}


@end
