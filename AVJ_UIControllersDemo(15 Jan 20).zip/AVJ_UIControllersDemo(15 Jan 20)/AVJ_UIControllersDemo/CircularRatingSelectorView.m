//
//  CircularRatingSelectorView.m
//  SpeedBanking
//
//  Created by admin on 02/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import "CircularRatingSelectorView.h"

@implementation CircularRatingSelectorView


- (void)drawRect:(CGRect)rect {
    CGPoint centre = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    float arcWidth = _arcWidth;
    for (int i=0; i<_nos; i++) {
        [self drawArcWithCentre:centre radius:_radius arcWidth:arcWidth startAngle:-M_PI_2 + i*2*M_PI/_nos + _cutAngle endAngle:-M_PI_2 + 2*M_PI/_nos + i*2*M_PI/_nos - _cutAngle andColor:[UIColor darkGrayColor]];
    }

}

-(void)drawArcWithCentre:(CGPoint)centre radius:(float)radius arcWidth:(float)arcWidth startAngle:(float)startAngle endAngle:(float)endAngle andColor:(UIColor*)color {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddArc(path, NULL, centre.x, centre.y, radius, startAngle, endAngle, NO);
    CGContextAddPath(context, path);
    CGContextSetStrokeColorWithColor(context, color.CGColor);
    CGContextSetLineWidth(context, arcWidth);
    CGContextSetShadowWithColor(context, CGSizeMake(3.5f, 2.5f), 5.0f, [UIColor colorWithWhite:.2 alpha:0.4].CGColor);
    CGContextStrokePath(context);
    CGContextRestoreGState(context);
}

@end
