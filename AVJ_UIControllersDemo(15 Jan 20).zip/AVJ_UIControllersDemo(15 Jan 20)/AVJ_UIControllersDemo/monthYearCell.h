//
//  monthYearCell.h
//  AVJ_Calendar
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface monthYearCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *cellLabel;
@end
