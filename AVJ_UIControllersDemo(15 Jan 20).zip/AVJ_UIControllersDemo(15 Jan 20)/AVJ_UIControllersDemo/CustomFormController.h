//
//  CustomFormController.h
//  ECRFmainScreen
//
//  Created by admin on 06/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownController.h"
#import "DropDownCell.h"
#import "EmailPVC.h"
#import "PanPVC.h"
#import "MobilePVC.h"
#import "ChequePVC.h"


@interface CustomFormController : UIViewController<UIPopoverPresentationControllerDelegate,UITextFieldDelegate,MobilePVCDelegate,ChequePVCDelegate,EmailPVCDelegate,PanPVCDelegate,DDTDelegate>

@property (weak, nonatomic) IBOutlet UIView *topLeftOuterView;
@property (weak, nonatomic) IBOutlet UIView *bottomLeftOuterView;
@property (weak, nonatomic) IBOutlet UIView *bottomRightOuterView;
@property (weak, nonatomic) IBOutlet UIView *topRightOuterView;
@property (weak, nonatomic) IBOutlet UIView *topLeftInnerView;
@property (weak, nonatomic) IBOutlet UIView *bottomLeftInnerView;
@property (weak, nonatomic) IBOutlet UIView *bottomRightInnerView;
@property (weak, nonatomic) IBOutlet UIView *topRightInnerView;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UILabel *PANLabel;
@property (weak, nonatomic) IBOutlet UILabel *mobileLabel;
@property (weak, nonatomic) IBOutlet UILabel *chequeLabel;

@property (weak, nonatomic) IBOutlet UITextField *textFieldAcc;
@property (weak, nonatomic) IBOutlet UITextField *textFieldHol;

- (IBAction)flipperPressed:(UIButton *)sender;

@property (strong, nonatomic) NSMutableArray *accountNoArray;
@property (strong, nonatomic) NSMutableArray *holderNameArray;
@property (strong, nonatomic) NSMutableArray *holderNoArray;

@property (strong, nonatomic) NSString *accountNumber;
@property (strong, nonatomic) NSString *holderName;
@property (strong, nonatomic) NSString *holderNumber;

@property (nonatomic) UIPopoverPresentationController *Popup;
@property (nonatomic) UIPopoverPresentationController *Dropdown;

@property (nonatomic) UITextField *currentfield;

@property (nonatomic) UIViewController *PVC;

@property (weak, nonatomic) IBOutlet UIView *custNameView;
@property (weak, nonatomic) IBOutlet UILabel *custNameLabel;

@property (nonatomic) UIView *superView;
@property (nonatomic) UIView *frontView;
@property (nonatomic) UIView *middleView;
@property (nonatomic) UIView *backView;
@property (nonatomic) UIImageView *imageView;
@property (nonatomic) UIImage *image;

@property (nonatomic) CGRect centralFrame;
@property (nonatomic) CGRect convertedFrame;



- (void)dropDownclicked:(UITextField *)textField;

@end
