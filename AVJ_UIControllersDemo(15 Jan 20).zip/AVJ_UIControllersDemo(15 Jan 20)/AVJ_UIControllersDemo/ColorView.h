//
//  ColorView.h
//  AVJ_UIControllersDemo
//
//  Created by admin on 23/01/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColorView : UIView

@end
