//
//  MagnifierView.h
//  AVJ_Calendar
//
//  Created by Apple on 16/05/18.
//  Copyright © 2018 Apple. All rights reserved.
//
#define Radius 120
#import <UIKit/UIKit.h>

@interface MagnifierView : UIView

@property (nonatomic, strong) UIView *viewToMagnify;
@property (nonatomic) CGPoint touchPoint;

@end
