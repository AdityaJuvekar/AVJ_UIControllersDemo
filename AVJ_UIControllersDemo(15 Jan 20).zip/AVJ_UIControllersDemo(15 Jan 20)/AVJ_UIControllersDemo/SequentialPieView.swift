//
//  SequentialPieView.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 09/12/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

struct SequentialPieStruct {
    var value: Double
    var color: UIColor
    var labelText: NSAttributedString
    fileprivate var index: Int
    
    static var counter = 0
    
    init(value val: Double,color clr: UIColor,image img: UIImage,labelText text: NSAttributedString) {
        self.value = val
        self.color = clr
        //self.image = img
        self.labelText = text
        self.index = SequentialPieStruct.counter
        SequentialPieStruct.counter += 1
    }
}

class SequentialPieView: UIView {

    var value : CGFloat = CGFloat(0.0)
    var color : UIColor = UIColor.red
    
    private var pieValue = CGFloat(0.0)
    private var startEndAnglesArray: [(startAngle: Double, endAngle: Double)]?
    private var layerArray: [CALayer] = []
    private var viewArray: [UIView] = []
    let shapelayer = CAShapeLayer()
    var arcCentre = CGPoint()
    var radius = CGFloat(0.0)
    let lineWidth: CGFloat = 36
    var endPoint = CGPoint()
    var distance: CGFloat = 0.0
    private var ninety = CGFloat.pi/2
    private var oneEighty = CGFloat.pi
    private var twoSeventy = CGFloat.pi*(3/2)
    private var threeSixty = CGFloat.pi*2
    private var selectedIndex = -1
    private var maxRadius: CGFloat = 0.0
    let maxRadFactor: CGFloat = 1.2
    private var centre = CGPoint(x: 0, y: 0)

    var dataArray: [SequentialPieStruct]? {
        didSet {
            removeAllPies()
            removeAllSubviews()
            SequentialPieStruct.counter = 0
            selectedIndex = -1
            var totalValue = 0.0
            guard dataArray != nil else { return }
            for data in dataArray! {
                totalValue = totalValue + data.value
            }
            
            for i in 0..<dataArray!.count {
                dataArray![i].value = (dataArray![i].value/totalValue)*Double(threeSixty)
                //                if maxValue < dataArray![i].value {
                //                    maxValue = dataArray![i].value
                //                    selectedIndex = i
                //                }
            }
            self.setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let dataArray = dataArray else { return }
        
        startEndAnglesArray?.removeAll()
        centre = CGPoint(x: frame.width/2.0, y: frame.height/2.0)
        radius = min(frame.width, frame.height)/2.4
        maxRadius = radius*maxRadFactor
        var shiftAngle = -(Double.pi/2)
        var maxValueTuple: (strAng:Double, endAgl:Double, arcColor:UIColor, text:NSAttributedString) = (0,0,UIColor.clear,NSAttributedString())
        var maxValArray: [(strAng:Double, endAgl:Double, arcColor:UIColor, text:NSAttributedString)]?
        
        for i in 0..<dataArray.count {
            let endAngle = (shiftAngle+dataArray[i].value)
            if dataArray[i].index == selectedIndex {
                maxValueTuple = (shiftAngle, endAngle, dataArray[i].color, dataArray[i].labelText)
                if maxValArray != nil {
                    maxValArray?.append(maxValueTuple)
                } else {
                    maxValArray = [maxValueTuple]
                }
                if startEndAnglesArray != nil {
                    startEndAnglesArray?.append((shiftAngle, endAngle))
                } else {
                    startEndAnglesArray = [(shiftAngle, endAngle)]
                }
            } else {
                if startEndAnglesArray != nil {
                    startEndAnglesArray?.append((shiftAngle, endAngle))
                } else {
                    startEndAnglesArray = [(shiftAngle, endAngle)]
                }
                drawArcWithCentre(centre, radius: radius, arcWidth: 0, startAngle: CGFloat(shiftAngle), endAngle: CGFloat(endAngle), andColor: dataArray[i].color,andText: dataArray[i].labelText)
//                drawArcWithCentre(centre, radius: radius, arcWidth: 0, startAngle: CGFloat(shiftAngle), endAngle: CGFloat(endAngle), andColor: dataArray[i].color)
            }
            shiftAngle = endAngle
        }
        if let maxValData = maxValArray {
            for maxValTuple in maxValData {
                drawArcWithCentre(centre, radius: maxRadius, arcWidth: lineWidth, startAngle: CGFloat(maxValTuple.strAng), endAngle: CGFloat(maxValTuple.endAgl), andColor: maxValTuple.arcColor,andText: maxValTuple.text)
            }
        }
    }
    
    private func drawArcWithCentre(_ centre: CGPoint,radius rad: CGFloat,arcWidth arcWid: CGFloat,startAngle srtAngle: CGFloat,endAngle endAgl: CGFloat,andColor color :UIColor,andText text: NSAttributedString) {
        print("StartAng: \(srtAngle), EndAng: \(endAgl)")
        let arcWidth: CGFloat = 40
        let path = UIBezierPath(arcCenter: centre, radius: rad+arcWidth/2.0, startAngle: srtAngle, endAngle: endAgl, clockwise: true)
        path.addLine(to: CGPoint(x: (rad-arcWidth/2.0)*cos(endAgl)+centre.x, y: (radius-arcWidth/2.0)*sin(endAgl)+centre.y))
        path.addArc(withCenter: centre, radius: rad-arcWidth/2.0, startAngle: endAgl, endAngle: srtAngle, clockwise: false)
        path.close()
        color.setFill()
        path.fill()
        let intermediateAng = srtAngle + (endAgl-srtAngle)/2.0
        addLabel(atPoint: CGPoint(x: rad*cos(intermediateAng)+centre.x, y: rad*sin(intermediateAng)+centre.y), withText: text)
    }
    
    private func addLabel(atPoint point: CGPoint, withText text: NSAttributedString) {
        let strAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 13),
            .foregroundColor: UIColor.white
        ]
        let attrStr = NSMutableAttributedString(attributedString: text)
        attrStr.setAttributes(strAttributes, range: NSRange(location: 0, length: attrStr.length))
        //let attrStr = NSAttributedString(string: text, attributes: strAttributes)
        let labelHeight: CGFloat = 32
        let labelWidth = attrStr.width(withConstrainedHeight: labelHeight)
        let label = UILabel(frame: CGRect(x: point.x-labelWidth/2, y: point.y-labelHeight/2, width: labelWidth, height: labelHeight))
        label.attributedText = attrStr
        addSubview(label)
        viewArray.append(label)
    }
    
//    private func drawArcWithCentre(_ centre: CGPoint,radius rad: CGFloat,arcWidth arcWid: CGFloat,startAngle srtAngle: CGFloat,endAngle endAgl: CGFloat,andColor color :UIColor,andText text: NSAttributedString) {
//        print("StartAng: \(srtAngle), EndAng: \(endAgl)")
//        let intermediateAng = srtAngle + (endAgl-srtAngle)/2.0
//        let path = CGMutablePath()
//        path.move(to: CGPoint(x: (radius+arcWid/2.0)*cos(srtAngle)+centre.x, y: (radius+arcWid/2)*sin(srtAngle)+centre.y))
//        path.addArc(center: centre, radius: radius+arcWid/2.0, startAngle: srtAngle, endAngle: endAgl, clockwise: false)
//
////        path.addLine(to: CGPoint(x: (radius-arcWid/2.0)*cos(endAgl)+centre.x, y: (radius-arcWid/2.0)*sin(endAgl)+centre.y))
////        path.addArc(center: centre, radius: radius-arcWid/2, startAngle: endAgl, endAngle: srtAngle, clockwise: false)
////        path.closeSubpath()
//
//        let shapelayer = CAShapeLayer()
//        shapelayer.path = path
//        shapelayer.strokeColor = UIColor.black.cgColor
//        shapelayer.lineWidth = 1
//        shapelayer.fillColor = color.cgColor
//        shapelayer.fillMode = CAMediaTimingFillMode.forwards
//        shapelayer.strokeEnd = 0
//
//        let animation = CABasicAnimation(keyPath: "strokeEnd")
//        animation.toValue = 1
//        animation.duration = 5
//        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
//        animation.fillMode = CAMediaTimingFillMode.both
//        animation.isRemovedOnCompletion = false
//        shapelayer.add(animation, forKey: animation.keyPath)
//
//        if rad == maxRadius {
////            shapelayer.shadowOffset = CGSize(width: 10, height: 3)
////            shapelayer.shadowColor = UIColor.black.cgColor
////            shapelayer.shadowRadius = 6
////            shapelayer.shadowOpacity = 0.4
//            let endPath = CGMutablePath()
//            endPath.move(to:  CGPoint(x: (maxRadius+arcWid/2)*cos(srtAngle)+centre.x, y: (maxRadius+arcWid/2)*sin(srtAngle)+centre.y))
//            endPath.addArc(center: centre, radius: maxRadius+arcWid/2, startAngle: srtAngle, endAngle: endAgl, clockwise: false)
//            endPath.addLine(to: CGPoint(x: (maxRadius-arcWid/2)*cos(endAgl)+centre.x, y: (maxRadius-arcWid/2)*sin(endAgl)+centre.y))
//            endPath.addArc(center: centre, radius: maxRadius-arcWid/2, startAngle: endAgl, endAngle: srtAngle, clockwise: false)
//            endPath.closeSubpath()
//
//            let animation = CABasicAnimation(keyPath: "path")
//            animation.toValue = endPath
//            animation.duration = 0.3
//            animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
//            animation.fillMode = CAMediaTimingFillMode.both
//            animation.isRemovedOnCompletion = false
//            shapelayer.add(animation, forKey: animation.keyPath)
//        } else {
////            shapelayer.shadowOffset = CGSize(width: 5, height: 1.5)
////            shapelayer.shadowColor = UIColor.black.cgColor
////            shapelayer.shadowRadius = 4
////            shapelayer.shadowOpacity = 0.3
//        }
//        self.layer.addSublayer(shapelayer)
//        layerArray.append(shapelayer)
//        addLabel(text, atAngle: intermediateAng, radius: rad)
//    }
    
    @objc private func animate() {
        let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        
        basicAnimation.toValue = 1
        basicAnimation.duration = 1
        basicAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
        basicAnimation.fillMode = CAMediaTimingFillMode.forwards
        basicAnimation.isRemovedOnCompletion = false
        
        shapelayer.add(basicAnimation, forKey: "nyam")
    }
    
    func removeAllPies() {
        for shapelayer in layerArray {
            shapelayer.removeAllAnimations()
            shapelayer.removeFromSuperlayer()
        }
        layerArray.removeAll()
    }
    
    func removeAllSubviews() {
        for view in viewArray {
            view.removeFromSuperview()
        }
        viewArray.removeAll()
    }
}
