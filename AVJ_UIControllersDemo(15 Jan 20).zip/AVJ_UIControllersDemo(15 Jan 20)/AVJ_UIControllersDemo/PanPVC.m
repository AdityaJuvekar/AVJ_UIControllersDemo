//
//  PanPVC.m
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "PanPVC.h"

@interface PanPVC ()

@end

@implementation PanPVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _cancelButton.layer.cornerRadius = 4;
    _confirmButton.layer.cornerRadius = 4;
    _cancelButton.clipsToBounds = YES;
    _confirmButton.clipsToBounds = YES;
    _inputField.text = _PAN;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.superview.layer.cornerRadius = 0;
    self.view.superview.clipsToBounds = NO;
}

- (IBAction)cancelClicked:(UIButton *)sender {
    [_delegate dismissPopUp];
}

- (IBAction)confirmClicked:(UIButton *)sender {
    NSString *PanNo = [_inputField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (PanNo.length == 0) {
        [self showAlertWithTitle:nil andMessage:@"Please enter PAN"];
    }
    else if (![self validatePanWithString:PanNo]) {
        [self showAlertWithTitle:nil andMessage:@"Please enter a valid PAN"];
    }
    else {
        if (![[PanNo uppercaseString] isEqualToString:[_PAN uppercaseString]]) {
            [_delegate setPANnumber:PanNo];
        }
        [_delegate captureAndSetImage];
        [_delegate dismissPopUp];
    }
}

- (BOOL)validatePanWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Za-z]{5}+[0-9]{4}+[A-Za-z]{1}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString*)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];
                             
                         }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}



@end
