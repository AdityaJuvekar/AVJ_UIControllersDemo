//
//  ProgressBarVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 17/01/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

func RGBCOLOR(_ red: CGFloat, _ green: CGFloat, _ blue: CGFloat) -> UIColor {
    return UIColor(red: red/255.0,
                   green: green/255.0,
                   blue: blue/255.0,
                   alpha: 1.0)
}

let GradientBlue = RGBCOLOR(85, 82, 199)
let GradientPurple = RGBCOLOR(42, 134, 230)

class ProgressBarVC: UIViewController {

    @IBOutlet weak var blackGlass: BlackGlass!
    
    @IBOutlet weak var progressBar: UIView!
    
    var minuteRepeater: Timer?
    var displayLink: CADisplayLink?
    var distanceFactor: CGFloat = 2.0
    let dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stopProgressAnimation()
        dateFormatter.dateFormat = "HH:mm"
    }
    
    @IBAction func startStopProgressAnimation(_ sender: UIButton) {
        if sender.tag == 0 {
            animateProgressBar()
        } else {
            stopProgressAnimation()
        }
    }
    
    func animateProgressBar() {
        for i in 1...13 {
            let fragView = progressBar.viewWithTag(i)
            UIView.animate(withDuration: 0.4,
                            delay: TimeInterval(Double(i)*0.07),
                            options: [.repeat,.autoreverse],
                            animations: {
                                fragView?.alpha = 1
                                fragView?.transform = CGAffineTransform.init(scaleX: 1, y: 1.3)
                                //fragView?.backgroundColor = GradientPurple
            })
            UIView.animate(withDuration: 0.05) {
                fragView?.backgroundColor = GradientPurple
            }
        }
    }
    
    func stopProgressAnimation() {
        for i in 1...13 {
            let fragView = progressBar.viewWithTag(i)
            fragView?.layer.removeAllAnimations()
            fragView?.backgroundColor = GradientBlue
            fragView?.alpha = 0
            fragView?.transform = CGAffineTransform.identity
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let now: Date = Date()
        let calendar: Calendar = Calendar.current
        let currentSeconds: Int = calendar.component(.second, from: now)
        minuteRepeater = Timer(fireAt: now.addingTimeInterval(Double(60 - currentSeconds)),
                               interval: 60,
                               target: self,
                               selector: #selector(timerFired(_:)),
                               userInfo: nil,
                               repeats: true)
        
        guard let minuteRepeater = minuteRepeater else { return }
        RunLoop.main.add(minuteRepeater, forMode: .default)
        minuteRepeater.fire()
    }
    
    @objc func timerFired(_ timer: Timer) {
        distanceFactor = 2
        let currentTimeStr = dateFormatter.string(from: Date())
        blackGlass.oldTimeStr = blackGlass.currentTimeStr
        blackGlass.currentTimeStr = currentTimeStr
        blackGlass.changedNumberIndexes = []
        displayLink = CADisplayLink(target: self, selector: #selector(updateBlackGlass))
        guard let displayLink = displayLink else { return }
        if #available(iOS 10.0, *) {
            displayLink.preferredFramesPerSecond = 15
        } else {
            displayLink.frameInterval = 15
        }
        displayLink.add(to: .main, forMode: .default)
    }
    
    @objc func updateBlackGlass() {
        if distanceFactor > 1 {
            blackGlass.distanceFactor = distanceFactor - 1
        } else if distanceFactor == 1 {
            blackGlass.distanceFactor = 0
        } else {
            blackGlass.distanceFactor = 1 + distanceFactor
        }
        
        distanceFactor -= 0.05
        
        blackGlass.setNeedsDisplay()
        
        guard let displayLink = displayLink else { return }
        if distanceFactor < 0 {
            displayLink.isPaused = true
            displayLink.invalidate()
            displayLink.remove(from: .main, forMode: .default)
        }
    }

}
