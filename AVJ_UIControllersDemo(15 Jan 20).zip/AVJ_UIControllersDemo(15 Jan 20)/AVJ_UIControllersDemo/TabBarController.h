//
//  TabBarController.h
//  AVJ_UIControllersDemo
//
//  Created by admin on 22/02/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController

@end
