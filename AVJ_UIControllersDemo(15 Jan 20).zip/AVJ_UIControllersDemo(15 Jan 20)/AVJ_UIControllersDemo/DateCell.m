//
//  DateCell.m
//  AVJ_Calendar
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "DateCell.h"

@implementation DateCell

-(void)awakeFromNib {
    [super awakeFromNib];
}

-(void)setMark:(BOOL)mark {
    _mark = mark;
    _markingView.markingColor = nil;
    if (_mark) {
        _markingView.markingColor = _markingColor;
    }
    [_markingView setNeedsDisplay];
}

-(void)setSelect:(BOOL)select {
    _select = select;
    _markingView.selectionColor = nil;
    if (_select) {
        _markingView.selectionColor = _selectionColor;
    }
    [_markingView setNeedsDisplay];
}

@end
