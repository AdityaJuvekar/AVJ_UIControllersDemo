//
//  BlackGlass.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 23/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class BlackGlass: UIView {

    var distanceFactor: CGFloat = 1.0
    var pathsArray = [UIBezierPath]()
    var oldTimeStr = String()
    var currentTimeStr = String()
    var dateStr = String()
    var changedNumberIndexes = [Int]()
    
    override func draw(_ rect: CGRect) {
        pathsArray.removeAll()
        
        if oldTimeStr.count > 0 {
            for i in 0..<oldTimeStr.count {
                if oldTimeStr[i] != currentTimeStr[i] {
                    changedNumberIndexes.append(i)
                }
            }
        }
        
        let fontSize: Float = 121
        
        let font = UIFont(name: "HelveticaNeue-CondensedBold", size: CGFloat(fontSize))!
        
        var unichars = [UniChar](currentTimeStr.utf16)
        var oldUnichars = [UniChar](oldTimeStr.utf16)
        
        var glyphs = [CGGlyph](repeating: 0, count: unichars.count)
        var oldGlyphs = [CGGlyph](repeating: 0, count: oldUnichars.count)
        
        let gotGlyphs = CTFontGetGlyphsForCharacters(font, &unichars, &glyphs, unichars.count)
        CTFontGetGlyphsForCharacters(font, &oldUnichars, &oldGlyphs, oldUnichars.count)
        
        if gotGlyphs {
            
            for i in 0..<glyphs.count {
                let cgpath = CTFontCreatePathForGlyph(font, (changedNumberIndexes.contains(i) && distanceFactor <= 1) ? oldGlyphs[i] : glyphs[i], nil)!
                var inverse = CGAffineTransform(scaleX: 1, y: -1).translatedBy(x: ((i>0) ? pathsArray[i-1].cgPath.boundingBox.origin.x + pathsArray[i-1].cgPath.boundingBox.width : 44) + CGFloat(sqrtf(fontSize))*(changedNumberIndexes.contains(i)
                    ? distanceFactor : 1), y: -cgpath.boundingBox.height - ((i==2) ? (200 + (pathsArray[i-1].cgPath.boundingBox.height - cgpath.boundingBox.height)/2) : 200))
                let path = UIBezierPath(cgPath: cgpath.copy(using: &inverse)!)
                pathsArray.append(path)
            }
            
            
            let dateFontSize: Float = 47
            let dateFont = UIFont(name: "HelveticaNeue-CondensedBold", size: CGFloat(dateFontSize))!
            var dateUnichars = [UniChar](dateStr.utf16)
            
            var dateGlyphs = [CGGlyph](repeating: 0, count: dateUnichars.count)
            
            let gotDateGlyphs = CTFontGetGlyphsForCharacters(dateFont, &dateUnichars, &dateGlyphs, dateUnichars.count)
            
            var firstCharHeight: CGFloat = 0
            var isBlankSpace = false
            if gotDateGlyphs {
                for i in 0..<dateGlyphs.count {
                    if let cgpath = CTFontCreatePathForGlyph(dateFont, dateGlyphs[i], nil) {
                        var inverse = CGAffineTransform(scaleX: 1, y: -1).translatedBy(x: (i>0) ? (pathsArray.last?.cgPath.boundingBox.origin.x ?? 44) + (pathsArray.last?.cgPath.boundingBox.width ?? 0) + (isBlankSpace ? 2.5*CGFloat(sqrtf(dateFontSize)) : CGFloat(sqrtf(dateFontSize))) : 44 + CGFloat(sqrtf(fontSize)), y: -cgpath.boundingBox.height - 320 - (i>0 ? (firstCharHeight - cgpath.boundingBox.height) : 0))
                        if i == 0 {
                            firstCharHeight = cgpath.boundingBox.height
                        }
                        let path = UIBezierPath(cgPath: cgpath.copy(using: &inverse)!)
                        pathsArray.append(path)
                        isBlankSpace = false
                    } else {
                        isBlankSpace = true
                    }
                }
            }
            
            let timePath = UIBezierPath()
            for path in pathsArray {
                timePath.append(path)
            }
            timePath.append(UIBezierPath(rect: self.bounds))
            
            let maskLayer = CAShapeLayer()
            maskLayer.fillRule = CAShapeLayerFillRule.evenOdd
            maskLayer.fillMode = CAMediaTimingFillMode.forwards
            maskLayer.path = timePath.cgPath
            
            self.layer.mask = maskLayer
        }
    }

}


extension String {
    subscript (i: Int) -> Character {
        return self[index(startIndex, offsetBy: i)]
    }
}
