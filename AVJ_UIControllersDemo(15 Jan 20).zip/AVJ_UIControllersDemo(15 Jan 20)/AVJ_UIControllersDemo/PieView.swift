//
//  PieView.swift
//  PieChart
//
//  Created by admin on 22/03/18.
//  Copyright © 2018 AXIS. All rights reserved.
//

import UIKit

class PieView: UIView {

    @IBInspectable var value : CGFloat = CGFloat(0.0)
    @IBInspectable var color : UIColor = UIColor.red
    
    private var pieValue = CGFloat(0.0)
    
    let shapelayer = CAShapeLayer()
    let trackLayer = CAShapeLayer()
    var arcCentre = CGPoint()
    var radius = CGFloat(0.0)
    let lineWidth: CGFloat = 12
    var endPoint = CGPoint()
    var distance: CGFloat = 0.0
    
    override init(frame:CGRect) {
        super.init(frame:frame)
        self.isOpaque = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    override func draw(_ rect: CGRect) {
        
        shapelayer.removeAllAnimations()
        shapelayer.removeFromSuperlayer()
        trackLayer.removeFromSuperlayer()
        
        let size = self.frame.size.width
        
        radius = size/2.3
        
        arcCentre = CGPoint(x: self.frame.size.width/2,y: self.frame.size.height/2)
        
        let circularPath = UIBezierPath(arcCenter: arcCentre, radius: radius, startAngle: -CGFloat.pi/2, endAngle: 2*CGFloat.pi - CGFloat.pi/2, clockwise: true)

        trackLayer.path = circularPath.cgPath
        trackLayer.strokeColor = UIColor.lightGray.cgColor
        trackLayer.lineWidth = lineWidth
        trackLayer.fillColor = UIColor.clear.cgColor

        self.layer.addSublayer(trackLayer)
        
        pieValue = (value/100)*2*CGFloat.pi
        
        let pieCircularPath = UIBezierPath(arcCenter: arcCentre, radius: radius, startAngle: -CGFloat.pi/2, endAngle: pieValue - CGFloat.pi/2, clockwise: true)
        
        let convertedStartPoint = self.convert(CGPoint(x: arcCentre.x, y: arcCentre.y - radius), to: self.superview)
        endPoint = pieCircularPath.currentPoint
        let convertedEndPoint = self.convert(endPoint, to: self.superview)
        let X = convertedStartPoint.x-convertedEndPoint.x
        let Y = convertedStartPoint.y-convertedEndPoint.y
        distance = sqrt(X*X + Y*Y)
        self.perform(#selector(animate), with: nil, afterDelay: 0.3)
        self.perform(#selector(addLabel), with: nil, afterDelay: 1.3)
        
        shapelayer.path = pieCircularPath.cgPath
        shapelayer.strokeColor = color.cgColor
        shapelayer.lineWidth = lineWidth
        shapelayer.fillColor = UIColor.clear.cgColor
        //shapelayer.lineCap = CAShapeLayerLineCap.round
        
        shapelayer.shadowColor = UIColor.black.cgColor
        shapelayer.shadowOffset = CGSize(width: 1, height: 3)
        shapelayer.shadowOpacity = 0.5
        shapelayer.shadowRadius = 3
        
        shapelayer.strokeEnd = 0
        
        self.layer.addSublayer(shapelayer)
        //self.layer.cornerRadius = size/2
        //self.clipsToBounds = true
    }
    
    @objc private func animate() {
        let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        
        basicAnimation.toValue = 1
        basicAnimation.duration = 1
        basicAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
        basicAnimation.fillMode = CAMediaTimingFillMode.forwards
        basicAnimation.isRemovedOnCompletion = false
        
        shapelayer.add(basicAnimation, forKey: "nyam")
    }
    
    @objc private func addLabel() {
        var correction = CGFloat(0.0)
        if value > 0.001 {
            correction = CGFloat(180/(value*radius))
        } else {
            correction = CGFloat(0.1)
        }
        
        let dashWidth:CGFloat = 24
        let dashThickness:CGFloat = 3
//        let dashView = UIView.init(frame: CGRect(origin: CGPoint(x: arcCentre.x+radius*cos(pieValue - CGFloat.pi/2) - dashWidth/2, y: arcCentre.y+radius*sin(pieValue - CGFloat.pi/2) - dashThickness/2), size: CGSize(width: dashWidth, height: dashThickness)))
        let dashView = UIView(frame: CGRect(x: 0, y: 0, width: dashWidth, height: dashThickness))
        dashView.center = endPoint
        dashView.backgroundColor = color
        dashView.alpha = 0
        dashView.transform = CGAffineTransform.init(rotationAngle: pieValue - CGFloat.pi/2)
        dashView.layer.shadowColor = UIColor.black.cgColor
        dashView.layer.shadowOffset = CGSize(width: 1, height: 3)
        dashView.layer.shadowOpacity = 0.5
        dashView.layer.shadowRadius = 3
        self.addSubview(dashView)
        
        let label = UILabel.init(frame: CGRect(origin: CGPoint(x: arcCentre.x+radius*cos(pieValue*(1+correction) - CGFloat.pi/2)-18,y: arcCentre.y+radius*sin(pieValue*(1+correction) - CGFloat.pi/2)-7), size: CGSize(width: 36,height: 14)))
        label.textColor = distance > 18 ? color : (color == UIColor.white ? UIColor.darkGray : UIColor.white)
        label.alpha = 0
        label.textAlignment = NSTextAlignment.center
        label.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight(rawValue: 2))
        label.transform = CGAffineTransform.init(rotationAngle: pieValue - CGFloat.pi/2)
        label.text = String.init(describing: Int(value))
        label.layer.shadowColor = UIColor.black.cgColor
        label.layer.shadowOffset = CGSize(width: 1, height: 3)
        label.layer.shadowOpacity = 0.5
        label.layer.shadowRadius = 3
        self.addSubview(label)
        
        UIView .animate(withDuration: 0.3) {
            label.alpha = 1
            dashView.alpha = 1
        }
    }
}
