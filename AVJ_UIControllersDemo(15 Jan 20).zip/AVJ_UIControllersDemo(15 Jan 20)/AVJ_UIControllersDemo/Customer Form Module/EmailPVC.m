//
//  EmailPVC.m
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "EmailPVC.h"

@interface EmailPVC ()

@end

@implementation EmailPVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _cancelButton.layer.cornerRadius = 4;
    _confirmButton.layer.cornerRadius = 4;
    _cancelButton.clipsToBounds = YES;
    _confirmButton.clipsToBounds = YES;
    _inputField.text = _email;

}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.superview.layer.cornerRadius = 0;
    self.view.superview.clipsToBounds = NO;
}

- (IBAction)cancelClicked:(UIButton *)sender {
    [_delegate dismissPopUp];
}

- (IBAction)confirmClicked:(UIButton *)sender {
    NSString *emailID = [_inputField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (emailID.length == 0) {
        [self showAlertWithTitle:nil andMessage:@"Please enter an email address"];
    }
    else if (![self validateEmailWithString:emailID]) {
        [self showAlertWithTitle:nil andMessage:@"Please enter a valid email adress"];
    }
    else {
        if (![[emailID uppercaseString] isEqualToString:[_email uppercaseString]]) {
            [_delegate setEmailAddress:emailID];
        }
        [_delegate dismissPopUp];
    }
}

- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9]+\\.[A-Za-z]{2,3}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString*)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];
                             
                         }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}




















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
