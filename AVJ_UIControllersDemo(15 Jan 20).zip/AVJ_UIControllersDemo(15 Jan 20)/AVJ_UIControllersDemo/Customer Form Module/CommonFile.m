//
//  CommonFile.m
//  ECRFmainScreen
//
//  Created by admin on 12/05/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "CommonFile.h"
#import <QuartzCore/QuartzCore.h>

@implementation CommonFile

+ (UIImage *) imageWithView: (UIView *)view {
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 0.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}

@end
