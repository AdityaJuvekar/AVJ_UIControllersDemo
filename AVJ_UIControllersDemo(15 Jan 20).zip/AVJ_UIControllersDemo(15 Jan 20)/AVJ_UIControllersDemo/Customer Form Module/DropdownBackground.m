//
//  DropdownBackground.m
//  SpeedBanking
//
//  Created by admin on 04/10/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import "DropdownBackground.h"

@implementation DropdownBackground

+(CGFloat)arrowBase {
    return 0;
}

+(CGFloat)arrowHeight {
    return 0;
}

+(UIEdgeInsets)contentViewInsets {
    return UIEdgeInsetsZero;
}

-(UIPopoverArrowDirection)arrowDirection {
    return UIPopoverArrowDirectionUp;
}

-(CGFloat)arrowOffset {
    return 0;
}

-(void)setArrowOffset:(CGFloat)arrowOffset {
}

- (void)drawRect:(CGRect)rect {
    self.layer.cornerRadius = 0;
    self.clipsToBounds = NO;
    self.layer.shadowColor = [UIColor clearColor].CGColor;
}

-(void)setArrowDirection:(UIPopoverArrowDirection)arrowDirection {

}

@end
