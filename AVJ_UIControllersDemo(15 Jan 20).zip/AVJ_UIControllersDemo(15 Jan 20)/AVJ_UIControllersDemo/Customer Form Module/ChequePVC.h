//
//  ChequePVC.h
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ChequePVCDelegate <NSObject>
@required -(void)dismissPopUp;
@required -(void)whetherChequeRequired:(BOOL)chequeRequired;
@end

@interface ChequePVC : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;
@property (weak, nonatomic) IBOutlet UISegmentedControl *YNSegment;


- (IBAction)cancelClicked:(UIButton *)sender;
- (IBAction)confirmClicked:(UIButton *)sender;
- (IBAction)segmentControllerPressed:(UISegmentedControl *)sender;

@property BOOL chequeBookIsRequired;

@property (weak,nonatomic) id delegate;
@end
