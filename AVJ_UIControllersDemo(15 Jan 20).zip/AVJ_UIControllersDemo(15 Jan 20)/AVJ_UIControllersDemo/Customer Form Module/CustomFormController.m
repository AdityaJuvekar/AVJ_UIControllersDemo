//
//  CustomFormController.m
//  ECRFmainScreen
//
//  Created by admin on 06/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "CustomFormController.h"
#import <QuartzCore/CAAnimation.h>
#import "CommonFile.h"
#import "DropdownBackground.h"

@interface CustomFormController ()
@property (weak, nonatomic) IBOutlet UIButton *emailButton;
@property (weak, nonatomic) IBOutlet UIButton *panButton;
@property (weak, nonatomic) IBOutlet UIButton *mobileButton;
@property (weak, nonatomic) IBOutlet UIButton *chequeButton;
@property (weak, nonatomic) IBOutlet UISegmentedControl *chequeSegmentControl;
@property int arrayIndex;
@end

@implementation CustomFormController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_chequeSegmentControl setTitleTextAttributes:[NSDictionary dictionaryWithObject:[UIFont boldSystemFontOfSize:10.0f] forKey:NSFontAttributeName] forState:UIControlStateNormal];
    [self disableButtons];
    [self initiateDataArrays];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    [self initiateDropDownTextFields];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self setShadow];
    int width = self.view.frame.size.width;
    int height = self.view.frame.size.height;
    _centralFrame = CGRectMake((width/2)-(width*2)/6, (height/2)-(width*4)/18, (width*2)/3, (width*4)/9);
}

-(void)disableButtons {
    _emailButton.enabled = NO;
    _panButton.enabled = NO;
    _mobileButton.enabled = NO;
    _chequeButton.enabled = NO;
}

-(void)enableButtons {
    _emailButton.enabled = YES;
    _panButton.enabled = YES;
    _mobileButton.enabled = YES;
    _chequeButton.enabled = YES;
}

-(void)initiateDropDownTextFields {
    _textFieldHol.userInteractionEnabled = NO;
    _textFieldAcc.delegate = self;
    _textFieldHol.delegate = self;
}

-(void)initiateDataArrays {
    _arrayIndex = -1;
    _accountNoArray = [[NSMutableArray alloc] initWithObjects:@"63525476",@"23747817024",@"8783698124",nil];
    _holderNameArray = [[NSMutableArray alloc] initWithObjects:@[@"Aditya Juvekar",@"Deepak Yadav",@"Ninad Divekar",@"Pooja Anbule",@"Sayali More"],@[@"Komal Dhumal",@"Prathamesh Sawant",@"Rahi Jain",@"Sandeep Khandare"],@[@"Dhrumil Shah",@"Gauri Desai",@"Sunil Dhappadhule",@"Vishal More"],nil];
    _holderNoArray = [[NSMutableArray alloc] initWithObjects:@[@"00000001",@"00000002",@"00000003",@"00000004",@"00000005"],@[@"00000006",@"00000007",@"00000008",@"00000009"],@[@"00000010",@"00000011",@"00000012",@"00000013"],nil];
}

-(void)setShadow {
    
    _custNameView.layer.borderWidth = 1.5f;
    _custNameView.layer.borderColor = [UIColor colorWithRed:149.0/255.0 green:184.0/255.0 blue:252.0/255.0 alpha:1].CGColor;
    
    _textFieldAcc.text = @"Select";
    _textFieldHol.text = @"Select";
    
    UIBezierPath *shadowPath1 = [UIBezierPath bezierPathWithRect:_topLeftOuterView.bounds];
    _topLeftOuterView.layer.masksToBounds = NO;
    _topLeftOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _topLeftOuterView.layer.shadowOffset = CGSizeMake(0.0f, 4.5f);
    _topLeftOuterView.layer.shadowOpacity = 0.5f;
    _topLeftOuterView.layer.shadowPath = shadowPath1.CGPath;
    
    UIBezierPath *shadowPath2 = [UIBezierPath bezierPathWithRect:_topRightOuterView.bounds];
    _topRightOuterView.layer.masksToBounds = NO;
    _topRightOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _topRightOuterView.layer.shadowOffset = CGSizeMake(0.0f, 4.5f);
    _topRightOuterView.layer.shadowOpacity = 0.5f;
    _topRightOuterView.layer.shadowPath = shadowPath2.CGPath;
    
    UIBezierPath *shadowPath3 = [UIBezierPath bezierPathWithRect:_bottomLeftOuterView.bounds];
    _bottomLeftOuterView.layer.masksToBounds = NO;
    _bottomLeftOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _bottomLeftOuterView.layer.shadowOffset = CGSizeMake(0.75f, 5.5f);
    _bottomLeftOuterView.layer.shadowOpacity = 0.4f;
    _bottomLeftOuterView.layer.shadowPath = shadowPath3.CGPath;
    
    UIBezierPath *shadowPath4 = [UIBezierPath bezierPathWithRect:_bottomLeftOuterView.bounds];
    _bottomRightOuterView.layer.masksToBounds = NO;
    _bottomRightOuterView.layer.shadowColor = [UIColor blackColor].CGColor;
    _bottomRightOuterView.layer.shadowOffset = CGSizeMake(0.75f, 5.5f);
    _bottomRightOuterView.layer.shadowOpacity = 0.4f;
    _bottomRightOuterView.layer.shadowPath = shadowPath4.CGPath;
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == _textFieldAcc || textField == _textFieldHol)
    {
        [self dropDownclicked:textField];
        return NO;
    }
    return YES;
}


- (void)dropDownclicked:(UITextField *)textField
{
    _currentfield=textField;
    int row_count = 0;
    DropDownController *ddt=[self.storyboard instantiateViewControllerWithIdentifier:@"DropDownController"];
    ddt.delegate = self;
    if (textField == _textFieldAcc) {
        ddt.tableDataArray1 = _accountNoArray;
        row_count = (int)_accountNoArray.count;
    }
    else if (textField == _textFieldHol && _arrayIndex>=0) {
        ddt.tableDataArray1 = _holderNameArray[_arrayIndex];
        ddt.tableDataArray2 = _holderNoArray[_arrayIndex];
        row_count = (int)((NSArray*)_holderNameArray[_arrayIndex]).count;
    }
    [ddt.tableView reloadData];
    
    ddt.preferredContentSize=CGSizeMake(textField.frame.size.width, row_count*50);
    ddt.modalPresentationStyle = UIModalPresentationPopover;
    ddt.view.clipsToBounds = NO;
    
    _Dropdown = ddt.popoverPresentationController;
    
    _Dropdown.delegate = self;
    _Dropdown.sourceView = self.view;
    _Dropdown.popoverBackgroundViewClass = [DropdownBackground class];
    CGRect rect = [self.view convertRect:textField.frame fromView:textField.superview];
    _Dropdown.sourceRect = rect;
    [_Dropdown setPermittedArrowDirections:UIPopoverArrowDirectionUp];
    [self presentViewController:ddt animated:NO completion:nil];
}

-(void)rowSelectedWithName:(NSString *)string1 andNumber:(NSString *)string2{
    [self dismissViewControllerAnimated:NO completion:nil];
    if (_currentfield == _textFieldAcc) {
        [self disableButtons];
        _accountNumber = string1;
        _arrayIndex = (int)[_accountNoArray indexOfObject:string1];
        _holderName = NULL;
        _textFieldAcc.text = string1;
        _textFieldHol.text = @"Select";
        _textFieldHol.userInteractionEnabled = YES;
        [_custNameLabel setFrame:CGRectMake(0, 0, 0, 0)];
        _custNameLabel.text = nil;
        [UIView animateWithDuration:.4 animations:^{
            [_custNameView setFrame:CGRectMake(24, 18, 0, 0)];
        } completion:^(BOOL finished) {
            
        }];
    }
    else if (_currentfield == _textFieldHol) {
        [self enableButtons];
        _holderName = string1;
        _textFieldHol.text = string1;
        [UIView animateWithDuration:.5 animations:^{
            [_custNameView setFrame:CGRectMake(24, 18, _custNameView.superview.frame.size.width-48, _custNameView.superview.frame.size.height-18)];
        } completion:^(BOOL finished) {
            [_custNameLabel setFrame:CGRectMake(20, 0, _custNameView.frame.size.width-30, _custNameView.frame.size.height)];
            _custNameLabel.text = [NSString stringWithFormat:@"Name :   %@ (%@)",string1,string2];
            self.mobile = @"9898989898";
            self.PAN = @"QWERT1111Y";
            self.email = @"xxxxx@xxxx.xxx";
            self.chequeWanted = TRUE;
        }];
    }
}

-(void)setEmail:(NSString *)email {
    _email = email;
    _emailLabel.text = email;
}

-(void)setPAN:(NSString *)PAN {
    _PAN = PAN;
    _PANLabel.text = PAN;
}

-(void)setMobile:(NSString *)mobile {
    _mobile = mobile;
    _mobileLabel.text = mobile;
}

-(void)setChequeWanted:(BOOL)chequeWanted {
    _chequeWanted = chequeWanted;
    if(chequeWanted)
        _chequeLabel.text = @"YES";
    else
        _chequeLabel.text = @"NO";
}

- (IBAction)flipperPressed:(UIButton *)sender {
    [self.view setUserInteractionEnabled:NO];
    _superView = [sender superview];
    _frontView = [_superView viewWithTag:20];
    _middleView = [_superView viewWithTag:30];
    _backView = [_superView viewWithTag:10];
    _middleView.alpha = 0;
    _convertedFrame = [_superView convertRect:_backView.frame toView:self.view];
    [UIView transitionWithView:_superView
                      duration:.7
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        _frontView.hidden = true;
                        _middleView.hidden = true;
                        _backView.hidden = false;
                    } completion:^(BOOL finished) {
                        _image = [CommonFile imageWithView:_backView];
                        _imageView = [[UIImageView alloc]initWithImage:_image];
                        [self.view addSubview:_imageView];
                        [_imageView setFrame:_convertedFrame];
                        _middleView.hidden = false;
                        _middleView.alpha = 1;
                        [UIView animateWithDuration:.7
                                         animations:^{
                                             [_imageView setFrame:_centralFrame];
                                             _imageView.alpha = .5;
                                         } completion:^(BOOL finished) {
                                             _imageView.alpha = 0;
                                             [self displayPopupScreenNumber:sender.tag];
                                         }];
                    }];
}

-(void)displayPopupScreenNumber:(NSInteger)number {
    if(number == 1) {
        EmailPVC *EVC = (EmailPVC*)[self.storyboard instantiateViewControllerWithIdentifier:@"EmailPVC"];
        EVC.delegate = self;
        EVC.email = _email;
        _PVC = EVC;
    }
    else if (number == 2) {
        PanPVC *PVC = [self.storyboard instantiateViewControllerWithIdentifier:@"PanPVC"];
        PVC.delegate = self;
        PVC.PAN = _PAN;
        _PVC = PVC;
    }
    else if (number == 3) {
        MobilePVC *MVC = [self.storyboard instantiateViewControllerWithIdentifier:@"MobilePVC"];
        MVC.delegate = self;
        MVC.mobile = _mobile;
        _PVC = MVC;
    }
    else if (number == 4) {
        ChequePVC *CVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ChequePVC"];
        CVC.delegate = self;
        CVC.chequeBookIsRequired = _chequeWanted;
        _PVC = CVC;
    }
    _PVC.preferredContentSize=CGSizeMake(_centralFrame.size.width, _centralFrame.size.height);
    _PVC.modalPresentationStyle = UIModalPresentationPopover;
    _PVC.view.clipsToBounds = NO;
    
    _Popup = _PVC.popoverPresentationController;
    
    _Popup.delegate = self;
    _Popup.sourceView = self.view;
    _Popup.popoverBackgroundViewClass = [DropdownBackground class];
    //CGRect rect = [self.view convertRect:textField.frame fromView:textField.superview];
    CGRect rect = CGRectMake(self.view.center.x-_centralFrame.size.width/2, self.view.center.y+_centralFrame.size.height/2,_centralFrame.size.width,0);
    _Popup.sourceRect = rect;
    [_Popup setPermittedArrowDirections:UIPopoverArrowDirectionDown];
    [self presentViewController:_PVC animated:NO completion:nil];
}

-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

-(BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    if (popoverPresentationController == _Dropdown) {
        [popoverPresentationController setPopoverBackgroundViewClass:nil];
        return YES;
    }
    return NO;
}

-(void)dismissPopUp {
    _imageView.alpha = .5;
    UIImage *capturedImage = [CommonFile imageWithView:_PVC.view];
    [_imageView setImage:capturedImage];
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];
    [self.view setUserInteractionEnabled:NO];
    [UIView animateWithDuration:.7
                     animations:^{
                         [_imageView setFrame:_convertedFrame];
                         _imageView.alpha = 1;
                     } completion:^(BOOL finished) {
                         _middleView.alpha = 0;
                         [self performSelector:@selector(flipViewsToDefault) withObject:nil afterDelay:.05];
                        /* _imageView.alpha = 0;
                         _imageView = nil;
                         [UIView transitionWithView:_superView
                                           duration:.7
                                            options:UIViewAnimationOptionTransitionFlipFromRight
                                         animations:^{
                                             _middleView.hidden = true;
                                             _backView.hidden = true;
                                             _frontView.hidden = false;
                                         } completion:^(BOOL finished) {
                                             [self.view setUserInteractionEnabled:YES];
                                         }];*/
                     }];
}

-(void)flipViewsToDefault {
    _imageView.alpha = 0;
    _imageView = nil;
    [UIView transitionWithView:_superView
                      duration:.7
                       options:UIViewAnimationOptionTransitionFlipFromRight
                    animations:^{
                        //_middleView.hidden = true;
                        _backView.hidden = true;
                        _frontView.hidden = false;
                    } completion:^(BOOL finished) {
                        [self.view setUserInteractionEnabled:YES];
                    }];
}

-(void)setMobileNumber:(NSString*)number {
    self.mobile = number;
}

-(void)whetherChequeRequired:(BOOL)chequeRequired {
    self.chequeWanted = chequeRequired;
}

-(void)setEmailAddress:(NSString*)emailID {
    self.email = emailID;
}

-(void)setPANnumber:(NSString*)PANnumber {
    self.PAN = PANnumber;
}


@end
