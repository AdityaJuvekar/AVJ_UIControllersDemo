//
//  DropDownCell.m
//  ECRFmainScreen
//
//  Created by admin on 23/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "DropDownCell.h"

@implementation DropDownCell

- (void)awakeFromNib {
    [super awakeFromNib];
    //self.mainView.layer.cornerRadius = 2;
    //self.mainView.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
