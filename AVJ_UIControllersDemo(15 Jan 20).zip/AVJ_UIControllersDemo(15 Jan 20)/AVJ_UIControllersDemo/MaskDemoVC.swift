//
//  MaskDemoVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 29/11/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class MaskDemoVC: UIViewController {

    @IBOutlet weak var navyBlueView: UIView!
    @IBOutlet weak var maskingView: UIView!
    
    @IBOutlet weak var pieView: SequentialPieView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        maskingView.frame = CGRect(x: maskingView.frame.origin.x + 100, y: maskingView.frame.origin.y, width: maskingView.frame.size.width, height: maskingView.frame.size.height)
//        let maskView = UIView(frame: CGRect(x: 100, y: 0, width: maskingView.frame.size.width, height: maskingView.frame.size.height))
//        maskView.layer.cornerRadius = 32
//        maskView.backgroundColor = .white
//
//        navyBlueView.mask = maskView
//
//        let displayLink = CADisplayLink(target: self, selector: #selector(slideMask))
//        displayLink.preferredFramesPerSecond = 30
//        displayLink.add(to: .main, forMode: .common)
        drawCropCircleWith(valueArray: [10,50,40])
    }
    
    var width: CGFloat = -400
    
    @objc func slideMask() {
        //navyBlueView.mask = nil
//        maskingView.frame = CGRect(x: width, y: 0, width: maskingView.frame.size.width, height: maskingView.frame.size.height)
        let maskView = UIView(frame: CGRect(x: width, y: 0, width: maskingView.frame.size.width, height: maskingView.frame.size.height))
        maskView.layer.cornerRadius = 32
        maskView.backgroundColor = .white
        
        navyBlueView.mask = maskView
        width += 8
    }
    
    func drawCropCircleWith(valueArray: [Double]) {
        
        var dataArray = [SequentialPieStruct]()
        
        let colorArray = [UIColor(red:171.0/255.0, green:45.0/255.0, blue:54.0/255.0, alpha:1), UIColor(red:235.0/255.0, green:95.0/255.0, blue:51.0/255.0, alpha:1), UIColor(red:241.0/255.0, green:183.0/255.0, blue:49.0/255.0, alpha:1), UIColor.yellow, UIColor(red:98.0/255.0, green:179.0/255.0, blue:75.0/255.0, alpha:1), UIColor(red:53.0/255.0, green:111.0/255.0, blue:60.0/255.0, alpha:1), UIColor(red:0.0/255.0, green:148.0/255.0, blue:203.0/255.0, alpha:1), UIColor.blue, UIColor.magenta, UIColor.purple]
        let imageNamesArray = ["icons8-buy-80.png","icons8-flag-2-64.png","icons8-motorcycle-filled-50.png","icons8-bipolar-disorder-90.png","icons8-salami-pizza-64.png","icons8-rupee-80.png","icons8-trust-64.png","icons8-cheap-2-80.png","icons8-descending-sorting-80.png","icons8-woman-with-a-suitcase-80.png"]
        var count = min(valueArray.count, colorArray.count)
        count = min(count, imageNamesArray.count)
        
        for i in 0..<count {
            let value = valueArray[i]
            let color = colorArray[i]
            let strfont = UIFont.systemFont(ofSize: 11, weight: .bold)
            let subfont = UIFont.systemFont(ofSize: 9)
            let shadow = NSShadow()
            shadow.shadowColor = UIColor.init(white: 0.2, alpha: 0.3)
            shadow.shadowOffset = CGSize(width: 3, height: 1.5)
            shadow.shadowBlurRadius = 5
            
            let strAttributes: [NSAttributedString.Key: Any] = [
                .font: strfont,
                .foregroundColor: colorArray[i],
                .shadow: shadow
            ]
            let subAttributes: [NSAttributedString.Key: Any] = [
                .font: subfont,
                .foregroundColor: UIColor.gray,
                .shadow: shadow
            ]
            let attributedStr = NSAttributedString(string: "Sample String\(i+1)", attributes: strAttributes)
            let attributedSub = NSAttributedString(string: "Sample Sub\(i+1)", attributes: subAttributes)
            let finalAttibutedStr = NSMutableAttributedString(attributedString: attributedStr)
            finalAttibutedStr.append(NSAttributedString(string: "\n"))
            finalAttibutedStr.append(attributedSub)
            let image = UIImage(named: imageNamesArray[i])
            let pieStruct = SequentialPieStruct(value: Double(value), color: color, image: image!, labelText: finalAttibutedStr)
            dataArray.append(pieStruct)
        }
        
        
        pieView.dataArray = dataArray
    }

}
