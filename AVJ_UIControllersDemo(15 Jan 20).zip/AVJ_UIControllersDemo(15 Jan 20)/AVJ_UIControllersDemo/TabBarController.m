//
//  TabBarController.m
//  AVJ_UIControllersDemo
//
//  Created by admin on 22/02/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "TabBarController.h"

@interface TabBarController ()

@end

@implementation TabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.tabBarItem.image
}

-(void)setSelectedViewController:(UIViewController *)selectedViewController
{
    [super setSelectedViewController:selectedViewController];
    for (UIViewController *viewController in self.viewControllers) {
        if (viewController == selectedViewController) {
            [viewController.tabBarItem setTitleTextAttributes:@{
                                                                NSFontAttributeName: [UIFont fontWithName:@"HelveticaNeue-Medium" size:14],
                                                                NSForegroundColorAttributeName: [UIColor colorWithRed:60.0/255.0 green:143.0/255.0 blue:31.0/255.0 alpha:1]
                                                                }
                                                     forState:UIControlStateNormal];
        } else {
            [viewController.tabBarItem setTitleTextAttributes:@{
                                                                NSFontAttributeName: [UIFont fontWithName:@"HelveticaNeue-Light" size:12],
                                                                NSForegroundColorAttributeName: [UIColor grayColor]
                                                                }
                                                     forState:UIControlStateNormal];
        }
    }
}

@end
