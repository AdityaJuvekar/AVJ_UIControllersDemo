//
//  MonthYearTable.h
//  AVJ_Calendar
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MonthYearTable : UITableViewController
@property (nonatomic) NSMutableArray *dataArray;
@property (weak, nonatomic) id delegate;

@end
