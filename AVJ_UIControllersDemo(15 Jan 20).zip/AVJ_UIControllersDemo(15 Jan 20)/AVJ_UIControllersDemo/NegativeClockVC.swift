//
//  NegativeClockVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 23/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class NegativeClockVC: UIViewController {

    @IBOutlet weak var blackGlass: BlackGlass!
    
    var minuteRepeater: Timer?
    var displayLink: CADisplayLink?
    var distanceFactor: CGFloat = 2.0
    let timeFormatter = DateFormatter()
    let dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timeFormatter.dateFormat = "HH:mm"
        dateFormatter.dateFormat = "dd MMM yyyy"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        super.viewDidAppear(animated)
        let now: Date = Date()
        let calendar: Calendar = Calendar.current
        let currentSeconds: Int = calendar.component(.second, from: now)
        minuteRepeater = Timer(fireAt: now.addingTimeInterval(Double(60 - currentSeconds)),
                               interval: 60,
                               target: self,
                               selector: #selector(timerFired(_:)),
                               userInfo: nil,
                               repeats: true)
        
        guard let minuteRepeater = minuteRepeater else { return }
        RunLoop.main.add(minuteRepeater, forMode: .default)
        minuteRepeater.fire()
    }
    
    
    @objc func timerFired(_ timer: Timer) {
        distanceFactor = 2
        let currentTimeStr = timeFormatter.string(from: Date())
        let currentDateStr = dateFormatter.string(from: Date())
        blackGlass.oldTimeStr = blackGlass.currentTimeStr
        blackGlass.currentTimeStr = currentTimeStr
        blackGlass.dateStr = currentDateStr
        blackGlass.changedNumberIndexes = []
        displayLink = CADisplayLink(target: self, selector: #selector(updateBlackGlass))
        guard let displayLink = displayLink else { return }
        if #available(iOS 10.0, *) {
            displayLink.preferredFramesPerSecond = 15
        } else {
            displayLink.frameInterval = 15
        }
        displayLink.add(to: .main, forMode: .default)
    }
    
    @objc func updateBlackGlass() {
        if distanceFactor > 1 {
            blackGlass.distanceFactor = distanceFactor - 1
        } else if distanceFactor == 1 {
            blackGlass.distanceFactor = 0
        } else {
            blackGlass.distanceFactor = 1 + distanceFactor
        }
        
        distanceFactor -= 0.075
        
        blackGlass.setNeedsDisplay()
        
        guard let displayLink = displayLink else { return }
        if distanceFactor < 0 {
            displayLink.isPaused = true
            displayLink.invalidate()
            displayLink.remove(from: .main, forMode: .default)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        minuteRepeater?.invalidate()
        displayLink = nil
        minuteRepeater = nil
    }
    
    @IBAction func dismissSelf(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
}
