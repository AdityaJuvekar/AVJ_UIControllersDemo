//
//  SwiftMarkerView.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 18/08/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class SwiftMarkerView: UIView {
    
    var markingColor: UIColor?
    var selectionColor: UIColor?

    override func draw(_ rect: CGRect) {
        if let markerColor = markingColor {
            let context = UIGraphicsGetCurrentContext()
            let frameWidth = self.frame.size.width
            let frameHeight = self.frame.size.height
            let shadowColor = UIColor(white: 0.5, alpha: 0.5).cgColor
            let circleRadius = min(frameWidth, frameHeight)/2 - 3
            context!.beginPath()
            
                //---Triangle at top right
            context?.move(to: CGPoint(x: frameWidth-14, y: 4))
            context?.addLine(to: CGPoint(x: frameWidth-4, y: 4))
            context?.addLine(to: CGPoint(x: frameWidth-4, y: 14))
            context!.closePath();
            context!.setFillColor(markerColor.cgColor);
            context?.setShadow(offset: CGSize(width: -1.0, height: 2.0), blur: 1, color: shadowColor)
            context?.fillPath();
            
                //---Bar at the top
//            context?.move(to: CGPoint(x: 8, y: 4))
//            context?.addLine(to: CGPoint(x: frameWidth-8, y: 4))
//            context?.setLineWidth(4)
//            context?.setStrokeColor(markerColor.cgColor)
//            context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//            context?.strokePath()
            
                //---Bar at the bottom
//            context?.move(to: CGPoint(x: 8, y: frameHeight-5))
//            context?.addLine(to: CGPoint(x: frameWidth-8, y: frameHeight-5))
//            context?.setLineWidth(4)
//            context?.setStrokeColor(markerColor.cgColor)
//            context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//            context?.strokePath()
            
                //---Dot at top right
//            context?.addArc(center: CGPoint(x: frameWidth-8, y: 8), radius: 4, startAngle: 0, endAngle: .pi*2, clockwise: true)
//            context?.setFillColor(markerColor.cgColor)
//            context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//            context?.fillPath()
            
                //---Square at bottom right
//            context?.addRect(CGRect(origin: CGPoint(x: frameWidth-8, y: frameHeight-8), size: CGSize(width: 6, height: 6)))
//            context?.setFillColor(markerColor.cgColor)
//            context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//            context?.fillPath()
            
                //---Circle around label
//            context?.addArc(center: CGPoint(x: frameWidth/2, y: frameHeight/2), radius: circleRadius, startAngle: 0, endAngle: .pi*2, clockwise: true)
//            //context?.setFillColor(markerColor.cgColor)
//            //context?.fillPath()
//            context?.setStrokeColor(markerColor.cgColor)
//            context?.setLineWidth(2.5)
//            context?.strokePath()
        }
        
        if let selectionColor = selectionColor {
            let context = UIGraphicsGetCurrentContext()
            let frameWidth = self.frame.size.width
            let frameHeight = self.frame.size.height
            let shadowColor = UIColor(white: 0.5, alpha: 0.5).cgColor
            let circleRadius = min(frameWidth, frameHeight)/2 - 3
            context!.beginPath()
            
            //---Triangle at top right
//            context?.move(to: CGPoint(x: frameWidth-16, y: 4))
//            context?.addLine(to: CGPoint(x: frameWidth-4, y: 4))
//            context?.addLine(to: CGPoint(x: frameWidth-4, y: 16))
//            context!.closePath();
//            context!.setFillColor(selectionColor.cgColor);
//            context?.setShadow(offset: CGSize(width: -1.0, height: 2.0), blur: 1, color: shadowColor)
//            context?.fillPath();
            
            //---Bar at the top
//                        context?.move(to: CGPoint(x: 8, y: 4))
//                        context?.addLine(to: CGPoint(x: frameWidth-8, y: 4))
//                        context?.setLineWidth(4)
//                        context?.setStrokeColor(selectionColor.cgColor)
//                        context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//                        context?.strokePath()
            
            //---Bar at the bottom
//                        context?.move(to: CGPoint(x: 8, y: frameHeight-5))
//                        context?.addLine(to: CGPoint(x: frameWidth-8, y: frameHeight-5))
//                        context?.setLineWidth(4)
//                        context?.setStrokeColor(selectionColor.cgColor)
//                        context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//                        context?.strokePath()
            
            //---Dot at top right
//                        context?.addArc(center: CGPoint(x: frameWidth-8, y: 8), radius: 4, startAngle: 0, endAngle: .pi*2, clockwise: true)
//                        context?.setFillColor(selectionColor.cgColor)
//                        context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//                        context?.fillPath()
            
            //---Square at bottom right
//                        context?.addRect(CGRect(origin: CGPoint(x: frameWidth-8, y: frameHeight-8), size: CGSize(width: 6, height: 6)))
//                        context?.setFillColor(selectionColor.cgColor)
//                        context?.setShadow(offset: CGSize(width: -1.0, height: 1.5), blur: 1, color: shadowColor)
//                        context?.fillPath()
            
            //---Circle around label
                        context?.addArc(center: CGPoint(x: frameWidth/2, y: frameHeight/2), radius: circleRadius, startAngle: 0, endAngle: .pi*2, clockwise: true)
                        //context?.setFillColor(selectionColor.cgColor)
                        //context?.fillPath()
                        context?.setStrokeColor(selectionColor.cgColor)
                        context?.setLineWidth(2.5)
                        context?.strokePath()
        }
    }
    

}
