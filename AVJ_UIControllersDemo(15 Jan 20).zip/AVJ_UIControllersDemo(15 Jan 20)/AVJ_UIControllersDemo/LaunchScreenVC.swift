//
//  LaunchScreenVC.swift
//  AVJ_UIControllersDemo
//
//  Created by Azim on 27/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class LaunchScreenVC: UIViewController, CAAnimationDelegate {
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //initialsLabel.alpha = 0
        initialsLabel.isOpaque = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        initialsLabel.alpha = 1
        let maskingGradient = CAGradientLayer()
        maskingGradient.frame = CGRect(x: -view.frame.width, y: 0, width: view.frame.width, height: view.frame.height)
        maskingGradient.colors = [UIColor.clear.cgColor,UIColor.white.cgColor,UIColor.clear.cgColor]
        maskingGradient.locations = [0.4,0.5,0.6]
        maskingGradient.transform = CATransform3DRotate(maskingGradient.transform, -.pi/4, 0, 0, 1)
        initialsLabel.layer.mask = maskingGradient
        
        let shineAnimation = CABasicAnimation(keyPath: "transform.translation.x")
        shineAnimation.fromValue = -view.frame.width
        shineAnimation.toValue = 1.5*view.frame.width
        shineAnimation.delegate = self
        shineAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        shineAnimation.isRemovedOnCompletion = false
        shineAnimation.duration = 2.5
        maskingGradient.add(shineAnimation, forKey: "Nyam")

    }
    
    @objc func jumpToTabController() {
        
    }
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        initialsLabel.isOpaque = false
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabVCContainer")
        self.present(vc!, animated: true, completion: nil)
    }

}
