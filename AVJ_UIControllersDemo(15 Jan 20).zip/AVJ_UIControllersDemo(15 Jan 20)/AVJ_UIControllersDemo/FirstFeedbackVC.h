//
//  FirstFeedbackVC.h
//  SpeedBanking
//
//  Created by admin on 02/11/17.
//  Copyright © 2017 AXIS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstFeedbackVC : UIViewController<UIGestureRecognizerDelegate>

@end
