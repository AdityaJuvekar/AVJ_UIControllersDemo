//
//  CalendarVC.m
//  AVJ_Calendar
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "CalendarVC.h"
#import "DateCell.h"
#import "MonthYearTable.h"
#import "CommonFile.h"
#import "DropdownBackground.h"
#import "MagnifierView.h"

@interface CalendarVC () <UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIView *topBar;
@property (weak, nonatomic) IBOutlet UIButton *leftButton;
@property (weak, nonatomic) IBOutlet UIButton *rightButton;
@property (weak, nonatomic) IBOutlet UIButton *monthButton;
@property (weak, nonatomic) IBOutlet UIButton *yearButton;
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *dayNameLabels;
@property (weak, nonatomic) IBOutlet UIView *collectionContainerView;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic) BOOL currentMonthFlag;
@property (nonatomic) BOOL monthFlag;
@property (nonatomic) NSDate *todayDate;
@property (nonatomic) NSInteger today;
@property (nonatomic) NSInteger day;
@property (nonatomic) NSUInteger numberOfDaysInMonth;
@property (nonatomic) NSUInteger numberOfDaysInPreviousMonth;
@property (nonatomic) NSInteger offset;
@property (nonatomic) NSInteger currentMonth;
@property (nonatomic) NSInteger currentYear;
@property (nonatomic) NSInteger month;
@property (nonatomic) NSInteger year;
@property (nonatomic) NSCalendar *calendar;
@property (nonatomic) NSArray *weekDaysNameArray;
@property (nonatomic) NSMutableArray *monthArray;
@property (nonatomic) NSMutableArray *monthNamesArray;
@property (nonatomic) NSMutableArray *yearArray;
@property (nonatomic) NSMutableArray *selectedDatesArray;
@property (nonatomic) UIPopoverPresentationController *dropDown;
@property (nonatomic) NSArray *markedDatesArray;
@property (nonatomic) NSArray *markingColorsArray;
@property (nonatomic) UIColor *selectionColor;
@property (nonatomic) UIFont *currentMonthFont;
@property (nonatomic) UIFont *otherMonthFont;
@property (nonatomic) MagnifierView *lens;
- (IBAction)showPreviousMonth:(UIButton *)sender;
- (IBAction)showNextMonth:(UIButton *)sender;
- (IBAction)showMonthDropdown:(UIButton *)sender;
- (IBAction)showYearDropdown:(UIButton *)sender;

@end

@implementation CalendarVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _indexOfFirstWeekDay = _indexOfFirstWeekDay%7;
    _calendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    [self setDate];
    [self prepareMonthAndYearArrays];
    _collectionContainerView.clipsToBounds = true;
    _selectionColor = [UIColor grayColor];
    _currentMonthFont = [UIFont systemFontOfSize:14 weight:UIFontWeightBold];
    _otherMonthFont = [UIFont systemFontOfSize:13 weight:UIFontWeightLight];
    UILongPressGestureRecognizer *gestureRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(magnify:)];
    gestureRecognizer.delegate = self;
    [_collectionView addGestureRecognizer:gestureRecognizer];
    [self setupCalendar];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshCalenderForDeviceOrientation) name:UIDeviceOrientationDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setupCalendarForNewDate) name:NSCalendarDayChangedNotification object:nil];
}

-(void)setIndexOfFirstWeekDay:(NSUInteger)indexOfFirstWeekDay {
    _indexOfFirstWeekDay = indexOfFirstWeekDay;
    [self setupCalendar];
    [_collectionView reloadData];
}

-(void)setWeekdayLabels {
    NSUInteger count = _weekDaysNameArray.count;
    for (NSUInteger i = 0; i<count; i++) {
        NSUInteger j = i + _indexOfFirstWeekDay;
        if(j < _weekDaysNameArray.count) {
            ((UILabel*)_dayNameLabels[i]).text = _weekDaysNameArray[j];
        } else {
            ((UILabel*)_dayNameLabels[i]).text = _weekDaysNameArray[j - count];
        }
    }
}

-(void)setDate {
    _todayDate = [NSDate date];
    NSDateComponents *weekdayComponents = [_calendar components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:_todayDate];
    _today = [weekdayComponents day];
    _currentMonth = [weekdayComponents month];
    _currentYear = [weekdayComponents year];
}

-(void)setupCalendar {
    NSDateComponents *weekdayComponents = [_calendar components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:_todayDate];
    _day = [weekdayComponents day];
    _month = [weekdayComponents month];
    _year = [weekdayComponents year];
    if (_month==_currentMonth && _year==_currentYear) {
        _currentMonthFlag = true;
    } else {
        _currentMonthFlag = false;
    }
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    NSString *monthName = [[df monthSymbols] objectAtIndex:(_month-1)];
    [_monthButton setTitle:monthName forState:UIControlStateNormal];
    [_yearButton setTitle:[NSString stringWithFormat:@"%ld",_year] forState:UIControlStateNormal];
    weekdayComponents.day = 1;
    NSDate *firstDayOfMonth = [_calendar dateFromComponents:weekdayComponents];
    NSInteger wd = [_calendar component:NSCalendarUnitWeekday fromDate:firstDayOfMonth];
    //NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //[dateFormatter setDateFormat:@"EEEE"];
    NSInteger nyam = wd-2-_indexOfFirstWeekDay;
    if (nyam >= 0) {
        _offset = wd-2-_indexOfFirstWeekDay;
    } else {
        _offset = wd+5-_indexOfFirstWeekDay;
    }
    NSRange range = [_calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:_todayDate];
    _numberOfDaysInMonth = range.length;
    _numberOfDaysInPreviousMonth = [_calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:[_calendar dateByAddingUnit:NSCalendarUnitMonth value:-1 toDate:_todayDate options:NSCalendarSearchBackwards]].length;
    [self setWeekdayLabels];
}

#pragma mark - collectionViewMethods
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    NSInteger numberOfCells = _numberOfDaysInMonth + _offset;
    if (numberOfCells%7 != 0) {
        return numberOfCells - (numberOfCells%7) + 7;
    } else {
        return numberOfCells;
    }
}

//-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
//    NSInteger normalizedIndex = indexPath.row+1-_offset;
//    DateCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"DateCell" forIndexPath:indexPath];
//    cell.mark = false;
//    [cell.contentView setBackgroundColor:[UIColor whiteColor]];
//    [cell.dateLabel setTextColor:[UIColor blackColor]];
//    cell.dateLabel.text = @"";
//    cell.contentView.layer.borderWidth = 0.5;
//
//    //Previous month cells
//    if (normalizedIndex < 1) {
//        cell.dateLabel.text = [NSString stringWithFormat:@"%ld", _numberOfDaysInPreviousMonth+normalizedIndex];
//        //[cell.contentView setBackgroundColor:[UIColor lightGrayColor]];
//        cell.dateLabel.textColor = [UIColor lightGrayColor];
//        [cell.contentView.layer setBorderColor:[UIColor lightGrayColor].CGColor];
//        return cell;
//    }
//
//    //Next month cells
//    if (normalizedIndex > _numberOfDaysInMonth) {
//        cell.dateLabel.text = [NSString stringWithFormat:@"%ld", normalizedIndex-_numberOfDaysInMonth];
//        //[cell.contentView setBackgroundColor:[UIColor lightGrayColor]];
//        cell.dateLabel.textColor = [UIColor lightGrayColor];
//        [cell.contentView.layer setBorderColor:[UIColor lightGrayColor].CGColor];
//        return cell;
//    }
//
//    //Currently displayed month cells
//    [cell.contentView.layer setBorderColor:[UIColor redColor].CGColor];
//    cell.dateLabel.text = [NSString stringWithFormat:@"%ld", normalizedIndex];
//
//    //Marked dates
//    for (int i=0; i<_markedDatesArray.count; i++) {
//        id date = _markedDatesArray[i];
//        NSInteger number = 0;
//        if ([date isKindOfClass:[NSNumber class]]) {
//            number = [date integerValue];
//        } else if([date isKindOfClass:[NSDate class]]){
//            NSDateComponents *weekdayComponents = [_calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:date];
//            if ([weekdayComponents year]==_year && [weekdayComponents month]==_month) {
//                number = [weekdayComponents day];
//            }
//        }
//        if(number == normalizedIndex) {
//            if(i < _markingColorsArray.count) {
//                cell.markingColor = _markingColorsArray[i];
//            } else {
//                cell.markingColor = _markingColorsArray[0];
//            }
//            cell.mark = true;
//        }
//    }
//
//    //Today's date
//    if (_currentMonthFlag && normalizedIndex == _today) {
//        [cell.contentView setBackgroundColor:[UIColor redColor]];
//        [cell.dateLabel setTextColor:[UIColor whiteColor]];
//    }
//    return cell;
//}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger normalizedIndex = indexPath.row+1-_offset;
    DateCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"DateCell" forIndexPath:indexPath];
    cell.mark = false;
    cell.select = false;
    [cell.contentView setBackgroundColor:[UIColor whiteColor]];
    [cell.dateLabel setTextColor:[UIColor blackColor]];
    [cell.dateLabel setFont: _currentMonthFont];
    cell.contentView.layer.borderWidth = 0.5;
    
    NSDate *currentIndexDate = [NSDate date];
    NSDateComponents *weekdayComponents;
    //Previous month cells
    if (normalizedIndex < 1) {
        currentIndexDate = [_calendar dateByAddingUnit:NSCalendarUnitMonth value:-1 toDate:_todayDate options:NSCalendarSearchBackwards];
        weekdayComponents = [_calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday) fromDate:currentIndexDate];
        weekdayComponents.day = _numberOfDaysInPreviousMonth+normalizedIndex;
        [cell.contentView setBackgroundColor:[UIColor colorWithWhite:0.95 alpha:1]];
        [cell.dateLabel setFont: _otherMonthFont];
        cell.dateLabel.textColor = [UIColor lightGrayColor];
        [cell.contentView.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    }
    
    //Next month cells
    else if (normalizedIndex > _numberOfDaysInMonth) {
        currentIndexDate = [_calendar dateByAddingUnit:NSCalendarUnitMonth value:1 toDate:_todayDate options:NSCalendarSearchBackwards];
        weekdayComponents = [_calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday) fromDate:currentIndexDate];
        weekdayComponents.day = normalizedIndex-_numberOfDaysInMonth;
        [cell.contentView setBackgroundColor:[UIColor colorWithWhite:0.95 alpha:1]];
        [cell.dateLabel setFont: _otherMonthFont];
        cell.dateLabel.textColor = [UIColor lightGrayColor];
        [cell.contentView.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    }
    
    //Currently displayed month cells
    else {
        weekdayComponents = [_calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday) fromDate:_todayDate];
        weekdayComponents.day = normalizedIndex;
        [cell.contentView.layer setBorderColor:[UIColor redColor].CGColor];
    }
    
    currentIndexDate = [_calendar dateFromComponents:weekdayComponents];
    cell.date = currentIndexDate;
    if ([_calendar component:NSCalendarUnitWeekday fromDate:currentIndexDate] == 1) {
        [cell.contentView setBackgroundColor:[UIColor colorWithRed:255/255.0 green:126/255.0 blue:121/255.0 alpha:1.0]];
    }
    cell.dateLabel.text = [NSString stringWithFormat:@"%ld",[_calendar component:NSCalendarUnitDay fromDate:currentIndexDate]];
    
    //Marked dates
    for (int i=0; i<_markedDatesArray.count; i++) {
        id date = _markedDatesArray[i];
        if ([date isKindOfClass:[NSNumber class]]) {
            if ([date intValue] == [cell.dateLabel.text intValue]) {
                (i < _markingColorsArray.count) ? (cell.markingColor = _markingColorsArray[i]) : (cell.markingColor = _markingColorsArray[0]);
                cell.mark = true;
            }
        } else if([date isKindOfClass:[NSDate class]]){
            if ([_calendar startOfDayForDate:date] == [_calendar startOfDayForDate:currentIndexDate]) {
                (i < _markingColorsArray.count) ? (cell.markingColor = _markingColorsArray[i]) : (cell.markingColor = _markingColorsArray[0]);
                cell.mark = true;
            }
        }
    }
    
    //Selected dates
    for (NSDate *date in _selectedDatesArray) {
        if ([_calendar startOfDayForDate:date] == [_calendar startOfDayForDate:cell.date]) {
            cell.selectionColor = _selectionColor;
            cell.select = true;
        }
    }
    
    //Today's date
    if (_currentMonthFlag && normalizedIndex == _today) {
        [cell.contentView setBackgroundColor:[UIColor redColor]];
        [cell.dateLabel setTextColor:[UIColor whiteColor]];
    }
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(collectionView.frame.size.width/7.001, collectionView.frame.size.height/6.333);
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    DateCell *cell = (DateCell*)[collectionView cellForItemAtIndexPath:indexPath];
    NSInteger normalizedIndex = indexPath.row+1-_offset;
    if (normalizedIndex < 1) {
        [self showPrevious];
    } else if (normalizedIndex > _numberOfDaysInMonth){
        [self showNext];
    } else {
        NSDate *selectedDate = cell.date;
        if ([_delegate respondsToSelector:@selector(dateSelected:)]) {
            [_delegate dateSelected:selectedDate];
        }
        //To mark/unmark the selected date
        cell.selectionColor = _selectionColor;
        cell.select = !cell.select;
        if ([_selectedDatesArray containsObject:selectedDate]) {
            [_selectedDatesArray removeObject:selectedDate];
        } else {
            [_selectedDatesArray addObject:selectedDate];
        }
    }
}


#pragma mark - dateSelection
- (IBAction)showPreviousMonth:(UIButton *)sender {
    [self showPrevious];
}

-(void)showPrevious {
    _todayDate = [_calendar dateByAddingUnit:NSCalendarUnitMonth value:-1 toDate:_todayDate options:NSCalendarSearchBackwards];
    [self changeMonth:1];
}

- (IBAction)showNextMonth:(UIButton *)sender {
    [self showNext];
}

-(void)showNext {
    _todayDate = [_calendar dateByAddingUnit:NSCalendarUnitMonth value:1 toDate:_todayDate options:NSCalendarSearchBackwards];
    [self changeMonth:-1];
}

-(void)changeMonth:(int)i {
    //NSLog(@"today: %@", _todayDate);
    [self setupCalendar];
    __block UIImageView *capturedImageView = [[UIImageView alloc]initWithFrame:_collectionView.bounds];
    capturedImageView.image = [CommonFile imageWithView:_collectionView];
    [_collectionContainerView addSubview:capturedImageView];
    [_collectionView reloadData];
    if([_delegate respondsToSelector:@selector(monthChangedWithNewDate:)]) {
        [_delegate monthChangedWithNewDate:_todayDate];
    }
    [UIView animateWithDuration:0.4
                     animations:^{
                         capturedImageView.transform = CGAffineTransformTranslate(capturedImageView.transform, i*self.collectionView.frame.size.width, 0);
                     }
                     completion:^(BOOL finished) {
                         [capturedImageView removeFromSuperview];
                         capturedImageView = nil;
                     }];
}

-(void)prepareMonthAndYearArrays {
    _weekDaysNameArray = @[@"Mon",@"Tue",@"Wed",@"Thu",@"Fri",@"Sat",@"Sun"];
    _monthArray = [[NSMutableArray alloc]initWithObjects:@"Jan(01)",@"Feb(02)",@"Mar(03)",@"Apr(04)",@"May(05)",@"Jun(06)",@"Jul(07)",@"Aug(08)",@"Sep(09)",@"Oct(10)",@"Nov(11)",@"Dec(12)", nil];
    _monthNamesArray = [[NSMutableArray alloc]initWithObjects:@"January",@"February",@"March",@"April",@"May",@"June",@"July",@"August",@"September",@"October",@"November",@"December", nil];
    _yearArray = [[NSMutableArray alloc]initWithObjects:@"2015",@"2016",@"2017",@"2018",@"2019",@"2020",@"2021",@"2022",@"2023",@"2024", nil];
    _selectedDatesArray = [[NSMutableArray alloc] init];
}

- (IBAction)showMonthDropdown:(UIButton *)sender {
    _monthFlag = true;
    [self showDropdownAtView:sender andArray:_monthArray];
}

- (IBAction)showYearDropdown:(UIButton *)sender {
    _monthFlag = false;
    [self showDropdownAtView:sender andArray:_yearArray];
}


-(void)showDropdownAtView:(UIView *)view andArray:(NSMutableArray *)array {
    MonthYearTable *dropDown = [self.storyboard instantiateViewControllerWithIdentifier:@"MonthYearTable"];
    dropDown.delegate = self;
    dropDown.dataArray = array;
    dropDown.preferredContentSize = CGSizeMake(70, 120);
    dropDown.modalPresentationStyle = UIModalPresentationPopover;
    
    _dropDown = dropDown.popoverPresentationController;
    _dropDown.delegate = self;
    _dropDown.sourceView = self.view;
    CGRect rect = [self.view convertRect:view.frame fromView:view.superview];
    _dropDown.sourceRect = rect;
    _dropDown.popoverBackgroundViewClass = [DropdownBackground class];
    [_dropDown setPermittedArrowDirections:UIPopoverArrowDirectionUp];
    [self presentViewController:dropDown animated:NO completion:nil];
}

-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

-(void)delegateMethod:(NSInteger) index {
    NSDateComponents *weekdayComponents = [_calendar components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:_todayDate];
    if (_monthFlag) {
        [_monthButton setTitle:_monthNamesArray[index] forState:UIControlStateNormal];
        weekdayComponents.month = index+1;
    } else {
        [_yearButton setTitle:_yearArray[index] forState:UIControlStateNormal];
        weekdayComponents.year = [_yearArray[index] integerValue];
    }
    _todayDate = [_calendar dateFromComponents:weekdayComponents];
    [self setupCalendar];
    [_collectionView reloadData];
    if([_delegate respondsToSelector:@selector(monthChangedWithNewDate:)]) {
        [_delegate monthChangedWithNewDate:_todayDate];
    }
}

-(void)markDatesFromArray:(NSArray *)dates withColors:(NSArray *)colors{
    _markedDatesArray = dates;
    for (id object in _markedDatesArray) {
        if ([object isKindOfClass:[NSDate class]]) {
            NSDateComponents *weekdayComponents = [_calendar components: NSCalendarUnitYear fromDate:object];
            NSString *year = [[NSString alloc] initWithFormat:@"%ld",weekdayComponents.year];
            if (![_yearArray containsObject:year]) {
                [_yearArray addObject:year];
                NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:nil
                                                                               ascending:YES];
                NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
                _yearArray = [NSMutableArray arrayWithArray:[_yearArray sortedArrayUsingDescriptors:sortDescriptors]];
            }
        }
    }
    if (colors.count>0 && [colors[0] isKindOfClass:[UIColor class]]) {
        _markingColorsArray = colors;
    } else {
        _markingColorsArray = @[[UIColor lightGrayColor]];
    }
    [_collectionView reloadData];
}

-(void)refreshCalenderForDeviceOrientation {
    [_collectionView reloadData];
}

-(void)setupCalendarForNewDate {
    [self setDate];
    [self setupCalendar];
    [_collectionView reloadData];
    if(_today == 1 && [_delegate respondsToSelector:@selector(monthChangedWithNewDate:)]) {
        [_delegate monthChangedWithNewDate:_todayDate];
    }
}

#pragma mark - magnification
-(void)magnify:(UILongPressGestureRecognizer*) recognizer {
    CGPoint touchPoint = [recognizer locationInView:recognizer.view];
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        if (_lens == nil) {
            _lens = [[MagnifierView alloc] initWithFrame:CGRectMake(touchPoint.x-60, touchPoint.y-60, 120, 120)];
            _lens.viewToMagnify = recognizer.view;
            [recognizer.view.superview addSubview:_lens];
            _lens.touchPoint = touchPoint;
            [_lens setNeedsDisplay];
        }
    } else if (recognizer.state == UIGestureRecognizerStateChanged) {
        _lens.touchPoint = touchPoint;
        [_lens setNeedsDisplay];
    } else /*if (recognizer.state == UIGestureRecognizerStateEnded)*/ {
        [_lens removeFromSuperview];
        _lens = nil;
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
