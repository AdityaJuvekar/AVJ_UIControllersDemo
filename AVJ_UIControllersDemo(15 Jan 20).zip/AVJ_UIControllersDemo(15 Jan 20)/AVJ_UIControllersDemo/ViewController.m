//
//  ViewController.m
//  BezierZigzagCurve
//
//  Created by admin on 06/07/17.
//  Copyright © 2017 AdityaVJ. All rights reserved.
//

#import "ViewController.h"
#import "ColorPickerVC.h"

@interface ViewController()
- (IBAction)decreaseNodes:(UIButton *)sender;
- (IBAction)increaseNodes:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UILabel *numberOfNodesLabel;
- (IBAction)tailOnOff:(UISwitch *)sender;
- (IBAction)decreaseTime:(UIButton *)sender;
- (IBAction)increaseTime:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *drawButton;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (nonatomic) NSMutableArray *pointViewsArray;
@property (nonatomic) int numberOfNodes;
@property (nonatomic) float time;
@property (nonatomic) CAShapeLayer *pointsLayer;
@property (nonatomic) BOOL wipeOutViews;
- (IBAction)openColorPicker:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *colorButton;
@property (nonatomic) UIPopoverPresentationController *colorPickerPopup;
@property (nonatomic) ColorPickerVC *colorPicker;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _snakeView.delegate = self;
    _snakeView.padding = 50;
    _snakeView.numberOfNodes = 5;
    _numberOfNodes = 5;
    _snakeView.drawEndTail = NO;
    _snakeView.animationDuration = 3;
    _snakeView.pathWidth = 8;
    _snakeView.segmentSeparation = .4;
    _snakeView.segmentLength = 16;
    _snakeView.pathColor = [UIColor purpleColor];
    _time = 3.0;
    _pointViewsArray = [[NSMutableArray alloc]init];
    _snakeView.draw = true;
    _wipeOutViews = false;
    [_colorButton setTintColor:[UIColor purpleColor]];
    [self disableDrawing];
    [self performSelector:@selector(enableDrawing) withObject:nil afterDelay:_time];
    [_drawButton setTitle:@"Erase" forState:UIControlStateNormal];
}

-(void)setTimeArray:(NSMutableArray *)timeArray {
    _timeArray = timeArray;
}

-(void)setPointsArray:(NSMutableArray *)pointsArray {
    _pointsArray = pointsArray;
    [self creatDotsAtPointsInPointsArray];
}

-(void)setCentresArray:(NSMutableArray *)centresArray {
    _centresArray = centresArray;
}

- (IBAction)drawPath {
    _pointsArray = nil;

    if (!_snakeView.draw && _wipeOutViews) {
        [self clearTopView];
        [_topView setNeedsDisplay];
        [_snakeView setNeedsDisplayInRect:_snakeView.frame];
        [self performSelector:@selector(clearSnakeView) withObject:nil afterDelay:0.05];
        [_drawButton setTitle:@"Draw" forState:UIControlStateNormal];
    } else if (_snakeView.draw && !_wipeOutViews){
        [_drawButton setTitle:@"Erase" forState:UIControlStateNormal];
        [self disableDrawing];
        [_snakeView setNeedsDisplayInRect:_snakeView.frame];
        [self performSelector:@selector(enableDrawing) withObject:nil afterDelay:_time];
    }
}

-(void)clearSnakeView {
    _snakeView.draw = true;
    _wipeOutViews = false;
}

-(void)disableDrawing {
    _drawButton.enabled = NO;
}

-(void)enableDrawing {
    
    _drawButton.enabled = YES;
    _snakeView.draw = false;
    _wipeOutViews = true;
}

-(void)clearTopView {
    for (UIView *point in _pointViewsArray) {
        [point removeFromSuperview];
    }
}

-(void)creatDotsAtPointsInPointsArray {
    for (int i=0; i<_pointsArray.count; i++) {
        [self performSelector:@selector(createDotAtPoint:) withObject:_pointsArray[i] afterDelay:[_timeArray[i] floatValue]];
    }
}

-(void)createDotAtPoint:(NSValue*)point {
    CGPoint location = point.CGPointValue;
    float dimension = 18;
    _dot = [[UIView alloc] initWithFrame:CGRectMake(location.x-dimension/2, location.y-dimension/2, dimension, dimension)];
    [_dot setBackgroundColor:[UIColor blueColor]];
    [_topView addSubview:_dot];
    _dot.layer.cornerRadius = dimension/2;
    [_pointViewsArray addObject:_dot];
}


- (IBAction)decreaseNodes:(UIButton *)sender {
    if (_numberOfNodes>2) {
        _numberOfNodes--;
        _snakeView.numberOfNodes = _numberOfNodes;
        _numberOfNodesLabel.text = [NSString stringWithFormat:@"%d",_numberOfNodes];
    }
}

- (IBAction)increaseNodes:(UIButton *)sender {
    _numberOfNodes++;
    _snakeView.numberOfNodes = _numberOfNodes;
    _numberOfNodesLabel.text = [NSString stringWithFormat:@"%d",_numberOfNodes];
}

- (IBAction)tailOnOff:(UISwitch *)sender {
    if (sender.isOn) {
        _snakeView.drawEndTail = YES;
    }
    else {
        _snakeView.drawEndTail = NO;
    }
}

- (IBAction)decreaseTime:(UIButton *)sender {
    if (_time>1.0) {
        _time = _time - 0.5;
        _snakeView.animationDuration = _time;
        _timeLabel.text = [NSString stringWithFormat:@"%.1f",_time];
    }
}

- (IBAction)increaseTime:(UIButton *)sender {
    _time = _time + 0.5;
    _snakeView.animationDuration = _time;
    _timeLabel.text = [NSString stringWithFormat:@"%.1f",_time];
}

-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

-(BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    return YES;
}

- (IBAction)openColorPicker:(UIButton *)sender {
    _colorPicker = [self.storyboard instantiateViewControllerWithIdentifier:@"ColorPickerVC"];
    _colorPicker.delegate = self;
    
    _colorPicker.preferredContentSize=CGSizeMake(250, 300);
    _colorPicker.modalPresentationStyle = UIModalPresentationPopover;
    
    _colorPickerPopup = _colorPicker.popoverPresentationController;
    
    _colorPickerPopup.delegate = self;
    _colorPickerPopup.sourceView = self.view;
    CGRect rect = [self.view convertRect:sender.frame fromView:sender.superview];
    _colorPickerPopup.sourceRect = rect;
    [_colorPickerPopup setPermittedArrowDirections:UIPopoverArrowDirectionDown];
    [self presentViewController:_colorPicker animated:NO completion:nil];
}

-(void)setButtonTint {
    [_colorButton setTintColor:_buttonColor];
    _snakeView.pathColor = _buttonColor;
}


@end
