//
//  MobilePVC.m
//  ECRFmainScreen
//
//  Created by admin on 13/06/17.
//  Copyright © 2017 admin. All rights reserved.
//

#import "MobilePVC.h"

@interface MobilePVC ()

@end

@implementation MobilePVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _cancelButton.layer.cornerRadius = 4;
    _confirmButton.layer.cornerRadius = 4;
    _cancelButton.clipsToBounds = YES;
    _confirmButton.clipsToBounds = YES;
    _inputField.text = _mobile;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.superview.layer.cornerRadius = 0;
    self.view.superview.clipsToBounds = NO;
}

- (IBAction)cancelClicked:(UIButton *)sender {
    [_delegate dismissPopUp];
}

- (IBAction)confirmClicked:(UIButton *)sender {
    NSString *mobileNo = [_inputField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if(mobileNo.length == 0) {
        [self showAlertWithTitle:nil andMessage:@"Please enter mobile number"];
    }
    else if (mobileNo.length < 9 || mobileNo.length >9) {
        [self showAlertWithTitle:nil andMessage:@"Mobile number should contain 10 digits"];
    }
    else if (![self validateMobileNumberWithString:mobileNo]) {
        [self showAlertWithTitle:nil andMessage:@"Please enter a valid mobile number"];
    }
    else {
        if (![mobileNo isEqualToString:_mobile]) {
            [_delegate setMobileNumber:mobileNo];
        }
        [_delegate captureAndSetImage];
        [_delegate dismissPopUp];
    }
}

-(BOOL)validateMobileNumberWithString:(NSString*)number {
    NSString *phoneRegex = @"[1-9]{1}+[0-9]{8}";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    return [phoneTest evaluateWithObject:number];
}

-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString*)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];
                             
                         }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}



@end
