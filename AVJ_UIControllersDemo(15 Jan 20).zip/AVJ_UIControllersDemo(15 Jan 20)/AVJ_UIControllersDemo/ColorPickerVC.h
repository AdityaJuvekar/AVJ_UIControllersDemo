//
//  ColorPickerVC.h
//  AVJ_UIControllersDemo
//
//  Created by admin on 22/01/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface ColorPickerVC : UIViewController<UIGestureRecognizerDelegate>
@property (weak, nonatomic) ViewController* delegate;
@end
