//
//  CustomerDetails+CoreDataProperties.h
//  AVJ_UIControllersDemo
//
//  Created by admin on 17/03/18.
//  Copyright © 2018 Admin. All rights reserved.
//

#import "CustomerDetails+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CustomerDetails (CoreDataProperties)

+ (NSFetchRequest<CustomerDetails *> *)fetchRequest;

@property (nonatomic) int32_t accountNumber;
@property (nonatomic) BOOL cheque;
@property (nullable, nonatomic, copy) NSString *custID;
@property (nullable, nonatomic, copy) NSString *emailID;
@property (nonatomic) int32_t mobile;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *pan;

@end

NS_ASSUME_NONNULL_END
